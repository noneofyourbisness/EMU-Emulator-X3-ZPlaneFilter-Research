# Recovered runtime stages and VST3 0.2.0

`emux_runtime.hpp` adds reusable C++17 motion and adaptive-gain components.
Use strict floating-point arithmetic, as for the existing cores. Prepare
`MorphLag` and `AdaptiveGain` before processing; initialize `RampedStereoFilter`
with the current cascade. The original executable and its activation system
are not required at runtime.

## Direct executable evidence

Source fingerprint is unchanged:
`6f342c6057a8a0fb69f021a0da46adbab7f5a332139a2ee3a9506c9fa84e6914`.
No executable patching or modern Eurorack Morpheus material was used.

- `0x1402fe9d0` generates the lag table using `2^(i * .05 * 10)` and the
  control interval. `0x1402cb280` selects normalized position 0.2 between
  entries 0 and 1, then takes a binary32 reciprocal, stored as double.
- `0x1402cbb60` subtracts accumulator * reciprocal, adds the current frequency
  target, clears magnitudes strictly below .0001, and converts the scaled
  accumulator to float. Initialization multiplies divisor * target in float.
- `0x1402cf8d0` computes `(new - previous) * float(1 / quantum)` for each of
  the five coefficients per section. Ramp kernels include `0x1402cbed0`,
  `0x1402cc200`, `0x1402cc690`, and `0x1402ccc80` for mono; adjacent stereo
  kernels add the shared deltas after processing each stereo pair. At the
  next control quantum the exact previous target is reloaded, eliminating drift.
- `0x1402cb140` prepares the 16 gain multipliers. Rates above 65,000 Hz take
  one square root; rates above 130,000 Hz take another. `0x1402cbc10` applies
  the detector/gain after filtering. Index is truncate(abs(output) * gain) & 15,
  using the larger absolute channel value for stereo. Updated gain at or above
  one clamps to one and leaves that pair unscaled. No added hard saturation.
- Morph Designer's setup at `0x1402e7c10` enables this stage and resets gain
  when the Designer setup is rebuilt. Other recovered filter setups leave it off.

## Verification

`research/validate_runtime.py` generates references by running the original
x64 routines in Unicorn. `research/check_runtime.cpp` checks the C++ port.
The gain test enters the original detector loop directly, bypassing unrelated
sampler buffer methods. The original lag routine receives the selected table
reciprocal; the table-selection formula is additionally traced from disassembly.

MSVC /fp:strict comparisons passed bit-for-bit for 2,048 lag outputs and double
accumulators, 128 moving mono/stereo cascade cases (1/2/3/6 sections, four rates,
1/17/64/128-sample ramps, 10,080 output values), and 8,192 gain sample pairs
covering attack, recovery and stereo detection. `runtime-validation.json`
records these results. The older validation files describe the fixed cores and
retain their original exclusions; this supplement extends that coverage.

## Integration in JUCE VST3 0.3.0

The plugin now combines ControllerLag from emux_control.hpp with the recovered
MorphLag and coefficient ramps. Realtime Q uses ControllerLag and coefficient
ramps without extra MorphLag. At 44.1 kHz, the supplied controlled reference
recordings establish an 88-sample filter-update interval. The user's ASIO buffer
remains 256 samples. The exact X3 host setup/scheduling path remains untraced.
Other rates currently use an approximate grid in the JUCE wrapper; the reusable
components themselves accept an explicit control quantum.

The actual new VST3 matches the three actual-dry Ooh to Eee comparisons to
0.0011–0.0014% sustained waveform RMS error: offline/live Morph at Q50, and live
Realtime Resonance at Morph50/baseQ0. Live timing offsets were established in
prior analysis and held fixed for the plugin comparisons. These values are not
built into the library or plugin. There is no gain fitting or source reconstruction.
The earlier 0.2.0 fitted-input-ramp model has been replaced; its archived reports
remain historical evidence rather than the current implementation.

X3 motion starts on in new 0.3.0 instances. Off retains the initial prototype's
20 ms/16-sample behavior. Optional timestamped MIDI is used for the reference
comparisons; arbitrary host parameter automation still follows the pinned JUCE
wrapper's block handling. The original complete sampler release, alternative
SIMD paths, Hz/dB UI mapping, and dynamic accuracy for other filters/rates remain
outside the audio-verified scope. The shared source/playback response has not
been baked into the recovered coefficient banks.

## Live Ooh to Eee validation, 5 October 2026

The user-supplied detailed standalone trace validates 925,952 mono filter samples bit-for-bit across 3,617 contiguous blocks. Port-generated controller/Morph/accumulator values and all current/target/previous/increment coefficients also match. A continuous replay uses captured internal input and seeds filter state only once; it matches all outputs and final states. Base Q50%, realtime Q0%, 44.1kHz, 256-sample standalone interval, note 60 / velocity 127. The first 256 note samples are untraced. This does not establish complete bus/VST3 output equality or coverage of other filters/settings. Exact voice amplification and bus arithmetic are the next trace target. DSP binaries remain unchanged. See [the live trace report](research/ooh-live-trace/REPORT.md).

## Voice and bus recovery / version 0.5.0

The optional X3 mono reference output stage preserves original voice/master multiplication and accumulation order. It is off by default; all 48 earlier parameter IDs/order and ordinary effect renders are preserved. Voice and master level defaults reflect the traced session. Use with internal mono voice input, not an already-amplified No Filter bus WAV. Ooh to Eee and Peak/Shelf Morph Steps at Q50/44.1kHz/256 now match loaded VST3 held-note output bit-for-bit, including startup: 925,952 samples per take. Complete release/voice lifetime is still different. Generic voice and bus arithmetic passed 144 original-code reference cases. See [voice/bus validation](research/voice-mix-trace/REPORT.md).

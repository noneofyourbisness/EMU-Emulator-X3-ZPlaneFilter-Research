#pragma once
// Other original X3 setups. Raw programmable settings are 0..127, not Hz/dB.
// Load extracted tables outside the audio callback. See EXTENDED.md.
#include "emux_filters.hpp"
#include <algorithm>
#include <cstring>

namespace emux {
using PackedSection = std::array<std::uint16_t,5>;
using Frames = std::array<std::array<PackedSection,6>,4>;
struct Configuration { Coefficients coefficients{}; std::size_t sections = 0; };
struct PackedConfiguration { Frames frames{}; std::size_t sections = 0; float gain_factor = 4.0f; };
enum class MorphKind { dual_eq, dual_eq_lowpass, dual_eq_expression, peak_shelf };
enum class Shape : unsigned { off=0, eq=1, lowpass=2, highpass=3 };
using MorphParameters = std::array<unsigned,6>;
struct DesignerSection {
    Shape shape=Shape::off;
    unsigned start_frequency=32, start_gain=64, end_frequency=96, end_gain=64;
};

inline Configuration coefficients_from_frames(const PackedConfiguration& packed,
                                               float frequency, float resonance) {
    if (packed.sections>6) throw std::invalid_argument("Section count must be 0..6");
    frequency=normalized(frequency); resonance=normalized(resonance);
    Configuration out{}; out.sections=packed.sections;
    for (std::size_t s=0;s<out.sections;++s) {
        Section d{};
        for (unsigned j=0;j<5;++j) {
            auto lo=interpolate(packed.frames[0][s][j],packed.frames[1][s][j],frequency);
            auto hi=interpolate(packed.frames[2][s][j],packed.frames[3][s][j],frequency);
            d[j]=decode_word(interpolate(lo,hi,resonance));
        }
        out.coefficients[s]={4.0f*d[0]+d[1],d[1],4.0f*d[2]+d[3],d[3],packed.gain_factor*d[4]};
    }
    return out;
}

class ExtendedBank {
public:
    static ExtendedBank from_table_files(const std::string& standard, const std::string& support) {
        std::ifstream file(standard,std::ios::binary), f(support,std::ios::binary);
        if (!file || !f) throw std::runtime_error("Cannot open extended banks");
        return from_streams(file,f);
    }
    // Runtime construction from embedded data, outside the audio callback.
    static ExtendedBank from_streams(std::istream& file, std::istream& f) {
        ExtendedBank bank;
        for (unsigned i=0;i<17;++i) for (unsigned r=0;r<4;++r) {
            auto& p=bank.standard_[i][r]; p.sections=counts[i]; p.gain_factor=(i>=8 && i<=10)?5.0f:4.0f;
            for (auto& frame:p.frames) for (std::size_t s=0;s<p.sections;++s)
                for (auto& word:frame[s]) word=read16(file);
        }
        check_end(file);

        read32array(f,bank.morph_base_); read32array(f,bank.morph_slope_);
        read16array(f,bank.lp_); read16array(f,bank.expression_);
        read32array(f,bank.shelf_base_); read32array(f,bank.shelf_slope_);
        read16array(f,bank.neutral_);
        read32array(f,bank.designer_base_); read32array(f,bank.designer_slope_);
        // Two final IEEE binary32 values; assemble bits without alignment aliasing.
        auto a=read32(f), b=read32(f);
        std::memcpy(&bank.resonance_scale_,&a,4); std::memcpy(&bank.index_scale_,&b,4);
        check_end(f);
        return bank;
    }
    PackedConfiguration frames(unsigned filter,unsigned sample_rate=48000) const {
        if (filter>=17) throw std::invalid_argument("Standard filter index must be 0..16");
        return standard_[filter][rate(sample_rate)];
    }
    Configuration coefficients(unsigned filter,float frequency,float resonance,unsigned sample_rate=48000) const {
        return coefficients_from_frames(frames(filter,sample_rate),frequency,resonance);
    }
    PackedConfiguration morph_frames(MorphKind kind,const MorphParameters& p,
                                      float resonance,unsigned sample_rate=48000) const {
        for (auto v:p) validate_byte(v);
        const unsigned r=rate(sample_rate); resonance=normalized(resonance);
        if (kind==MorphKind::peak_shelf) return shelf(p,resonance,r);
        if (kind!=MorphKind::dual_eq && kind!=MorphKind::dual_eq_lowpass && kind!=MorphKind::dual_eq_expression)
            throw std::invalid_argument("Unknown morph kind");
        const int o=kind==MorphKind::dual_eq?offset(resonance):0;
        const int ga=clamp(s16((static_cast<int>(p[2])-64)*128+o*256),-8192,8191);
        const int gb=clamp(s16((static_cast<int>(p[5])-64)*128+o*256),-8192,8191);
        std::array<std::uint16_t,6> k{0xdfff,0xffff,0xdfff,0xdfff,0xffff,0xdfff};
        const auto index=static_cast<unsigned>(clamp(static_cast<int>(resonance*index_scale_),0,15));
        if (kind==MorphKind::dual_eq_lowpass) std::copy_n(lp_.begin()+index*6,6,k.begin());
        if (kind==MorphKind::dual_eq_expression) {
            std::copy_n(expression_.begin()+index*3,3,k.begin());
            std::copy_n(k.begin(),3,k.begin()+3);
        }
        PackedConfiguration out{}; out.sections=3;
        for (unsigned f=0;f<2;++f) {
            const auto fa=u16(morph_slope_[r]*p[f]+morph_base_[r]);
            const auto fb=u16(morph_slope_[r]*p[3+f]+morph_base_[r]);
            const auto ta=u16((fa>>1)+0x6400), tb=u16((fb>>1)+0x6400);
            out.frames[f][0]={fa,u16(ga+ta),k[f*3],k[f*3+1],k[f*3+2]};
            out.frames[f][1]={fb,u16(gb+tb),fa,u16(ta-ga),0xdfff};
            out.frames[f][2]={0xdfff,0xffff,fb,u16(tb-gb),0xdfff};
        }
        duplicate(out); return out;
    }
    Configuration morph_coefficients(MorphKind kind,const MorphParameters& p,float frequency,
                                      float resonance,unsigned sample_rate=48000) const {
        return coefficients_from_frames(morph_frames(kind,p,resonance,sample_rate),frequency,resonance);
    }
    PackedConfiguration designer_frames(const std::array<DesignerSection,6>& sections,
                                          float resonance,unsigned sample_rate=48000) const {
        const unsigned r=rate(sample_rate); const int o=offset(normalized(resonance));
        PackedConfiguration out{};
        for (const auto& s:sections) {
            if (static_cast<unsigned>(s.shape)>3) throw std::invalid_argument("Unknown designer shape");
            validate_byte(s.start_frequency); validate_byte(s.start_gain);
            validate_byte(s.end_frequency); validate_byte(s.end_gain);
            if (s.shape==Shape::off) continue;
            for (unsigned f=0;f<2;++f) {
                const unsigned rawfreq=f?s.end_frequency:s.start_frequency, rawgain=f?s.end_gain:s.start_gain;
                const int freq=static_cast<int>((designer_slope_[r]*rawfreq)>>7)+static_cast<int>(designer_base_[r]);
                const int gain=clamp(sar(static_cast<int>(rawgain)-64,1)+o,-32,31);
                int a=freq,b=clamp((freq*124>>8)+118+gain,0,255);
                int c=freq,d=clamp((freq*124>>8)+118-gain,0,255);
                std::uint16_t g=0xe000;
                if (s.shape==Shape::lowpass) {
                    a=r<2?236:225; b=r<2?255:240; g=u16((r<2?freq+245:freq)*256);
                } else if (s.shape==Shape::highpass) {
                    a=static_cast<int>(designer_base_[r]); b=(a*124>>8)+150;
                    if (r<2) {
                        g=u16(0xe000-(freq-18)*12);
                        if (freq>=220 && gain<0) c=220+sar(s16((freq-220)*(gain+32)),5);
                    }
                }
                out.frames[f][out.sections]={u16(a*256),u16(b*256),u16(c*256),u16(d*256),g};
            }
            ++out.sections;
        }
        if (out.sections>3 && out.sections<6) {
            for (auto& f:out.frames) for (std::size_t i=out.sections;i<6;++i) f[i]=neutral_;
            out.sections=6;
        }
        duplicate(out); return out;
    }
    Configuration designer_coefficients(const std::array<DesignerSection,6>& sections,float frequency,
                                         float resonance,unsigned sample_rate=48000) const {
        return coefficients_from_frames(designer_frames(sections,resonance,sample_rate),frequency,resonance);
    }
private:
    static constexpr std::array<unsigned,17> counts{1,2,3,1,2,1,2,1,1,1,1,2,2,2,3,3,3};
    std::array<std::array<PackedConfiguration,4>,17> standard_{};
    std::array<std::uint32_t,4> morph_base_{},morph_slope_{},shelf_base_{},shelf_slope_{},designer_base_{},designer_slope_{};
    std::array<std::uint16_t,96> lp_{};
    std::array<std::uint16_t,48> expression_{};
    PackedSection neutral_{};
    float resonance_scale_=-63.0f,index_scale_=16.0f;
    static int clamp(int v,int lo,int hi) { return std::max(lo,std::min(hi,v)); }
    static std::uint16_t u16(unsigned v) { return static_cast<std::uint16_t>(v); }
    static int s16(int v) { return static_cast<int>(static_cast<unsigned>(v+32768)&65535)-32768; }
    // Explicit arithmetic right shift, independent of C++17 signed-shift rules.
    static int sar(int v,unsigned n) { return v>=0?v/(1<<n):-((-v+(1<<n)-1)/(1<<n)); }
    int offset(float resonance) const { return -32-static_cast<int>(resonance*resonance_scale_); }
    static void validate_byte(unsigned v) { if (v>127) throw std::invalid_argument("Raw parameter must be 0..127"); }
    static unsigned rate(unsigned r) {
        switch(r) { case 44100:return 0;case 48000:return 1;case 96000:return 2;case 192000:return 3;
            default:throw std::invalid_argument("Unsupported sample rate"); }
    }
    static void duplicate(PackedConfiguration& p) { p.frames[2]=p.frames[0];p.frames[3]=p.frames[1]; }
    PackedConfiguration shelf(const MorphParameters& p,float resonance,unsigned r) const {
        PackedConfiguration out{}; out.sections=3;
        for (unsigned f=0;f<2;++f) {
            const int freq=static_cast<int>(p[f*3]), spread0=static_cast<int>(p[f*3+1]>>1)-32;
            const int spread=spread0-sar(spread0,2);
            const int gain=clamp(sar(static_cast<int>(p[f*3+2])-64,1)+offset(resonance),-32,31);
            const int center=clamp(static_cast<int>((shelf_slope_[r]*freq)>>7)+static_cast<int>(shelf_base_[r]),1+std::abs(spread),237-std::abs(spread));
            const int low=center-spread,high=center+spread;
            const auto gl=u16(clamp((low*124>>8)+gain+137,0,255)*256);
            const auto gh=u16(clamp((high*124>>8)-gain+137,0,255)*256);
            const auto sw=u16((std::min(sar(spread*freq,6),32)+207)*256);
            out.frames[f][0]={sw,0xdfff,sw,0xdfff,0xa000};
            out.frames[f][1]={u16(low*256),gl,0xdfff,0xffff,0xffff};
            out.frames[f][2]={0xdfff,0xffff,u16(high*256),gh,0xffff};
        }
        duplicate(out); return out;
    }
    static std::uint16_t read16(std::istream& f) {
        unsigned char b[2]; if (!f.read(reinterpret_cast<char*>(b),2)) throw std::runtime_error("Truncated bank");
        return static_cast<std::uint16_t>(b[0]|(b[1]<<8));
    }
    static std::uint32_t read32(std::istream& f) { const std::uint32_t a=read16(f),b=read16(f);return a|(b<<16); }
    template<std::size_t N> static void read16array(std::istream& f,std::array<std::uint16_t,N>& a) { for(auto& v:a)v=read16(f); }
    template<std::size_t N> static void read32array(std::istream& f,std::array<std::uint32_t,N>& a) { for(auto& v:a)v=read32(f); }
    static void check_end(std::istream& f) { if(f.get()!=std::char_traits<char>::eof())throw std::runtime_error("Incorrect bank length"); }
};
} // namespace emux

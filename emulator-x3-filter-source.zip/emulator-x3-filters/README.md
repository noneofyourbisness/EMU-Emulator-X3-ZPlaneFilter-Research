# Emulator X3 filter recovery: working research port

This package contains a newly written, reusable C++17 and Python implementation
of all 55 filter types in the installed Emulator X3 build: 33 twelve-pole factory
filters, 17 standard filters, and five programmable filters.
It recovers the actual packed-table interpolation, coefficient decoding and
scalar six-section audio recurrence. It is not a generic morphing-EQ approximation.

Initial offline recovery read the installed sampler without changing its files.
Later native diagnostics also attached to the running application on scratch
buffers. No licensing code or activation mechanism was modified. The library reads the user's own executable as data. Once its factory
bank is exported locally, the library can process audio without the application
installed or running. No executable or original coefficient-table payload is
included in the source archive.

The separate `factory-bank.bin` and `factory-bank.json` deliverables are the
locally extracted bank from your installed copy. Use the binary directly with
C++, or load the JSON with Python, to avoid reading the executable again.
The added standard and programmable paths use `extended-bank.json` in Python,
or `standard-bank.bin` and `morph-support.bin` in C++. See [EXTENDED.md](EXTENDED.md)
for their APIs, research findings and verification.

## What works

- All 33 factory filters from Ace of Bass through Klang Kling, including Ooh to
  Eee, Talking Hedz, Deep Bouche, MegaSweepz and BassBox 303.
- All 17 standard types: low/high/bandpass, contrary bandpass, three swept EQs,
  phasers, Bat Phaser, Flanger Lite and the two vowel filters.
- Dual EQ Morph, Dual EQ + LP Morph, Dual EQ Morph/Expression, Peak/Shelf Morph,
  and Morph Designer with independently programmable sections.
- The original tables for 44.1, 48, 96 and 192 kHz.
- Both normalized internal filter controls, independently variable over 0..1.
- Stateful mono processing; independent instances provide stereo processing.
- A C++ callback core that allocates no memory and performs no file access.
- A dependency-free Python reference implementation, optional conventional
  second-order-section conversion, local data export and an audible example.

The C++ code is standard C++17. Windows compilation has been tested with GCC
16.2.0 and MSVC 19.44.35229; other operating systems have not been tested here.

## What is not yet ported or verified

All 55 filter types' setup and fixed-control scalar processing paths are exposed.
This is still a subset of the complete sampler voice-processing system.

The recovered frequency accumulator, per-sample coefficient ramps and optional
adaptive gain now have C++ implementations in `emux_runtime.hpp`; see
[RUNTIME.md](RUNTIME.md). The complete modulation-source path, control scheduling,
alternative SIMD kernels, denormal policy and remaining voice processing are
still unverified. The older `Filter` API continues to apply coefficient changes
immediately; use the runtime helpers when building a moving cascade. Preserve
independent channel states and keep them across audio callbacks.

The tests establish equality to the isolated original scalar core, not complete
sound equality with a preset rendered through the entire sampler. UI slider
and MIDI mappings are not fully recovered. The supplied Ooh to Eee recordings
do corroborate its normalized Morph/Q controls, including the 64/127 midpoint.
Highly resonant filters may have large
gain; the processing core intentionally does not normalize or limit its output.

## Quick start: Python

Place `emux_filters.py` beside your code. It needs only Python's standard library.

```python
from emux_filters import FactoryBank, Filter, FACTORY_NAMES

bank = FactoryBank.from_executable(
    r"C:\Program Files\E-MU\Emulator X3\EmulatorX.exe"
)
coefficients = bank.coefficients(
    "Ooh to Eee", frequency=0.35, resonance=0.5, sample_rate=48000
)
filter = Filter(coefficients)
output_block = filter.process(input_block)  # input/output: mono float samples

# Export once, then use the JSON bank with Python on another platform.
bank.save("my-x3-bank.json")
# Export the packed data for the C++ implementation.
bank.save_binary("my-x3-bank.bin")
```

`FactoryBank.load("my-x3-bank.json")` needs no original executable. Factory names
use the strings from this installed application's resources. Numeric filter
indices run from 0 to 32 in the same order. `FACTORY_NAMES` lists them.

Generate the supplied kind of example with:

```text
python example.py --exe "C:\Program Files\E-MU\Emulator X3\EmulatorX.exe" --output demo.wav
python example.py --exe "C:\Program Files\E-MU\Emulator X3\EmulatorX.exe" --export-bank my-x3-bank.bin
```

The demo is one second of a dry 110 Hz saw followed by three seconds through Ooh
to Eee, sweeping the frequency/morph control with resonance at 0.5. It applies
one common post-gain to the entire clip. Its 64-sample control updates are an
example host policy, not recovered X3 modulation smoothing.

## Quick start: C++17

```cpp
#include "emux_filters.hpp"

auto bank = emux::FactoryBank::from_table_file("my-x3-bank.bin");
auto coefficients = bank.coefficients(10, 0.35f, 0.5f, 48000); // Ooh to Eee
emux::Filter left(coefficients), right(coefficients);

// In each callback: pointers to planar float audio, with frame_count samples.
left.process(input_left, output_left, frame_count);
right.process(input_right, output_right, frame_count);
```

Load the bank outside the audio callback. Configure valid, finite coefficients
and finite audio input. Compile GCC/Clang code with `-ffp-contract=off` and
without fast-math; use an equivalent non-contracting floating-point mode on other
compilers. The verified Windows build used:

```text
g++ -std=c++17 -O2 -ffp-contract=off -fno-fast-math
```

## Verification performed

Both Python and compiled C++ passed:

- 924 cases: 33 filters x four sample rates x seven control positions, including
  all four corners and three interior points.
- All 30 coefficients in each case.
- 59,136 output samples per implementation, using an impulse and deterministic
  low-level noise at fixed coefficients.
- All 65,536 possible packed coefficient words through the original conversion
  routine, including its zero and unity special cases.
- State continuity across split audio blocks in the C++ and Python comparisons.

The original factory-table copy, interpolation, conversion and mono six-section
audio routines were run in an isolated x86-64 CPU emulator with local memory.
Its standard `ldexp` math call was replaced by `math.ldexp`. The sampler process,
audio driver and activation system were not involved. Python outputs matched
the emulated original routine bit-for-bit in IEEE binary32; compiled C++ matched
those validated references bit-for-bit. Maximum absolute audio difference in
these test vectors was zero. These short, fixed-control tests are not a proof of
behavior for every possible input, long run, compiler or modulation trajectory.

Details are in `validation.json`. Executable identity and symbols are recorded
in `binary-inventory.json`, `filter-strings.json` and `filter-vtables.json`.
The source archive also includes the scripts needed to reproduce this analysis
and verification against the supported executable, with workspace-only
dependencies documented in `research/REPRODUCE.md`.
The extension additionally passed 3,156 cases and 201,984 audio samples per
implementation across all four sample rates, with exact packed-frame comparisons
and bit-for-bit coefficients/audio. See `extended-validation.json`.

## Recovered structure

The factory setup routine at preferred VA `0x1402ed880` indexes table VA
`0x1406f6030` by `(filter_index * 4 + sample_rate_index) * 240` bytes. Each record
contains six sections, each with four frames of five unsigned 16-bit words.
The 33 x four records occupy 31,680 bytes and end at `0x1406fdbf0`, immediately
before another virtual-table region.

The copy routine transposes stage-major records into four contiguous frames in
the voice. The interpolation routine at `0x1402cf470` interpolates the packed
words along frequency first and resonance second, truncating each result. The
converter at `0x1402ced30` decodes a custom mantissa/exponent format, then combines
decoded values into five stage coefficients. Decoding before interpolation
changes the sound and is not equivalent.

The recovered state recurrence from mono kernel `0x1402ccc80` is:

```text
t = s2*c3 - s1*c2 + input
output = (s1*c0 + t - s2*c1)*gain
s1_next = 2*s1 + t - s2
s2_next = s1
```

The order and float rounding of each operation matter. In conventional
second-order-section notation the equivalent numerator is
`gain * [1, c0-2, 1-c1]` and the denominator is `[1, c2-2, 1-c3]`.

## Supported source build

- File: the user-specified `EmulatorX.exe`, 33,638,400 bytes.
- Native architecture: AMD64 / 64-bit PE.
- Version resource: 3.0.64.606.
- SHA-256: `6f342c6057a8a0fb69f021a0da46adbab7f5a332139a2ee3a9506c9fa84e6914`.

Extraction refuses any other executable fingerprint because static offsets may
differ. Supporting another build requires independently locating its tables and
verifying its routines. No conclusion was drawn about the provenance or license
status of this particular installed build.

## Documentation context

The installed E-MU X3 manual describes 55 filter choices, factory filters up to
12th order, and a Morph Designer with six programmable sections (pp. 145-153).
Its local readme documents one-time internet/email activation and Windows XP /
Vista support. This investigation did not independently establish the current
availability of activation services.

Public references:

- [E-MU Emulator X3 reference manual (vendor-authored PDF mirror)](https://images.thomann.de/pics/prod/227599_manual.pdf).
- [Dave Rossum's dynamic IIR filter patent US5170369A](https://patents.google.com/patent/US5170369A/en).
The reconstruction uses the installed X3 executable and original E-MU material.
The modern Eurorack Morpheus documentation is excluded as a reference for X3 or
the original E-MU H-chip.

## Runtime update

The reusable C++ motion and adaptive-gain components are in `emux_runtime.hpp`.
See [RUNTIME.md](RUNTIME.md) for original-instruction validation, the VST3 0.2.0
reference-step improvement, and the remaining control-path uncertainty.

## Controller and JUCE 0.3.0 update

`emux_control.hpp` adds the recovered fixed-speed controller slew and ordinary
7-bit MIDI normalization. It is the same header embedded in the JUCE VST3.
`control-validation.json` and `research/control-vectors.bin` contain the original
EXE/DLL instruction references: 9,216 ticks, 78 desktop selector cases, and 128
MIDI values. Compile `research/check_control_trace.cpp` and run from `research/`
to check them. The selector is a recovered desktop setup path, not a guarantee
of the active filter interval inside every VST host.

The JUCE 0.3.0 wrapper combines controller slew with MorphLag for Morph, and
controller slew without additional MorphLag for realtime Q. Both feed recovered
coefficient ramps. The supplied 44.1 kHz recordings match an 88-sample control
grid, independent of the user's 256-sample host buffer. The built VST3 now matches
the three controlled reference recordings to 0.0011–0.0014% sustained waveform
RMS error. This validates those cases; host MIDI timing and complete sampler
behavior remain separate concerns. Capture-specific offsets are not built into
the reusable DSP or plugin. See the JUCE source's current RUNTIME.md and validation.

## JUCE 0.4.0 and same-voice diagnostics

`emux_sweep_timing.hpp` is now used by the actual VST3 with selectable FL reference
(88 at 44.1 kHz) and Standalone (256 at 44.1 kHz) clocks. All 165 standalone
filtered sustained renders match the corrected core bit-for-bit. The separate
harness has one-button batch capture and an optional same-voice kernel trace.
`Filter::State`, `state()` and `restore_state()` allow diagnostic replays using
captured initial state, without changing normal sample processing. See the JUCE
0.4.0 comparison report and harness TRACE.md for verification limits.

## Live Ooh to Eee validation, 5 October 2026

The user-supplied detailed standalone trace validates 925,952 mono filter samples bit-for-bit across 3,617 contiguous blocks. Port-generated controller/Morph/accumulator values and all current/target/previous/increment coefficients also match. A continuous replay uses captured internal input and seeds filter state only once; it matches all outputs and final states. Base Q50%, realtime Q0%, 44.1kHz, 256-sample standalone interval, note 60 / velocity 127. The first 256 note samples are untraced. This does not establish complete bus/VST3 output equality or coverage of other filters/settings. Exact voice amplification and bus arithmetic are the next trace target. DSP binaries remain unchanged. See [the live trace report](research/ooh-live-trace/REPORT.md).

## Voice and bus recovery / version 0.5.0

The optional X3 mono reference output stage preserves original voice/master multiplication and accumulation order. It is off by default; all 48 earlier parameter IDs/order and ordinary effect renders are preserved. Voice and master level defaults reflect the traced session. Use with internal mono voice input, not an already-amplified No Filter bus WAV. Ooh to Eee and Peak/Shelf Morph Steps at Q50/44.1kHz/256 now match loaded VST3 held-note output bit-for-bit, including startup: 925,952 samples per take. Complete release/voice lifetime is still different. Generic voice and bus arithmetic passed 144 original-code reference cases. See [voice/bus validation](research/voice-mix-trace/REPORT.md).

## Release/control source trace, 5 October 2026

`emux_voice_control.hpp` and `emux_voice_tables.hpp` add recovered amplitude/pan, cord transfer, normal volume release and sample-player keep/remove components. They pass 10,860 original-instruction cases / 46,890 values with zero bit differences. Four live downstream audio replays also match exactly in their covered windows, using captured post-filter input. The shipped VST3 remains 0.5.0 and its binary is unchanged; these controls are not yet wired into effect processing. Complete sample playback/lifetime and arbitrary presets remain unverified. See [the scoped report](research/release-control-trace/REPORT.md) and [next captures](research/release-control-trace/NEXT-CAPTURES.md).

## Q extremes, 5 October 2026

Two complete user Steps batches add Q0/Q100 coverage: 110 filtered loaded-VST3 comparisons have median held-note waveform errors of 0.000952% and 0.001980%, with maxima 0.021961% and 0.067164%. The No Filter takes are bit-identical. Direct Q readback awaits separate detailed traces; these are bus-input effect comparisons, not full sampler bit-exactness. DSP and VST3 remain unchanged at 0.5.0. See [the scoped Q report](research/q-extreme-validation/REPORT.md).

## Native attached filter tests, 5 October 2026

Direct calls to the original running X3 and these C++ DSP headers passed all 55 filter types: 7,040 sequences, 119,680 blocks and 17,793,600 output float samples, with zero bit differences in setup frames, gains, coefficients, ramps, audio and carried state. Coverage includes four sample-rate table selections, distinct stereo and active programmable frames. A deliberate one-bit negative control was detected correctly. This establishes tested filter-core equivalence; controller scheduling and the complete sampler/host signal chain remain separate. The released VST3 remains 0.5.0. See [the native comparison report](research/direct-filter-tests/REPORT.md). The separate X3-Direct-Filter-Tester.zip automates this without WAV captures.

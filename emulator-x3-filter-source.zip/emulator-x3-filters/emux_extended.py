"""Remaining X3 filter setups; uses X3 data, not modern module documentation.

Programmable settings are raw X3 parameter bytes (0..127), not Hz/dB.
See EXTENDED.md for scope and verification. No third-party dependencies.
"""
import json
from pathlib import Path
from emux_filters import (SUPPORTED_SHA256, SAMPLE_RATES, f32, decode_word,
                          _control, _lerp_word)

STANDARD_NAMES = (
    '2 Pole Lowpass', '4 Pole Lowpass', '6 Pole Lowpass', '2 Pole Highpass',
    '4 Pole Highpass', '2 Pole Bandpass', '4 Pole Bandpass', 'Contrary Bandpass',
    'Swept EQ 1 Octave', 'Swept EQ 2/1 Octave', 'Swept EQ 3/1 Octave',
    'Phaser 1', 'Phaser 2', 'Bat Phaser', 'Flanger Lite', 'Vocal Ah-Ay-Ee',
    'Vocal Oo-Ah')
PROGRAMMABLE_NAMES = ('Dual EQ Morph', 'Dual EQ + LP Morph',
    'Dual EQ Morph/Expression', 'Peak/Shelf Morph', 'Morph Designer')

def _rate(sample_rate):
    if sample_rate not in SAMPLE_RATES: raise ValueError('Unsupported sample rate')
    return SAMPLE_RATES.index(sample_rate)

def _bytes(values, count):
    values = tuple(values)
    if len(values) != count or any(type(v) is not int or not 0 <= v <= 127 for v in values):
        raise ValueError(f'Expected {count} raw X3 parameter bytes in 0..127')
    return values

def _clamp(x, lo, hi): return max(lo, min(hi, x))
def _u16(x): return x & 65535
def _s16(x): return ((x + 32768) & 65535) - 32768

def coefficients_from_frames(frames, frequency=.5, resonance=.5, gain_factor=4.0):
    """Interpolate packed words before decoding; supports zero to six sections."""
    frequency, resonance = _control(frequency), _control(resonance)
    if len(frames) != 4 or len(frames[0]) > 6 or any(len(f) != len(frames[0]) for f in frames):
        raise ValueError('Expected four frames with equal section counts, at most six')
    result = []
    for s in range(len(frames[0])):
        words = []
        for j in range(5):
            lo = _lerp_word(frames[0][s][j], frames[1][s][j], frequency)
            hi = _lerp_word(frames[2][s][j], frames[3][s][j], frequency)
            words.append(_lerp_word(lo, hi, resonance))
        d = [decode_word(w) for w in words]
        result.append((f32(f32(4*d[0])+d[1]), d[1],
                       f32(f32(4*d[2])+d[3]), d[3], f32(gain_factor*d[4])))
    return result

class ExtendedBank:
    def __init__(self, data):
        if data.get('format') != 'emux-extended-v1' or data.get('source_sha256') != SUPPORTED_SHA256:
            raise ValueError('Unrecognized extended bank format or provenance')
        if tuple(f['name'] for f in data['filters']) != STANDARD_NAMES:
            raise ValueError('Incorrect standard filter list')
        self.data = data
        self.support = data['support']

    @classmethod
    def load(cls, path):
        return cls(json.loads(Path(path).read_text(encoding='utf-8')))

    def frames(self, filter_id, sample_rate=48000):
        if isinstance(filter_id, str): filter_id = STANDARD_NAMES.index(filter_id)
        if type(filter_id) is not int or not 0 <= filter_id < 17:
            raise ValueError('Standard filter index must be 0..16')
        return self.data['filters'][filter_id]['frames'][_rate(sample_rate)]

    def coefficients(self, filter_id, frequency=.5, resonance=.5, sample_rate=48000):
        if isinstance(filter_id, str): filter_id = STANDARD_NAMES.index(filter_id)
        frames = self.frames(filter_id, sample_rate)
        return coefficients_from_frames(frames, frequency, resonance,
            self.data['filters'][filter_id]['gain_factor'])

    def _offset(self, resonance):
        return -32 - int(f32(_control(resonance)*self.support['resonance_scale']))

    def morph_frames(self, kind, parameters=(32,96,64,48,112,64), resonance=.5, sample_rate=48000):
        """Six bytes: A frequency start/end, A gain, B frequency start/end, B gain.

        Peak/Shelf uses: start frequency/shelf/peak, end frequency/shelf/peak.
        Frequency is the continuous morph between these frames. Resonance also
        rebuilds the frames, so call again when that control changes.
        """
        p = _bytes(parameters,6)
        r = _rate(sample_rate)
        resonance = _control(resonance)
        if kind == 'Peak/Shelf Morph': return self._shelf(p, resonance, r)
        if kind not in PROGRAMMABLE_NAMES[:3]: raise ValueError('Unknown morph filter')
        offset = self._offset(resonance) if kind == 'Dual EQ Morph' else 0
        gain_a = _clamp(_s16(((p[2]-64)<<7)+(offset<<8)), -8192,8191)
        gain_b = _clamp(_s16(((p[5]-64)<<7)+(offset<<8)), -8192,8191)
        if kind == 'Dual EQ Morph': constants = [0xdfff,0xffff,0xdfff]*2
        else:
            index = _clamp(int(f32(resonance*self.support['index_scale'])),0,15)
            if kind == 'Dual EQ + LP Morph': constants = self.support['lp_morph'][index*6:index*6+6]
            else: constants = self.support['expression'][index*3:index*3+3]*2
        frames=[]
        for frame in range(2):
            fa = _u16(self.support['morph_slope'][r]*p[frame]+self.support['morph_base'][r])
            fb = _u16(self.support['morph_slope'][r]*p[3+frame]+self.support['morph_base'][r])
            ta,tb = _u16((fa>>1)+0x6400), _u16((fb>>1)+0x6400)
            frames.append([[fa,_u16(gain_a+ta),*constants[frame*3:frame*3+3]],
                [fb,_u16(gain_b+tb),fa,_u16(ta-gain_a),0xdfff],
                [0xdfff,0xffff,fb,_u16(tb-gain_b),0xdfff]])
        return frames+frames

    def morph_coefficients(self, kind, parameters=(32,96,64,48,112,64),
                           frequency=.5, resonance=.5, sample_rate=48000):
        return coefficients_from_frames(self.morph_frames(kind,parameters,resonance,sample_rate),
                                        frequency,resonance)

    def _shelf(self, p, resonance, r):
        frames=[]
        for frame in range(2):
            freq,shelf,peak = p[frame*3:frame*3+3]
            gain = _clamp(((peak-64)>>1)+self._offset(resonance),-32,31)
            spread = (shelf>>1)-32
            spread -= spread>>2
            center = (self.support['shelf_slope'][r]*freq>>7)+self.support['shelf_base'][r]
            center = _clamp(center,1+abs(spread),237-abs(spread))
            low,high = center-spread,center+spread
            gl = _clamp((low*124>>8)+gain+137,0,255)
            gh = _clamp((high*124>>8)-gain+137,0,255)
            shelf_word = _u16((min(spread*freq>>6,32)+207)<<8)
            frames.append([[shelf_word,0xdfff,shelf_word,0xdfff,0xa000],
                [_u16(low<<8),gl<<8,0xdfff,0xffff,0xffff],
                [0xdfff,0xffff,_u16(high<<8),gh<<8,0xffff]])
        return frames+frames

    def designer_frames(self, sections, resonance=.5, sample_rate=48000):
        """Up to six (shape, start_frequency, start_gain, end_frequency, end_gain).

        Shape is 'off', 'eq', 'lowpass', 'highpass', or integer 0..3. Other values
        are raw bytes 0..127. X3 compacts active sections and pads four/five to six.
        """
        sections = list(sections)
        if len(sections)>6: raise ValueError('At most six designer sections')
        r = _rate(sample_rate)
        offset = self._offset(resonance)
        frames=[[],[]]
        shapes={'off':0,'eq':1,'lowpass':2,'highpass':3}
        for row in sections:
            if len(row)!=5: raise ValueError('Expected five fields per designer section')
            shape=shapes.get(row[0],row[0])
            if type(shape) is not int or not 0<=shape<=3: raise ValueError('Unknown shape')
            p=_bytes(row[1:],4)
            if not shape: continue
            for frame in range(2):
                freq=(self.support['designer_slope'][r]*p[frame*2]>>7)+self.support['designer_base'][r]
                gain=_clamp(((p[frame*2+1]-64)>>1)+offset,-32,31)
                a,b=freq,_clamp((freq*124>>8)+118+gain,0,255)
                c,d=freq,_clamp((freq*124>>8)+118-gain,0,255)
                g=0xe000
                if shape==2:
                    a,b=(236,255) if r<2 else (225,240)
                    g=_u16(((freq+245) if r<2 else freq)<<8)
                elif shape==3:
                    a=self.support['designer_base'][r]
                    b=(a*124>>8)+150
                    if r<2:
                        g=_u16(0xe000-(freq-18)*12)
                        if freq>=220 and gain<0: c=220+(_s16((freq-220)*(gain+32))>>5)
                frames[frame].append([_u16(a<<8),_u16(b<<8),_u16(c<<8),_u16(d<<8),g])
        if 3<len(frames[0])<6:
            for frame in frames:
                frame.extend([list(self.support['neutral']) for _ in range(6-len(frame))])
        return frames+frames

    def designer_coefficients(self, sections, frequency=.5, resonance=.5, sample_rate=48000):
        return coefficients_from_frames(self.designer_frames(sections,resonance,sample_rate),frequency,resonance)

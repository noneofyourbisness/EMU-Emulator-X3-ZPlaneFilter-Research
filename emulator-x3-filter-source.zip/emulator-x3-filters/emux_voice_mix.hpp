#pragma once
#include <array>
#include <cstddef>
namespace emux {
// Original 0x1402e8860: binary32 endpoint difference, binary64 inverse
// block length multiplication, binary32 increment; use old weight before add.
class VoiceMixRamp {
public:
 using Weights=std::array<float,4>;
 void prepare(Weights previous,Weights target,double inverseFrames) noexcept {
  weights_=previous;
  for(unsigned i=0;i<4;++i) {
   const float difference=target[i]-previous[i];
   increments_[i]=static_cast<float>(static_cast<double>(difference)*inverseFrames);
  }
 }
 void accumulate(float left,float right,bool stereo,float& busLeft,float& busRight) noexcept {
  float outLeft=left*weights_[0],outRight;
  if(stereo) {
   const float crossLeft=right*weights_[3];outLeft=crossLeft+outLeft;
   const float crossRight=left*weights_[2];const float ownRight=right*weights_[1];outRight=crossRight+ownRight;
  } else outRight=left*weights_[1];
  // Bus virtual +0x30, 0x1402d2b80: each voice is added separately.
  busLeft=outLeft+busLeft;busRight=outRight+busRight;
  for(unsigned i=0;i<4;++i)weights_[i]+=increments_[i];
 }
 const Weights& weights() const noexcept { return weights_; }
private:
 Weights weights_{},increments_{};
};
// Stereo bus 0x1402fac50 uses two interleaved frames per SIMD iteration.
// The two gain lanes advance independently by float(2*increment).
class StereoBusGainRamp {
public:
 void prepare(float previous,float increment) noexcept {
  even_=previous;odd_=previous+increment;stride_=increment*2.0f;phase_=false;
 }
 void accumulate(float left,float right,float& destLeft,float& destRight) noexcept {
  const float gain=phase_?odd_:even_;
  const float l=left*gain,r=right*gain;destLeft=l+destLeft;destRight=r+destRight;
  if(phase_) { even_+=stride_;odd_+=stride_; }phase_=!phase_;
 }
private:
 float even_=1,odd_=1,stride_=0;bool phase_=false;
};
// Fixed mono reference levels. Preserve the two multiplications and two bus
// additions; replacing them with a product gain changes rounding.
inline float mono_voice_reference_output(float sample,float voiceWeight,float masterGain) noexcept {
 const float voice=sample*voiceWeight;
 const float voiceBus=voice+0.0f;
 const float mastered=voiceBus*masterGain;
 return mastered+0.0f;
}
} // namespace emux

# Additional original X3 filters

The extension adds all 22 remaining filter types to the original 33-filter port.
The executable and installed E-MU X3 manual are the implementation references.
No current Eurorack Morpheus documentation or coefficients are used. This work
reconstructs X3's software DSP; it does not claim bit-exact emulation of an
original E-MU hardware H-chip.

## Coverage

| Group | Types | Sections |
|---|---|---|
| Lowpass | 2, 4, 6 Pole | 1, 2, 3 |
| Highpass | 2, 4 Pole | 1, 2 |
| Bandpass | 2, 4 Pole; Contrary Bandpass | 1, 2, 1 |
| Swept EQ | 1 Octave, 2/1 Octave, 3/1 Octave | 1 |
| Phaser | Phaser 1, Phaser 2, Bat Phaser | 2 |
| Other standard | Flanger Lite, Vocal Ah-Ay-Ee, Vocal Oo-Ah | 3 |
| Programmable | Dual EQ Morph, Dual EQ + LP Morph, Dual EQ Morph/Expression, Peak/Shelf Morph | 3 |
| Designer | Morph Designer: off/EQ/lowpass/highpass per section | 0–6 |

These counts refer to second-order sections. The separate legacy resource labels
“Flanger” and “Low Shelf” were not treated as additional documented X3 choices.
Zero active Designer sections provide bypass. For four or five active sections,
X3 pads to six with its own neutral packed section; the port retains that padding.

## Python

Place `emux_filters.py`, `emux_extended.py` and `extended-bank.json` beside your
application. No executable, CPU emulator or Windows APIs are needed at runtime.

```python
from emux_filters import Filter
from emux_extended import ExtendedBank, STANDARD_NAMES, PROGRAMMABLE_NAMES

bank = ExtendedBank.load("extended-bank.json")
coefficients = bank.coefficients("Vocal Ah-Ay-Ee", .35, .65, 48000)
audio_filter = Filter(coefficients)
output_block = audio_filter.process(input_block)

# Raw parameter bytes: A start frequency, A end frequency, A gain,
#                      B start frequency, B end frequency, B gain.
coefficients = bank.morph_coefficients(
    "Dual EQ Morph", (32, 96, 64, 48, 112, 64),
    frequency=.4, resonance=.5, sample_rate=48000)
audio_filter.set_coefficients(coefficients)

# Shape, start frequency, start gain/Q, end frequency, end gain/Q.
sections = [
    ("eq", 32, 80, 96, 64),
    ("lowpass", 96, 64, 48, 80),
    ("highpass", 12, 64, 24, 64),
]
coefficients = bank.designer_coefficients(sections, .4, .5, 48000)
```

For Peak/Shelf Morph the six bytes instead mean start frequency/shelf/peak,
followed by end frequency/shelf/peak. All these stored settings are integers
0..127. They are **not Hz or dB values**. The library's `frequency` argument is
the continuous morph control, normalized 0..1. Exact UI display conversion is
not recovered here. Resonance can rebuild programmable frames; recalculate
coefficients whenever it changes.

## C++17

```cpp
#include "emux_extended.hpp"

auto bank = emux::ExtendedBank::from_table_files(
    "standard-bank.bin", "morph-support.bin");
auto config = bank.coefficients(15, .35f, .65f, 48000); // Vocal Ah-Ay-Ee
emux::Filter left(config.coefficients, config.sections);
left.process(input_left, output_left, frame_count);

emux::MorphParameters p{32,96,64,48,112,64};
config = bank.morph_coefficients(emux::MorphKind::dual_eq, p, .4f, .5f, 48000);
left.set_coefficients(config.coefficients, config.sections);

std::array<emux::DesignerSection,6> sections{}; // Unused entries default to off.
sections[0] = {emux::Shape::eq,32,80,96,64};
sections[1] = {emux::Shape::lowpass,96,64,48,80};
config = bank.designer_coefficients(sections, .4f, .5f, 48000);
```

The standard indices are the order listed in Python `STANDARD_NAMES`, 0..16.
Supply the returned section count to `Filter`; its default six-section behavior
is retained for the original factory API. Independent instances provide stereo.
Load the bank outside callbacks. Processing and setup calculations allocate no
memory. Keep fast-math disabled and use `-ffp-contract=off` on GCC/Clang.

## Findings from X3

All standard types use the existing packed-word interpolation and coefficient
decoder. Their setups provide one, two or three sections. The three swept EQs
use a gain factor of **5**, whereas the other recovered paths use **4**.

Dual EQ variants share the helper at `0x1402e7030`. The frequency settings build
two frames from sample-rate-specific integer base/slope tables. The lowpass and
expression variants select among **16 discrete constant sets** using the
resonance control. Dual EQ Morph instead adds a packed gain offset. Peak/Shelf
Morph constructs separate shelf and peak sections with bounded cutoff spacing.

Morph Designer at `0x1402e7c10` accepts six descriptors starting at parameter
offset `0x20`, with six bytes per descriptor. Its active shapes are 1=EQ,
2=lowpass, 3=highpass; 0 skips the descriptor. Highpass and lowpass setups differ
between 44.1/48 kHz and 96/192 kHz. Active sections are compacted in order.

Programmable EQ/Q offsets depend on the internal resonance value through
`-32 - trunc(float32(resonance * -63))`. The port retains integer truncation,
signed shifts, packed 16-bit wrapping, and interpolation-before-decoding.

| Setup | Preferred virtual address |
|---|---|
| Standard types | `0x1402e6200` through `0x1402e6f50`; exact entries in bank JSON |
| Dual EQ Morph | `0x1402e73e0` |
| Dual EQ + LP Morph | `0x1402e74c0` |
| Dual EQ Morph/Expression | `0x1402e7590` |
| Peak/Shelf Morph | `0x1402e76a0` |
| Morph Designer | `0x1402e7c10` |
| Mono kernels: 1 / 2 / 3 / 6 sections | `0x1402cbed0` / `0x1402cc200` / `0x1402cc690` / `0x1402ccc80` |

`standard-bank.bin` stores each filter, then each sample rate, then four frames,
active sections and five little-endian words. It contains 4,960 bytes.
`morph-support.bin` contains the frequency mappings, lowpass/expression constants,
neutral section and two control scales, in the order in `recover_extended.py`.
It contains 402 bytes. `extended-bank.json` holds both sets with metadata.

## Verification and limits

The extension passed **3,156 cases**, comparing setup frames exactly and scalar
coefficients/audio bit for bit against emulated original x86-64 routines:

- 476 cases for 17 standard types at four rates and seven control positions.
- 2,080 cases for the four programmable morph variants, including boundary
  parameter values, deterministic random settings and the resonance selector.
- 600 Morph Designer cases, including all shapes, zero to six active sections,
  mixed shapes and four/five-section padding.
- 201,984 audio samples per implementation, using impulse/noise input.
- C++ split-block processing and reset checks for every case.

Details are in `extended-validation.json`. These are fixed-control, isolated
core comparisons. Full sampler renders, alternative SIMD paths, coefficient
ramps, denormal handling, and the optional adaptive gain stage remain unverified.
Morph Designer enables that separate adaptive gain stage in X3; the library
currently implements its filter cascade only. Tests do not prove arbitrary
long-run stability or exact behavior during rapid modulation. Parameter changes
are immediate, and hosts must supply their own smoothing.

## Original E-MU context

The installed X3 manual's printed pp. 145–153 describe the filter choices and
programmable controls. It is the matching product reference; a
[vendor-authored PDF mirror](https://images.thomann.de/pics/prod/227599_manual.pdf)
is listed for access, while the installed manual was used for this investigation.

Rossum's original E-MU-assigned
[1992 dynamic IIR patent, US5170369A](https://patents.google.com/patent/US5170369A/en),
describes a modified recursive structure, compressed coefficient encoding,
and interpolation of approximately logarithmically encoded coefficients. Those
ideas provide historical context for the recovered X3 structure. The patent
does not establish X3's exact implementation or the arithmetic behavior of a
particular H-chip revision. The actual packed formats, tables, section counts
and rounding in this library come from the supplied X3 executable.

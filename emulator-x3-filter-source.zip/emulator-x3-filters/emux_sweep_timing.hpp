#pragma once
#include "emux_control.hpp"
#include "emux_runtime.hpp"

namespace emux {
// Recovered positive Mod Wheel -> Morph path. Call tick() exactly once per
// selected X3 synthesis/control interval, after delivering MIDI for that tick.
// A host's audio buffer size and X3's interval are separate quantities.
// Coefficient evaluation and RampedStereoFilter::ramp_to(..., quantum) follow
// this stage. The coefficient ramp processes its old value before adding delta.
class SweepTiming {
public:
    void prepare(double rate,unsigned quantum,float initial=0) noexcept {
        controller_.prepare(rate,quantum,initial);
        morph_.prepare(rate,quantum,initial);
        target_=position_=initial;moving_=false;
    }
    void set_target(float value) noexcept {
        if(value!=target_) {
            target_=value;controller_.set_target(value);moving_=true;
        }
    }
    void set_midi_cc7(unsigned value) noexcept { set_target(midi_cc7(value)); }
    float tick() noexcept {
        const float driver=controller_.tick();
        if(moving_)position_=morph_.tick(driver);
        return position_;
    }
    float controller_value() const noexcept { return controller_.value(); }
    float controller_step() const noexcept { return controller_.step(); }
    float morph_divisor() const noexcept { return morph_.divisor(); }
    double accumulator() const noexcept { return morph_.accumulator(); }
private:
    ControllerLag controller_;MorphLag morph_;
    float target_=0,position_=0;bool moving_=false;
};
} // namespace emux

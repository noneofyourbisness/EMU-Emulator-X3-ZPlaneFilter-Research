#pragma once
#include <algorithm>
#include <cstdint>

namespace emux {
// Normal MIDI handler: integer -> double * (1/127) -> binary32.
inline float midi_cc7(unsigned value) noexcept {
    return static_cast<float>(static_cast<double>(std::min(value,127u)) * (1.0 / 127.0));
}

// CPhantomRTCCLag, original routine 0x1402ea3f0. Call once per
// original control tick, BEFORE evaluating modulation cords and MorphLag.
// A new target retains the current value: this is a slew limiter, not a
// fixed-duration ramp restarted for every MIDI message.
// Supported timing: positive rate/quantum, quantum/sampleRate <= .012.
class ControllerLag {
public:
    void prepare(double sampleRate, unsigned quantum, float value=0) noexcept {
        const double tickSeconds = static_cast<double>(quantum) / sampleRate;
        const double entry1 = std::min(1.0, tickSeconds / .012);
        const double entry2 = std::min(1.0, tickSeconds / .024);
        const double position = 255.0 / 128.0;
        step_ = static_cast<float>(entry1 + (entry2-entry1)*(position-1.0));
        reset(value);
    }
    void reset(float value) noexcept { value_=target_=value; active_=false; }
    void set_target(float value) noexcept { target_=value; active_=true; }
    float tick() noexcept {
        if (!active_) return value_;
        if (value_ < target_) {
            value_ += step_;
            if (value_ >= target_) { value_=target_; active_=false; }
        } else if (value_ > target_) {
            value_ -= step_;
            if (value_ <= target_) { value_=target_; active_=false; }
        } else active_=false;
        return value_;
    }
    float value() const noexcept { return value_; }
    float step() const noexcept { return step_; }
    bool active() const noexcept { return active_; }
private:
    float value_=0, target_=0, step_=1;
    bool active_=false;
};

// Recovered desktop audio setup selector 0x1401f9280, for positive
// buffer sizes and sample rates. This is evidence of a setup path, not
// a guarantee that the X3 VST wrapper uses the same selected quantum.
inline unsigned desktop_control_quantum(unsigned buffer, unsigned rate) noexcept {
    if (!buffer || !rate) return 0;
    unsigned candidate = buffer - buffer%4;
    const double secondsPerSample = 1.0 / static_cast<double>(rate);
    if (static_cast<double>(buffer)*secondsPerSample <= .01) return candidate;
    for (unsigned divisor=8; divisor<2008; divisor+=4) {
        if (buffer%divisor) continue;
        candidate=buffer/(divisor/4);
        if (static_cast<double>(candidate)*secondsPerSample <= .01) return candidate;
    }
    return candidate;
}
} // namespace emux

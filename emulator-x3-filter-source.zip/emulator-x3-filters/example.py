r"""Generate a small audible demo and optionally export your local filter bank.

python example.py --exe "C:\Program Files\E-MU\Emulator X3\EmulatorX.exe" --output demo.wav
python example.py --exe "..." --export-bank my-bank.bin
"""
import argparse
import math
from pathlib import Path
import struct
import wave
from emux_filters import FactoryBank,Filter,SAMPLE_RATES

def main():
    parser=argparse.ArgumentParser(description='Recovered X3 filter-core example')
    source=parser.add_mutually_exclusive_group(required=True)
    source.add_argument('--exe',help='Path to the supported local EmulatorX.exe')
    source.add_argument('--bank-json',help='Previously exported bank from FactoryBank.save()')
    parser.add_argument('--export-bank',help='Export the raw little-endian bank for C++')
    parser.add_argument('--output',help='Write a mono 16-bit WAV demo')
    args=parser.parse_args()
    if not args.export_bank and not args.output:
        parser.error('Specify --export-bank and/or --output')
    bank=FactoryBank.from_executable(args.exe) if args.exe else FactoryBank.load(args.bank_json)
    if args.export_bank:
        bank.save_binary(args.export_bank)
        print('Exported bank:',args.export_bank)
    if not args.output: return
    rate=48000
    # One second dry saw, then three seconds through Ooh to Eee. Modulation is
    # explicit 64-sample coefficient updates, not the sampler's smoothing.
    source=[0.01*(2.0*((i*110/rate)%1.0)-1.0) for i in range(rate*4)]
    result=source[:rate]
    filt=Filter(bank.coefficients('Ooh to Eee',0.0,0.5,rate))
    for offset in range(rate,rate*4,64):
        frequency=(offset-rate)/(rate*3-1)
        filt.set_coefficients(bank.coefficients('Ooh to Eee',frequency,0.5,rate))
        result.extend(filt.process(source[offset:offset+64]))
    peak=max(abs(x) for x in result)
    # One common post-gain for the entire clip, to preserve relative levels.
    gain=0.85/peak if peak else 1.0
    pcm=struct.pack('<'+str(len(result))+'h',*[int(max(-1,min(1,x*gain))*32767) for x in result])
    with wave.open(str(args.output),'wb') as file:
        file.setnchannels(1); file.setsampwidth(2); file.setframerate(rate); file.writeframes(pcm)
    print('Demo: 1 second dry saw + 3 seconds Ooh to Eee sweep; common post-gain',round(gain,6))

if __name__=='__main__': main()

"""Recovered X3 factory Z-plane filter core (33 twelve-pole filters).

Reads tables from the user's local, fingerprinted executable. Does not load or
execute the executable. The filter core itself has no Windows dependencies.
This is a research port: sampler modulation smoothing and its separate adaptive
gain stage are not included. See README.md for scope and validation.
"""
import hashlib
import json
import math
from pathlib import Path
import struct

SUPPORTED_SHA256 = '6f342c6057a8a0fb69f021a0da46adbab7f5a332139a2ee3a9506c9fa84e6914'
SAMPLE_RATES = (44100, 48000, 96000, 192000)
FACTORY_NAMES = (
    'Ace of Bass', 'MegaSweepz', 'Early Rizer', 'Millennium', 'Meaty Gizmo',
    'Klub Klassik', 'BassBox 303', 'Fuzzi Face', 'Dead Ringer', 'TB or Not TB',
    'Ooh to Eee', 'Boland Bass', 'Multi Q Vox', 'Talking Hedz', 'Zoom Peaks',
    'DJ Alkaline', 'Bass Tracer', 'Rogue Hertz', 'Razor Blades', 'Radio Craze',
    'Eeh to Aah', 'Ubu Orator', 'Deep Bouche', 'Freak Shifta', 'Cruz Pusher',
    'Angelz Hairz', 'Dream Weava', 'Acid Ravage', 'Bass-O-Matic', "Lucifer's Q",
    'Tooth Comb', 'Ear Bender', 'Klang Kling',
)

def f32(value):
    """Round once to IEEE binary32, matching scalar SSE arithmetic."""
    return struct.unpack('<f', struct.pack('<f', value))[0]

def decode_word(word):
    """Translate X3's unsigned 16-bit packed coefficient, not IEEE float16."""
    if not isinstance(word, int) or not 0 <= word <= 65535:
        raise ValueError('Packed coefficient must be an unsigned 16-bit integer')
    n = word + 1
    if n == 65536:
        return 1.0
    if n == 1:
        return 0.0
    exponent = ((n >> 12) & 15) - 15
    mantissa = n & 4095
    if exponent > -15:
        mantissa |= 4096
        scale = 1.0 / 8192.0
    else:
        scale = 1.0 / 4096.0
    return f32(math.ldexp(f32(mantissa * scale), exponent))

def _control(value):
    value = float(value)
    if not math.isfinite(value):
        raise ValueError('Filter control must be finite')
    return f32(min(1.0, max(0.0, value)))

def _lerp_word(a, b, t):
    return (a + int(f32(f32(b - a) * t))) & 65535

class FactoryBank:
    """33 filters x 4 sample rates x 6 sections x 4 frames x 5 words."""
    def __init__(self, table):
        table = bytes(table)
        if len(table) != 33 * 4 * 240:
            raise ValueError('Incorrect X3 factory bank size')
        self.table = table

    @classmethod
    def from_executable(cls, path):
        data = Path(path).read_bytes()
        if hashlib.sha256(data).hexdigest() != SUPPORTED_SHA256:
            raise ValueError('Unrecognized executable build; offsets are unsafe for this file')
        # Confirmed .rdata file mapping for the fingerprint above.
        table_offset = 0x6F6030 - 0x60C000 + 0x60A000
        return cls(data[table_offset:table_offset + 33 * 4 * 240])

    def save(self, path):
        """Save locally extracted data for using the core on another platform."""
        Path(path).write_text(json.dumps({'format': 'emux-factory-v1',
            'source_sha256': SUPPORTED_SHA256,
            'table_hex': self.table.hex()}), encoding='utf-8')

    def save_binary(self, path):
        """Export 31,680 little-endian bytes for the portable C++ bank reader."""
        Path(path).write_bytes(self.table)

    @classmethod
    def load(cls, path):
        obj = json.loads(Path(path).read_text(encoding='utf-8'))
        if obj.get('format') != 'emux-factory-v1' or obj.get('source_sha256') != SUPPORTED_SHA256:
            raise ValueError('Unrecognized factory bank format or provenance')
        return cls(bytes.fromhex(obj['table_hex']))

    def frames(self, filter_id, sample_rate=48000):
        if isinstance(filter_id, str):
            filter_id = FACTORY_NAMES.index(filter_id)
        if not isinstance(filter_id, int) or not 0 <= filter_id < 33:
            raise ValueError('Factory filter index must be 0..32')
        if sample_rate not in SAMPLE_RATES:
            raise ValueError('Supported sample rates: 44100, 48000, 96000, 192000')
        rate_index = SAMPLE_RATES.index(sample_rate)
        off = (filter_id * 4 + rate_index) * 240
        return [[list(struct.unpack_from('<5H', self.table, off + stage * 40 + frame * 10))
                 for stage in range(6)] for frame in range(4)]

    def coefficients(self, filter_id, frequency=0.5, resonance=0.5, sample_rate=48000):
        """Return six [c0,c1,c2,c3,g] sections at normalized X3 controls.

        X3 interpolates packed words in frequency first, then resonance,
        truncating after each interpolation. Decoding before interpolation
        produces a different filter.
        """
        frames = self.frames(filter_id, sample_rate)
        frequency, resonance = _control(frequency), _control(resonance)
        sections = []
        for stage in range(6):
            words = []
            for j in range(5):
                lo = _lerp_word(frames[0][stage][j], frames[1][stage][j], frequency)
                hi = _lerp_word(frames[2][stage][j], frames[3][stage][j], frequency)
                words.append(_lerp_word(lo, hi, resonance))
            d = [decode_word(word) for word in words]
            sections.append((f32(f32(4.0 * d[0]) + d[1]), d[1],
                             f32(f32(4.0 * d[2]) + d[3]), d[3], f32(4.0 * d[4])))
        return sections

class Filter:
    """Stateful mono cascade using the recovered X3 scalar stage recurrence.

    Use independent instances for left/right. Coefficient replacement preserves
    state but is immediate: the host must provide its own modulation smoothing.
    Python is a reference implementation; use emux_filters.hpp for real time.
    """
    def __init__(self, coefficients):
        self.set_coefficients(coefficients)
        self.reset()

    def set_coefficients(self, coefficients):
        coefficients = [tuple(f32(float(x)) for x in row) for row in coefficients]
        if not 0 <= len(coefficients) <= 6 or any(len(row) != 5 for row in coefficients):
            raise ValueError('Expected zero to six sections of five coefficients')
        if any(not math.isfinite(x) for row in coefficients for x in row):
            raise ValueError('Coefficients must be finite')
        if hasattr(self, 'state') and len(coefficients) != len(self.state):
            self.state = [[0.0, 0.0] for _ in coefficients]
        self.coefficients = coefficients

    def reset(self):
        self.state = [[0.0, 0.0] for _ in self.coefficients]

    def process_sample(self, sample):
        x = f32(float(sample))
        if not math.isfinite(x):
            raise ValueError('Input sample must be finite')
        for i, (c0, c1, c2, c3, gain) in enumerate(self.coefficients):
            s1, s2 = self.state[i]
            t = f32(f32(f32(s2 * c3) - f32(s1 * c2)) + x)
            x = f32(f32(f32(f32(s1 * c0) + t) - f32(s2 * c1)) * gain)
            self.state[i] = [f32(f32(f32(2.0 * s1) + t) - s2), s1]
        return x

    def process(self, samples):
        return [self.process_sample(x) for x in samples]

def to_sos(coefficients):
    """Convert to conventional [b0,b1,b2,a0,a1,a2] second-order sections.

    Transfer-function equivalent; rounding/state behavior differs from Filter.
    Suitable for response plots and scipy.signal.sosfilt.
    """
    return [(g, (c0 - 2.0) * g, (1.0 - c1) * g, 1.0, c2 - 2.0, 1.0 - c3)
            for c0, c1, c2, c3, g in coefficients]

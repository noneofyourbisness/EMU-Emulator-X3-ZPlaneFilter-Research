#pragma once
#include "emux_voice_tables.hpp"
#include <array>
#include <cstdint>
#include <cstddef>
namespace emux {
// Tables were read from the original standalone X3 at 44.1 kHz / 256 frames.
// Use strict floating-point compilation; each temporary preserves an SSE rounding point.
template<class T,std::size_t N> inline T voice_lookup_scaled(const std::array<T,N>& table,T position) noexcept {
 const int index=static_cast<int>(position);
 if(index<0)return table[0];if(index>=int(N-1))return table[N-1];
 const T fraction=position-static_cast<T>(index);
 const T difference=table[index+1]-table[index];
 const T product=difference*fraction;
 return product+table[index];
}
inline float voice_pan_lookup(float pan,bool equalPower,bool stereo=false) noexcept {
 const float position=256.0f*pan;
 return equalPower?voice_lookup_scaled(voice_tables::equalPowerPanTable,position):stereo?voice_lookup_scaled(voice_tables::legacyStereoPanTable,position):voice_lookup_scaled(voice_tables::legacyPanTable,position);
}
inline std::array<float,2> voice_pan(float pan,bool equalPower,bool stereo=false) noexcept {
 const float inverse=1.0f-pan;
 return {voice_pan_lookup(inverse,equalPower,stereo),voice_pan_lookup(pan,equalPower,stereo)};
}
inline float voice_tick_rate(float time) noexcept {
 const double position=255.0*static_cast<double>(time);
 return static_cast<float>(voice_lookup_scaled(voice_tables::tickRateTable,position));
}
struct RegionFade {
 float current=1,output=1;std::uint32_t state=6;
 float tick() noexcept {
  if(state==0) {
   const double position=255.0*0.01171875;
   const float step=static_cast<float>(voice_lookup_scaled(voice_tables::tickRateTable,position));
   current=step+current;output=current;
   if(current>1.0f){state=6;current=output=1.0f;}
  } else if(state==7) {
   const double position=255.0*0.01171875;
   const float step=static_cast<float>(voice_lookup_scaled(voice_tables::tickRateTable,position));
   current=current-step;output=current;
   if(current<0.0f){state=8;current=output=0.0f;}
  } else if(state!=8)current=output=1.0f;
  return output;
 }
};
struct VoiceTargetInputs {
 float amplitude=1,pan=.5f,width=1,regionGain=1,baseGain=1,basePan=.5f,previousAmplitude=1;
 bool stereo=false,specialStereo=false,equalPower=true,silenced=false,muted=false;
};
struct VoiceTargets {float amplitude;std::array<float,4> weights;};
inline VoiceTargets voice_targets(const VoiceTargetInputs& in,RegionFade& fade,std::array<float,4> previous) noexcept {
 double amp=static_cast<double>(in.regionGain)*static_cast<double>(in.baseGain);
 amp=amp*static_cast<double>(in.silenced?in.previousAmplitude:in.amplitude);
 float a=static_cast<float>(amp);a=fade.tick()*a;if(in.muted)a=0.0f;
 float p=in.pan+in.basePan;p=p-1.0f;p=p+.5f;
 auto w=previous;
 if(!in.stereo&&!in.specialStereo) {
  auto lr=voice_pan(p,in.equalPower);w[0]=lr[0]*a;w[1]=lr[1]*a;
 }else if(in.width<1.0f) {
  float adjusted=p*2.0f;adjusted=adjusted-1.0f;adjusted=adjusted*in.width;adjusted=adjusted*.5f;adjusted=adjusted+.5f;
  auto lr=voice_pan(adjusted,in.equalPower,true);
  float cross=1.0f-in.width;cross=cross*.5f;const float own=1.0f-cross;
  w={own*lr[0],own*lr[1],cross*lr[1],cross*lr[0]};for(auto& x:w)x=x*a;
 }else {
  auto lr=voice_pan(p,in.equalPower,true);const float delta=p-.5f;
  if(delta<=0.0f){const float own=delta+1.0f;const float cross=delta*lr[0];w={own*lr[0],lr[1],0.0f,0.0f-cross};}
  else {const float own=1.0f-delta;w={lr[0],own*lr[1],delta*lr[1],0.0f};}
  for(auto& x:w)x=x*a;
 }
 return {a,w};
}
// Original 0x1402e5530, after modulation-source evaluation (lazy flag updates belong to the caller).
struct VoiceAmplitudeInputs {
 float controllerDb=0,volume=0,realtimeVolume=0,linearGain=1,envelope=1,keyControl=0,velocityGain=1,voiceGain=1;
 float panChannel=.5f,panController=0,panCord=.5f,panVoice=.5f;
 std::int8_t keyLow=0,keyLowFade=0,keyHighFade=0,keyHigh=127;
 bool linear=true,muted=false;
};
inline double voice_key_fade(const VoiceAmplitudeInputs& in) noexcept {
 float key=in.keyControl*127.0f;key=key+.5f;int k=static_cast<int>(key);if(k<0)k=0;if(k>=128)k=127;
 int index=-1;
 if(k<int(in.keyLow)+int(in.keyLowFade)) {
  if(k<int(in.keyLow))return 0.0;
  if(in.keyLowFade==0)return 1.0;
  const int quotient=static_cast<std::int8_t>(128/int(in.keyLowFade));index=quotient*(k-int(in.keyLow));
 }else if(k>int(in.keyHigh)-int(in.keyHighFade)) {
  if(k>int(in.keyHigh))return 0.0;
  if(in.keyHighFade==0)return 1.0;
  const int quotient=static_cast<std::int8_t>(128/int(in.keyHighFade));index=quotient*(int(in.keyHigh)-k);
 }
 if(index==-1)return 1.0;if(index<0)index=0;if(index>=128)index=127;
 return voice_tables::keyFadeTable[index];
}
inline float voice_amplitude(const VoiceAmplitudeInputs& in) noexcept {
 double mapped;
 if(in.linear) {
  double position=static_cast<double>(in.controllerDb)*(1.0/96.0);position=position+1.0;position=position*voice_tables::linearDbTableScale;
  const double dbGain=voice_lookup_scaled(voice_tables::linearDbTable,position);
  const float volumes=in.volume+in.realtimeVolume;
  double gain=static_cast<double>(volumes)+dbGain;if(gain<0.0)gain=0.0;if(gain>4.0)gain=4.0;
  const float envProduct=in.envelope*in.linearGain;
  double envelope=static_cast<double>(envProduct);if(envelope<0.0)envelope=0.0;if(envelope>2.0)envelope=2.0;
  mapped=envelope*envelope;mapped=mapped*gain;
 }else {
  float value=in.volume+in.realtimeVolume;value=value+in.linearGain;value=value*127.0f;value=value+in.controllerDb;
  float env=in.envelope-1.0f;env=env*96.0f;
  double position=static_cast<double>(env)+static_cast<double>(value);position=position*(1.0/96.0);position=position+1.0;position=position*voice_tables::logDbTableScale;
  mapped=voice_lookup_scaled(voice_tables::logDbTable,position);
 }
 double amplitude=static_cast<double>(in.velocityGain)*voice_key_fade(in);amplitude=amplitude*mapped;amplitude=amplitude*static_cast<double>(in.voiceGain);
 return in.muted?0.0f:static_cast<float>(amplitude);
}
inline float voice_pan_control(const VoiceAmplitudeInputs& in) noexcept {
 float p=in.panController+in.panChannel;p=p+in.panCord;p=p+in.panVoice;p=p-2.0f;return p+.5f;
}
inline float voice_modulation_value(unsigned mode,float base,const float* cords,unsigned count) noexcept {
 float value=base;
 if(mode==0||mode==4)for(unsigned i=0;i<count;++i)value=value+cords[i];
 else if(mode==1)for(unsigned i=0;i<count;++i)value=value*cords[i];
 if(mode==4){if(value<0.0f)value=0.0f;if(value>1.0f)value=1.0f;}
 return value;
}
// Original 0x140300b60 / 0x140300bf0 cord transfer, after source/amount evaluation.
// Even a unity multiplicative cord rounds (source-bias)+1 separately.
inline float voice_modulation_cord(float source,float bias,float amount,unsigned destinationMode) noexcept {
 float value=source-bias;value=value*amount;
 if(destinationMode==1)value=value+1.0f;
 return value;
}

// Normal volume-envelope release, original 0x1403025e0 / 0x1403018d0.
// Cached time controls supplied after modulation; nonsynchronized 44.1k/256 table.
struct VolumeRelease {
 float value=1,output=1,increment=0,start=1,target1=0,target2=0,time1=0,time2=0;
 unsigned state=6;
 void enterSecond() noexcept {
  const float rate=voice_tick_rate(time2);
  if(rate==1.0f){state=8;increment=0;value=target2;}
  else {state=5;increment=target2<target1?0.0f-rate:rate;value=target1;}
 }
 void begin(float previous,float firstTarget,float secondTarget,float firstTime,float secondTime) noexcept {
  start=value=output=previous;target1=firstTarget;target2=secondTarget;time1=firstTime;time2=secondTime;state=4;
  const float rate=voice_tick_rate(time1);
  if(target1==start||rate==1.0f)enterSecond();
  else increment=target1<start?0.0f-rate:rate;
 }
 float tick() noexcept {
  float next=value+increment;
  if(state==4) {
   if((target1>=start&&next>=target1)||(target1<start&&next<=target1)){enterSecond();next=value;}
   else {const float rate=voice_tick_rate(time1);increment=target1<start?0.0f-rate:rate;}
  }else if(state==5) {
   if((target2>=target1&&next>=target2)||(target2<target1&&next<=target2)){state=8;increment=0;next=target2;}
   else {const float rate=voice_tick_rate(time2);increment=target2<target1?0.0f-rate:rate;}
  }
  value=output=next;return output;
 }
};

struct SamplePlaybackState {bool loopEnabled=false,loopActive=false,held=false;int count=0,limit=0;float limitControl=0;};
// Original 0x1402d54ea: post-render keep/remove decision, not resampling or loop rendering.
inline bool sample_playback_continues(SamplePlaybackState& s) noexcept {
 if(s.loopEnabled) {
  if(s.loopActive)return s.held||s.count==0;
  if(s.count!=0&&s.limit==2)s.limit=static_cast<int>(s.limitControl*2.0f);
  return s.count<=s.limit;
 }
 return s.loopActive||s.count==0;
}
} // namespace emux

# X3 release, amplitude, pan and voice lifetime trace

The recovered controls reproduce the covered live X3 voice/master audio with **zero bit differences in four takes**. They also pass **10,860 isolated original-instruction cases, 46,890 output values, zero bit differences**. This is scoped evidence, not an overall accuracy percentage or a new end-to-end VST3 claim.

| Live take | Note / velocity | Covered blocks | Covered mono frames | Stereo audio values per stage | Differences |
|---|---|---:|---:|---:|---:|
| Ooh to Eee | 60 / 127 | 3,617 | 925,952 | 1,851,904 | 0 |
| No Filter | 36 / 64 | 3,654 | 935,424 | 1,870,848 | 0 |
| Peak/Shelf Morph, default frames | 60 / 127 | 3,617 | 925,952 | 1,851,904 | 0 |
| No Filter | 36 / 127 | 3,654 | 935,424 | 1,870,848 | 0 |

All are standalone X3, 44.1 kHz, 256 frames, existing saw bank, Q50 / realtime Q0, Steps. Mono is duplicated to stereo. Each row compares both the premaster and final bus separately. In total, each audio stage compares **7,445,504 float values**. The first note quantum is not observed here: comparison begins at frame 44,544, not the note-on at 44,288. Note-off applies at 970,240. End frames are 970,496 or 979,968 (exclusive).

## Recovered source

`emux_voice_control.hpp` and `emux_voice_tables.hpp` add the original legacy/equal-power pan lookups, region fade, amplitude laws and key fades, mono/stereo pan/width targets, cord transfer and combination, normal nonsynchronized two-stage volume release, and sample-player post-render keep/remove predicate. Keep strict floating-point compilation: the original float/double conversion and operation order matter. The envelope-rate table is specific to the measured 44.1 kHz / 256-frame conditions. Its other-rate construction remains to be ported. E-MU table provenance remains separate from the wrapper's licence.

Normal release decrements the held envelope by 0.026639200747013092 per tick in this bank. The first released value is 0.9733607769012451. The volume law squares the routed envelope before applying the mapped gain. Region fade remains held at 1; it does not cause this release slope.

The unity envelope cord still performs `float(envelope - 1)`, multiplication by 1 and `float(value + 1)`. That round trip changes low envelope values. Omitting it produced small late-tail errors; restoring the original cord arithmetic removes them. Cord source/amount evaluation and scheduling are separate from this recovered transfer operation.

The low-velocity bank voice has linear gain 0.8809449076652527. Its existing velocity cord uses normalized 64/127, bias 1 and depth approximately 0.24. The direct velocityGain/voiceGain fields remain 1. This demonstrates the bank's cord route, not a universal velocity-to-gain law.

## Voice lifetime

The note-60 takes render one post-note-off block. The low-note takes render 38, including 37 additional blocks, and the envelope reaches state 8 / zero. The low-note result is the same at velocities 64 and 127; the velocity-127 comparison isolates pitch against note 60. An additional earlier note-84/velocity-32 trace also ends after one release block.

The sample-player keep/remove predicate reads loop/held/counter state after rendering. In the final note-60 snapshot the held flag is zero and counter is 1, so it returns false even though the envelope is still in release. The low-note counter remains 0, allowing playback until the envelope finishes. This is why a universal one-block release cutoff is incorrect. The predicate is ported and tested, but the routines that advance the sample/loop counters are not yet ported. The saved sample-player snapshots document these conditions without asserting that all fields' musical meanings are known.

## What the live replay supplies

The checker starts the envelope once at the logged note-off, generates its subsequent values, passes them through the recovered cord and amplitude law, generates pan/target weights, carries endpoints between blocks, then runs the recovered gain ramps and original master arithmetic. It compares envelope state/value/output/increment/start, previous amplitude and mono weights, and all covered audio values.

The captured post-filter samples, controller values, static voice settings, base/region gains and master level are inputs. First held endpoints are seeded once. The unused mono cross-channel weights are ignored. Every later used endpoint is independently generated. The after-render observer skips the removed final voice; the before-mix audio/control observer covers that final block. The first note block is outside this new proof.

This verifies the control and downstream audio path in these configurations. It does not regenerate the sampler or establish a bit-exact plugin across arbitrary audio, presets or settings. Stereo targets have isolated instruction tests; the live captures remain mono.

## Delivery and remaining work

The reusable library and JUCE source contain the new headers, fixtures and a `VoiceControlChecks` test. Both that test and `ProcessorChecks` pass. The shipped VST3 remains **0.5.0**, with its binary unchanged; the new envelope/lifetime components are not wired into its effect processing. Adding a partial sampler lifetime to an effect would produce the wrong release for some pitches.

See [NEXT-CAPTURES.md](NEXT-CAPTURES.md) for the next useful recordings and [REPRODUCE.md](REPRODUCE.md) for independent checks. `accuracy.json` contains exact counts and limits. The full `X3-Release-Control-Trace.zip` includes the live inputs and snapshots; source/library research folders omit the large audio payloads.

The original installed executable and user SawBank EXB hashes remain unchanged. No activation/protection code or modern Rossum Morpheus documentation was used.

#include "emux_voice_control.hpp"
#include <fstream>
#include <iostream>
#include <cstring>
#include <algorithm>
struct Case {uint32_t kind;float v[32];uint32_t i[8];float out[12];};
uint32_t bits(float x){uint32_t u;std::memcpy(&u,&x,4);return u;}
int main(int argc,char** argv) {
 std::ifstream f(argc>1?argv[1]:"outputs/zplane-release-trace/voice-control-vectors.bin",std::ios::binary);uint32_t count=0;f.read((char*)&count,4);if(!f||!count)return 2;
 unsigned failures=0,values=0;unsigned kinds[8]{};
 for(uint32_t n=0;n<count;++n) {
  Case c{};f.read((char*)&c,sizeof(c));if(!f)return 2;float got[12]{};unsigned used=0;const auto& v=c.v;const auto& i=c.i;
  switch(c.kind) {
  case 0:{auto p=emux::voice_pan(v[0],i[0]!=0);got[0]=p[0];got[1]=p[1];used=2;break;}
  case 1:{emux::RegionFade fade{v[0],v[1],i[0]};fade.tick();got[0]=fade.current;got[1]=fade.output;got[2]=float(fade.state);used=3;break;}
  case 2:{emux::VoiceTargetInputs in;in.amplitude=v[0];in.pan=v[1];in.width=v[2];in.regionGain=v[3];in.baseGain=v[4];in.basePan=v[5];in.previousAmplitude=v[6];in.stereo=i[0]!=0;in.specialStereo=i[1]!=0;in.equalPower=i[2]!=0;in.silenced=i[4]!=0;in.muted=i[5]!=0;
   emux::RegionFade fade{v[7],v[8],i[6]};auto r=emux::voice_targets(in,fade,{v[9],v[10],v[11],v[12]});got[0]=r.amplitude;std::copy(r.weights.begin(),r.weights.end(),got+1);got[5]=fade.current;got[6]=fade.output;got[7]=float(fade.state);used=8;break;}
  case 3:{emux::VoiceAmplitudeInputs in;in.controllerDb=v[0];in.volume=v[1];in.realtimeVolume=v[2];in.linearGain=v[3];in.envelope=v[4];in.keyControl=v[5];in.velocityGain=v[6];in.voiceGain=v[7];in.panChannel=v[8];in.panController=v[9];in.panCord=v[10];in.panVoice=v[11];in.keyLow=int8_t(i[0]);in.keyLowFade=int8_t(i[1]);in.keyHighFade=int8_t(i[2]);in.keyHigh=int8_t(i[3]);in.linear=i[4]!=0;in.muted=i[5]!=0;got[0]=emux::voice_amplitude(in);got[1]=emux::voice_pan_control(in);used=2;break;}
  case 4:got[0]=emux::voice_modulation_value(i[0],v[0],v+1,i[1]);used=1;break;
  case 5:{emux::SamplePlaybackState s{i[0]!=0,i[1]!=0,i[2]!=0,int(i[3]),int(i[4]),v[0]};got[0]=float(emux::sample_playback_continues(s));got[1]=float(s.limit);used=2;break;}
  case 6:{emux::VolumeRelease release;release.begin(v[0],v[3],v[4],v[1],v[2]);for(unsigned n=0;n<i[0];++n)release.tick();got[0]=release.value;got[1]=release.output;got[2]=release.increment;got[3]=release.start;got[4]=float(release.state);used=5;break;}
  case 7:got[0]=emux::voice_modulation_cord(v[0],v[1],v[2],i[0]);used=1;break;
  default:return 2;
  }
  for(unsigned j=0;j<used;++j){++values;if(bits(got[j])!=bits(c.out[j])){if(failures<20)std::cout<<"case "<<n<<" kind "<<c.kind<<" field "<<j<<" got "<<std::hex<<bits(got[j])<<" expected "<<bits(c.out[j])<<std::dec<<"\n";++failures;++kinds[c.kind];}}
 }
 std::cout<<count<<" cases, "<<values<<" values, "<<failures<<" bit differences\n";for(auto k:kinds)std::cout<<k<<" ";std::cout<<"\n";return failures?1:0;
}

#include "emux_voice_control.hpp"
#include "emux_voice_mix.hpp"
#include <fstream>
#include <iostream>
#include <vector>
#include <cstring>
#include <string>
std::vector<char> read(const std::string& p){std::ifstream f(p,std::ios::binary);return {std::istreambuf_iterator<char>(f),{}};}
template<class T>T load(const std::vector<char>& b,size_t offset){T v;std::memcpy(&v,b.data()+offset,sizeof v);return v;}
uint32_t bits(float x){uint32_t u;std::memcpy(&u,&x,4);return u;}
struct Counter {uint64_t values=0,different=0;void check(float a,float b){++values;if(bits(a)!=bits(b))++different;}};
int main(int argc,char**argv){if(argc!=2)return 2;std::string p=argv[1];auto cfg=read(p+".config.bin"),records=read(p+".release.bin"),src=read(p+".source.f32"),pre=read(p+".premaster.f32"),bus=read(p+".bus.f32");if(cfg.size()!=96||records.size()<20||src.size()!=pre.size()||src.size()!=bus.size())return 2;
 emux::VoiceAmplitudeInputs in;auto cf=[&](unsigned i){return load<float>(cfg,i*4);};auto ci=[&](unsigned i){return load<int>(cfg,68+i*4);};
 in.volume=cf(1);in.realtimeVolume=cf(2);in.linearGain=cf(3);in.keyControl=cf(5);in.velocityGain=cf(6);in.voiceGain=cf(7);in.panCord=cf(10);in.panVoice=cf(11);in.keyLow=int8_t(ci(0));in.keyLowFade=int8_t(ci(1));in.keyHighFade=int8_t(ci(2));in.keyHigh=int8_t(ci(3));in.linear=ci(4)!=0;in.muted=ci(5)!=0;
 const auto off=load<uint32_t>(cfg,92),count=load<uint32_t>(records,12);if(!count||load<uint32_t>(records,0)!=0x524c5331||load<uint32_t>(records,8)!=344||records.size()!=20+size_t(count)*344)return 2;
 emux::VolumeRelease release;release.value=release.output=cf(12);release.start=0;bool releasing=false;emux::RegionFade fade;
 emux::VoiceMixRamp::Weights previous{};float previousAmplitude=0;Counter envelope,amplitude,weights,premaster,master;uint64_t first=0,last=0;
 for(unsigned n=0;n<count;++n){const size_t o=20+size_t(n)*344;const auto frame=load<uint64_t>(records,o);const auto frames=load<uint32_t>(records,o+36);if(frames!=256||frame>src.size()/8||frames>src.size()/8-frame||(n&&frame!=last))return 2;auto rf=[&](unsigned i){return load<float>(records,o+48+4*i);};auto ef=[&](unsigned i){return load<float>(records,o+304+4*i);};if(n==0){first=frame;for(unsigned i=0;i<4;++i)previous[i]=rf(i);previousAmplitude=rf(7);fade={rf(8),rf(9),load<uint32_t>(records,o+44)};}
  if(frame>=off){if(!releasing){release.begin(cf(12),cf(13),cf(14),cf(15),cf(16));releasing=true;}release.tick();}
  envelope.check(release.value,ef(0));envelope.check(release.output,ef(1));envelope.check(release.increment,ef(2));envelope.check(release.start,ef(3));envelope.check(float(release.state),float(load<uint32_t>(records,o+336)));
  in.envelope=emux::voice_modulation_cord(release.output,1.0f,1.0f,1);in.controllerDb=rf(12+22*2);in.panChannel=rf(12+20*2);in.panController=rf(12+23*2);const float amp=emux::voice_amplitude(in),pan=emux::voice_pan_control(in);amplitude.check(previousAmplitude,rf(7));
  for(unsigned i=0;i<2;++i)weights.check(previous[i],rf(i));
  emux::VoiceTargetInputs t;t.amplitude=amp;t.pan=pan;t.width=rf(10);t.regionGain=rf(4);t.baseGain=rf(5);t.basePan=rf(6);t.previousAmplitude=previousAmplitude;const auto flags=load<uint32_t>(records,o+296);t.stereo=(flags&255)!=0;t.silenced=((flags>>8)&255)!=0;t.equalPower=((flags>>16)&255)!=0;t.specialStereo=load<uint32_t>(records,o+300)==3;
  auto target=emux::voice_targets(t,fade,previous);emux::VoiceMixRamp ramp;ramp.prepare(previous,target.weights,1.0/double(frames));
  for(unsigned j=0;j<frames;++j){const size_t audio=(frame+j)*8;float l=0,r=0;ramp.accumulate(load<float>(src,audio),load<float>(src,audio+4),t.stereo||t.specialStereo,l,r);premaster.check(l,load<float>(pre,audio));premaster.check(r,load<float>(pre,audio+4));float ml=l*rf(11);ml=ml+0.0f;float mr=r*rf(11);mr=mr+0.0f;master.check(ml,load<float>(bus,audio));master.check(mr,load<float>(bus,audio+4));}
  previous=target.weights;previousAmplitude=target.amplitude;last=frame+frames;
 }
 auto emit=[](const char*name,Counter c){std::cout<<"\""<<name<<"\":{\"values\":"<<c.values<<",\"bit_differences\":"<<c.different<<"}";};
 std::cout<<"{\"first_frame\":"<<first<<",\"end_frame\":"<<last<<",\"blocks\":"<<count<<",";emit("envelope",envelope);std::cout<<",";emit("previous_amplitude",amplitude);std::cout<<",";emit("previous_weights",weights);std::cout<<",";emit("premaster_audio",premaster);std::cout<<",";emit("master_audio",master);std::cout<<"}\n";
 return (envelope.different||amplitude.different||weights.different||premaster.different||master.different)?1:0;
}

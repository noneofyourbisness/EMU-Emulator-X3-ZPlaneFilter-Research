# Next useful X3 captures

## First: Q0 and Q100 Steps

Keep standalone X3 at **44.1 kHz / 256 samples**, note **60**, velocity **127**, base Morph **0**, Mod Wheel → Filter Frequency **100%**, realtime Q **0**. No 48 kHz test is needed for this next step.

1. Load the **inner** `FilterSawBank.exb` from the harness's `Profiles/Q0/FilterSawBank.exb/` folder into X3, replacing the main Q50 bank. Keep its channel 1 / port A assignment.
2. Check **Ooh to Eee** shows base Q **0%**. Capture one Steps take with detailed tracing enabled to confirm the raw Q and timing. Then disable detailed tracing for the large batch.
3. Choose **Steps — 56 files**, then **Capture all filters**. This includes No Filter and takes about **22m 24s**, plus saving time.
4. Save/share the whole batch folder as a ZIP named **Q0-Steps**. Keep its JSON sidecars/session log.
5. Repeat with `Profiles/Q100/FilterSawBank.exb/FilterSawBank.exb`, checking base Q **100%**, and name the result **Q100-Steps**.

The harness selects presets; it does not automatically switch or verify which Q bank is loaded. Loading the inner bank and checking the displayed Q prevents another wrong-setting batch. These profiles preserve the original sample and loop bytes. The existing Q50 batch does not need repeating.

## Next: active programmable frames

Make a separate copy of the relevant harness bank. For one programmable filter (for example Dual EQ Morph or Peak/Shelf Morph), set noticeably different, nonzero frame values and save the copy. Retain the preset number and mod-wheel routing. Record **No Filter + that filter, Steps, Q50**, and share the edited bank/sample-pool folder or ZIP along with the WAVs and sidecars. A screenshot of all frame settings is useful too. Start with one filter; the existing zero defaults do not exercise active frame branches.

For Morph Designer, follow the same process with at least one active section and distinct endpoint settings. Save the exact section configuration.

## Later: true stereo

Use a genuinely stereo test sample with different left/right signals, with no effects. Share the sample, looped bank, and No Filter / Ooh to Eee Steps captures. Identical left/right mono copies do not test the stereo paths. The reusable pan/width arithmetic already matches isolated X3 instructions, but needs a live stereo-bank check.

## Work that can continue here

Pitch/velocity release checks are now available at 36/64, 36/127, 60/127 and 84/32. You do not need to repeat them. Remaining tracing can target sampler resampling/loop advancement, attack/decay/sustain, tempo-synchronized envelopes, forced fades and retrigger. If a new user recording is needed for a specific branch, its exact settings should be defined first.

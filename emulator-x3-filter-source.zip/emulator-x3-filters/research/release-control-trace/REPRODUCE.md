# Reproduce the control and live checks

Use a Visual Studio x64 developer PowerShell (MSVC C++17) in the extracted full trace folder. No X3 process is needed to run the saved-fixture checks.

```powershell
cl /nologo /std:c++17 /EHsc /MT /O2 /fp:strict /utf-8 check_voice_control.cpp /Fe:VoiceControlCheck.exe
.\VoiceControlCheck.exe voice-control-vectors.bin
cl /nologo /std:c++17 /EHsc /MT /O2 /fp:strict /utf-8 check_live_release.cpp /Fe:LiveReleaseCheck.exe
.\LiveReleaseCheck.exe live/ooh
.\LiveReleaseCheck.exe live/low
.\LiveReleaseCheck.exe live/peak
.\LiveReleaseCheck.exe live/low-unity
```

Expected: 10,860 original-instruction cases, 46,890 meaningful output values, zero bit differences. Each live JSON result has zero `bit_differences` in every comparison group. Exit status is nonzero if a check fails. The full trace ZIP contains the live `.f32`, `.config.bin`, `.release.bin`, event metadata and original structure snapshots. These payloads are not repeated in the library/JUCE source ZIPs.

The fixture records are a uint32 count followed by `<I32f8I12f` records; only the per-kind meaningful output fields are checked. The generator executed the original installed EXE's SSE instructions with the measured table data. Kind 7 covers the cord transfer; kind 6 covers normal volume release. Other kinds cover pan, region fade, targets, amplitude/key fades, modulation combination and sample keep/remove arithmetic. The original executable is not included.

The live config is `<17f6iI`, caching original static amplitude settings, initial envelope/release parameters and applied note-off frame. Release files have a 20-byte `<5I` header and 344-byte `<4Q4I62f2I8fI4x` records. Audio files are little-endian float32 interleaved stereo at 44.1 kHz. Records retain original process addresses as observational metadata; the checker does not dereference them. `snapshots/` contains the original small structure dumps and after-render amplifier logs.

## Optional new live captures

Connect the existing normal harness to an already-running matching X3 at 44.1 kHz / 256 frames. From this package, run:

```powershell
.\ReleaseCaptureReady.exe --status
.\ReleaseCaptureReady.exe "Ooh to Eee" 60 127
.\ReleaseCaptureReady.exe "No Filter" 36 127
```

Keep `X3ReleaseProbeFinal.dll` beside the capture EXE. This helper requires the existing protocol-4 X3Bridge attachment; it does not create a MIDI driver or automatically load a bank. It temporarily wraps the bridge processing callback and the one active voice's mix callback, forwards original processing and restores the previous tables after capture. It leaves the DLL loaded but inactive. Capture storage is preallocated, and file saving occurs outside the audio callback. Unknown executable, callback owner, rate/quantum or concurrent capture is rejected. Captures save under this package's `captures/` folder. The actual loaded Q bank must be chosen and verified in X3.

The source is in `observer-source/`; compile the DLL from `ReleaseProbeFinal.cpp` and the CLI from `ReleaseCaptureReady.cpp`, using MSVC x64, the same strict options, and the harness's Windows libraries. It includes the existing controller implementation only to reuse its connection/capture machinery; the original GUI/bridge behavior is unchanged.

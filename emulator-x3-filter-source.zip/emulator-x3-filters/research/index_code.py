import json,re,pathlib,collections,sys
from trace_filters import pe,md,bounds,OUT
refs=collections.defaultdict(list); calls=collections.defaultdict(list); fieldrefs=collections.defaultdict(list)
pattern=re.compile(r'\[rip ([-+]) (0x[0-9a-f]+)\]')
for s in pe.sections:
    if s['name'] not in ('.text','.textidx'): continue
    blob=pe.data[s['raw_offset']:s['raw_offset']+s['raw_size']]
    for address,size,mnemonic,ops in md.disasm_lite(blob,pe.base+s['rva']):
        m=pattern.search(ops)
        if m:
            target=address+size+int(m[2],16)*(1 if m[1]=='+' else -1)
            refs[hex(target)].append([hex(address),mnemonic,ops])
        if mnemonic=='call' and ops.startswith('0x'): calls[ops].append(hex(address))
        for field in ['0x2c0','0x2fc','0x338','0x374','0x420']:
            if field in ops: fieldrefs[field].append([hex(address),mnemonic,ops])
result={'refs':refs,'calls':calls,'fields':fieldrefs}
(pathlib.Path(__file__).parent/'code-index.json').write_text(json.dumps(result),encoding='utf-8')
targets=['0x1406f6030','0x1406f4b20','0x1406f4b00','0x1402ed880','0x1402e7c10']
print(json.dumps({t:{'refs':refs.get(t,[]),'calls':calls.get(t,[])} for t in targets},indent=2))
print(json.dumps(fieldrefs,indent=2))

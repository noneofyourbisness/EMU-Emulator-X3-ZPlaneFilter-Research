import pathlib,random,struct,sys
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from emux_filters import *
bank=FactoryBank.from_executable(r'C:\Program Files\E-MU\Emulator X3\EmulatorX.exe')
bank.save_binary(ROOT/'research'/'factory-tables.bin')
rng=random.Random(38117)
positions=[(0,0),(1,0),(0,1),(1,1),(.5,.5),(.137,.829),(.933,.247)]
with (ROOT/'research'/'cpp-vectors.bin').open('wb') as file:
    file.write(struct.pack('<I',924))
    for rate in SAMPLE_RATES:
        for idx in range(33):
            for freq,res in positions:
                coefs=bank.coefficients(idx,freq,res,rate)
                samples=[.001]+[0.0]*31+[f32(rng.uniform(-.0001,.0001)) for _ in range(32)]
                filt=Filter(coefs)
                expected=filt.process(samples)
                filt.reset()
                chunked=filt.process(samples[:17])+filt.process(samples[17:])
                assert chunked==expected
                file.write(struct.pack('<IIff',idx,rate,freq,res))
                for stage in coefs: file.write(struct.pack('<5f',*stage))
                file.write(struct.pack('<128f',*(samples+expected)))
    file.write(struct.pack('<65536f',*[decode_word(w) for w in range(65536)]))
print('Generated 924 independently validated scalar reference cases')

import hashlib,json,math,pathlib,random,struct,sys,time
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'research'/'python-deps'))
sys.path.insert(0,str(ROOT))
from unicorn import Uc,UC_ARCH_X86,UC_MODE_64,UC_HOOK_CODE
from unicorn.x86_const import *
from inspect_emulator import PE,OUT
from emux_filters import FactoryBank,Filter,decode_word,f32

pe=PE(r'C:\Program Files\E-MU\Emulator X3\EmulatorX.exe')
bank=FactoryBank.from_executable(pe.path)
uc=Uc(UC_ARCH_X86,UC_MODE_64)
uc.mem_map(pe.base,0x2100000)
for s in pe.sections:
    uc.mem_write(pe.base+s['rva'],pe.data[s['raw_offset']:s['raw_offset']+s['raw_size']])
MEM=0x20000000; STACK=MEM+0x80000; STOP=MEM+0xf0000
uc.mem_map(MEM,0x100000)
def write(address,fmt,*values): uc.mem_write(address,struct.pack('<'+fmt,*values))
def read(address,fmt): return struct.unpack('<'+fmt,uc.mem_read(address,struct.calcsize('<'+fmt)))
def hook(uc,address,size,user):
    if address!=0x14052b650: return
    xmm=uc.reg_read(UC_X86_REG_XMM0)
    value=struct.unpack('<d',xmm.to_bytes(16,'little')[:8])[0]
    exp=uc.reg_read(UC_X86_REG_EDX)
    if exp >= 0x80000000: exp-=0x100000000
    result=math.ldexp(value,exp)
    uc.reg_write(UC_X86_REG_XMM0,int.from_bytes(struct.pack('<d',result)+b'\0'*8,'little'))
    rsp=uc.reg_read(UC_X86_REG_RSP)
    ret=read(rsp,'Q')[0]
    uc.reg_write(UC_X86_REG_RSP,rsp+8)
    uc.reg_write(UC_X86_REG_RIP,ret)
uc.hook_add(UC_HOOK_CODE,hook,begin=0x14052b650,end=0x14052b650)

def call(address,rcx=0,rdx=0,r8=0,r9=0):
    rsp=STACK-8
    write(rsp,'Q',STOP)
    uc.reg_write(UC_X86_REG_RSP,rsp)
    uc.reg_write(UC_X86_REG_RCX,rcx)
    uc.reg_write(UC_X86_REG_RDX,rdx)
    uc.reg_write(UC_X86_REG_R8,r8)
    uc.reg_write(UC_X86_REG_R9,r9)
    uc.emu_start(address,STOP,count=5000000)
    assert uc.reg_read(UC_X86_REG_RIP)==STOP,'Routine failed to return'

VOICE=MEM; PLUGIN=MEM+0x1000; INPUT_DESC=MEM+0x2000; OUTPUT_DESC=MEM+0x2100
COEFS=MEM+0x3000; DELTAS=MEM+0x4000; STATES_PTR=MEM+0x5000; STATES=MEM+0x6000
INPUT=MEM+0x10000; OUTPUT=MEM+0x20000
def original_coefficients(filter_id,rate_index,freq,res):
    uc.mem_write(VOICE,b'\0'*0x1000)
    write(PLUGIN+0xc,'H',rate_index)
    write(PLUGIN+0x18,'H',filter_id)
    # Original factory-table copy (CPhantomFilterP2k virtual slot 1).
    call(0x1402ed880,PLUGIN,0,VOICE)
    frames=bank.frames(filter_id,(44100,48000,96000,192000)[rate_index])
    for frame in range(4):
        assert list(read(VOICE+0x2c0+frame*60,'30H'))==[x for stage in frames[frame] for x in stage]
    write(VOICE+0x2b0,'f',freq)
    write(VOICE+0x1e8,'f',res)
    write(VOICE+0x2a8,'f',4.0)
    call(0x1402cf470,VOICE)
    call(0x1402ced30,VOICE,VOICE+0x3b0,VOICE+0x530)
    return [read(VOICE+0x530+i*20,'5f') for i in range(6)]

def original_process(coefficients,samples):
    write(VOICE+0x28,'I',len(samples))
    write(VOICE+0x420,'I',6)
    write(VOICE+0x620,'Q',STATES_PTR)
    uc.mem_write(STATES,b'\0'*0x100)
    uc.mem_write(DELTAS,b'\0'*0x100)
    for i,c in enumerate(coefficients):
        write(COEFS+i*20,'5f',*c)
        write(VOICE+0x428+i*8,'Q',COEFS+i*20)
        write(VOICE+0x488+i*8,'Q',DELTAS+i*20)
        write(STATES_PTR+i*8,'Q',STATES+i*8)
    write(INPUT_DESC+0x20,'Q',INPUT)
    write(OUTPUT_DESC+0x28,'Q',OUTPUT)
    write(INPUT,str(len(samples))+'f',*samples)
    call(0x1402ccc80,VOICE,INPUT_DESC,OUTPUT_DESC)
    return list(read(OUTPUT,str(len(samples))+'f'))

def packed(values): return struct.pack('<'+str(len(values))+'f',*values)
started=time.monotonic()
positions=[(0,0),(1,0),(0,1),(1,1),(.5,.5),(.137,.829),(.933,.247)]
cases=0; sample_count=0; max_difference=0
rng=random.Random(38117)
for rate_index,sample_rate in enumerate((44100,48000,96000,192000)):
    for filter_id in range(33):
        for freq,res in positions:
            original=original_coefficients(filter_id,rate_index,freq,res)
            port=bank.coefficients(filter_id,freq,res,sample_rate)
            assert all(packed(a)==packed(b) for a,b in zip(original,port)),(filter_id,sample_rate,freq,res,original,port)
            samples=[.001]+[0.0]*31+[f32(rng.uniform(-.0001,.0001)) for _ in range(32)]
            expected=original_process(original,samples)
            actual=Filter(port).process(samples)
            diff=max(abs(a-b) for a,b in zip(actual,expected))
            max_difference=max(max_difference,diff)
            assert packed(actual)==packed(expected),(filter_id,sample_rate,freq,res,diff)
            cases+=1; sample_count+=len(samples)
    print('Passed sample rate',sample_rate,flush=True)

# Exhaustive packed decoder verification, using original conversion routine.
for start in range(0,65536,30):
    words=list(range(start,min(65536,start+30)))
    padding=words+[65535]*(30-len(words))
    write(VOICE+0x420,'I',6)
    write(VOICE+0x2a8,'f',4.0)
    write(VOICE+0x3b0,'30H',*padding)
    call(0x1402ced30,VOICE,VOICE+0x3b0,VOICE+0x530)
    expected=[]
    for i in range(6):
        # Values 1 and 3 are stored directly, value 4 is multiplied by 4.
        c=read(VOICE+0x530+i*20,'5f')
        d=[decode_word(w) for w in padding[i*5:i*5+5]]
        calc=(f32(f32(4*d[0])+d[1]),d[1],f32(f32(4*d[2])+d[3]),d[3],f32(4*d[4]))
        assert packed(c)==packed(calc),(start,i,c,calc)
print('Passed all 65536 packed coefficient values',flush=True)
report={'source_sha256':hashlib.sha256(pe.data).hexdigest(),'method':'Isolated x86-64 instruction emulation of original factory-table copy, interpolation, coefficient conversion and mono six-section processing. Original ldexp call replaced with Python math.ldexp. No sampler process launched or modified.',
    'factory_filter_count':33,'sample_rates':[44100,48000,96000,192000],
    'control_positions':positions,'coefficient_and_audio_cases':cases,'audio_samples_compared':sample_count,
    'packed_decoder_values_checked':65536,'audio_comparison':'bit-for-bit IEEE binary32 equality',
    'maximum_absolute_audio_difference':max_difference,'elapsed_seconds':round(time.monotonic()-started,2),
    'excluded':'Whole-application rendering, SSE alternative kernels, modulation smoothing, adaptive gain/distortion and UI-to-normalized-control mapping'}
(OUT/'validation.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report,indent=2))

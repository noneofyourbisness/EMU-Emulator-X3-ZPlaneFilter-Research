from recover_extended import *
from emux_extended import ExtendedBank, PROGRAMMABLE_NAMES, coefficients_from_frames
from emux_filters import SAMPLE_RATES

extended=ExtendedBank.load(OUT/'extended-bank.json')
KERNELS={1:0x1402cbed0,2:0x1402cc200,3:0x1402cc690,6:0x1402ccc80}

def original_coefficients(frames,freq,res):
    count=len(frames[0])
    if not count: return []
    write(VOICE+0x2b0,'f',freq)
    write(VOICE+0x1e8,'f',res)
    call(0x1402cf470,VOICE)
    call(0x1402ced30,VOICE,VOICE+0x3b0,VOICE+0x530)
    return [read(VOICE+0x530+i*20,'5f') for i in range(count)]

def original_process(coefficients,samples):
    count=len(coefficients)
    if not count: return samples
    write(VOICE+0x28,'I',len(samples))
    write(VOICE+0x420,'I',count)
    write(VOICE+0x620,'Q',STATES_PTR)
    uc.mem_write(STATES,b'\0'*0x100)
    uc.mem_write(DELTAS,b'\0'*0x100)
    for i,c in enumerate(coefficients):
        write(COEFS+i*20,'5f',*c)
        write(VOICE+0x428+i*8,'Q',COEFS+i*20)
        write(VOICE+0x488+i*8,'Q',DELTAS+i*20)
        write(STATES_PTR+i*8,'Q',STATES+i*8)
    write(INPUT_DESC+0x20,'Q',INPUT)
    write(OUTPUT_DESC+0x28,'Q',OUTPUT)
    write(INPUT,str(len(samples))+'f',*samples)
    call(KERNELS[count],VOICE,INPUT_DESC,OUTPUT_DESC)
    return list(read(OUTPUT,str(len(samples))+'f'))

def packed(values): return struct.pack('<'+str(len(values))+'f',*values)

if __name__=='__main__':
    rng=random.Random(43111)
    positions=[(0,0),(1,0),(0,1),(1,1),(.5,.5),(.137,.829),(.933,.247)]
    vectors=[]
    cases=0
    def check(frames,gain,ported,freq,res,label):
        global cases
        expected=original_coefficients(frames,freq,res)
        assert packed([x for row in expected for x in row])==packed([x for row in ported for x in row]),('coefs',label,expected,ported)
        samples=[.001]+[0.0]*31+[f32(rng.uniform(-.0001,.0001)) for _ in range(32)]
        expected_audio=original_process(expected,samples)
        actual=Filter(ported).process(samples)
        assert packed(actual)==packed(expected_audio),('audio',label,max(abs(a-b) for a,b in zip(actual,expected_audio)))
        vectors.append(dict(label=label,frequency=freq,resonance=res,frames=frames,gain=gain,coefficients=expected,input=samples,output=expected_audio))
        cases+=1
    for rate in range(4):
        for index,(name,address) in enumerate(STATIC):
            for freq,res in positions:
                frames,gain=setup(address,rate,res=res)
                assert frames==extended.frames(index,SAMPLE_RATES[rate])
                check(frames,gain,extended.coefficients(index,freq,res,SAMPLE_RATES[rate]),freq,res,[name,rate])
    print('17 standard filters passed',cases,flush=True)
    addresses=[0x1402e73e0,0x1402e74c0,0x1402e7590,0x1402e76a0]
    for kind,address in zip(PROGRAMMABLE_NAMES,addresses):
        for rate in range(4):
            for iteration in range(130):
                p=([0]*6 if iteration==0 else [127]*6 if iteration==1 else [64]*6 if iteration==2 else [rng.randrange(128) for _ in range(6)])
                freq,res=positions[iteration%len(positions)]
                # Explicitly sample the entire 16-level selector, and its boundaries.
                if iteration>=100: res=f32((iteration-100)/29)
                param=bytearray(0x100);param[0x16:0x1c]=bytes(p)
                frames,gain=setup(address,rate,param,res)
                port_frames=extended.morph_frames(kind,p,res,SAMPLE_RATES[rate])
                assert frames==port_frames,('frames',kind,rate,p,res,frames,port_frames)
                check(frames,gain,extended.morph_coefficients(kind,p,freq,res,SAMPLE_RATES[rate]),freq,res,[kind,rate,p])
        print(kind,'passed',flush=True)
    designer_shapes=set()
    for rate in range(4):
        for iteration in range(150):
            sections=[];param=bytearray(0x100)
            for s in range(6):
                shape=(int(s<iteration%7)*(iteration//7%3+1)) if iteration<63 else rng.randrange(4)
                values=[rng.randrange(128) for _ in range(4)]
                if iteration==0: values=[0,0,127,127]
                sections.append((shape,*values))
                param[0x20+s*6:0x25+s*6]=bytes([shape,*values])
                designer_shapes.add(shape)
            freq,res=positions[iteration%len(positions)]
            frames,gain=setup(0x1402e7c10,rate,param,res)
            port_frames=extended.designer_frames(sections,res,SAMPLE_RATES[rate])
            assert frames==port_frames,('designer',rate,sections,res,frames,port_frames)
            check(frames,gain,extended.designer_coefficients(sections,freq,res,SAMPLE_RATES[rate]),freq,res,['Morph Designer',rate,sections])
    print('Morph Designer passed',flush=True)
    (ROOT/'research'/'extended-vectors.json').write_text(json.dumps(vectors),encoding='utf-8')
    report=dict(standard_filters=17,programmable_filters=5,sample_rates=list(SAMPLE_RATES),
        coefficient_and_audio_cases=cases,audio_samples_compared=cases*64,
        standard_cases=476,morph_cases=2080,designer_cases=600,
        comparison='Bit-for-bit binary32 coefficients and mono audio, exact packed setup frames',
        designer_shapes_checked=sorted(designer_shapes),designer_section_counts_checked=[0,1,2,3,4,5,6],
        excluded='Full sampler rendering, adaptive gain, dynamic coefficient ramps, UI Hz/dB mapping, alternative SIMD kernels')
    (OUT/'extended-validation.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(report)

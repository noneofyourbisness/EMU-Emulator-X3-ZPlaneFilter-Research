#include "../emux_control.hpp"
#include <fstream>
#include <iostream>
#include <stdexcept>
std::ifstream data("control-vectors.bin",std::ios::binary);
template<class T> T read(){ T x;data.read(reinterpret_cast<char*>(&x),sizeof x);if(!data)throw std::runtime_error("truncated vectors");return x; }
void equal(bool yes){if(!yes)throw std::runtime_error("original/C++ mismatch");}
int main(){
    unsigned ticks=0;auto n=read<unsigned>();
    for(unsigned i=0;i<n;++i){auto rate=read<unsigned>(),q=read<unsigned>();auto initial=read<float>(),step=read<float>();auto count=read<unsigned>();
        emux::ControllerLag lag;lag.prepare(rate,q,initial);equal(lag.step()==step);
        for(unsigned j=0;j<count;++j){auto change=read<unsigned>();auto target=read<float>(),value=read<float>();auto active=read<unsigned>();
            if(change)lag.set_target(target);equal(lag.tick()==value);equal(lag.active()==bool(active));++ticks;}
    }
    n=read<unsigned>();for(unsigned i=0;i<n;++i){auto b=read<unsigned>(),r=read<unsigned>(),q=read<unsigned>();equal(emux::desktop_control_quantum(b,r)==q);}
    for(unsigned i=0;i<128;++i)equal(emux::midi_cc7(i)==read<float>());
    std::cout<<"Exact original/C++ match: "<<ticks<<" controller ticks, "<<n<<" selector cases, 128 MIDI values\n";
}

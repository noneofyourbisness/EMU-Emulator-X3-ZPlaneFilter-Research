import bisect,json,pathlib,struct,sys
sys.path.insert(0,str(pathlib.Path(__file__).parent/'python-deps'))
from capstone import Cs,CS_ARCH_X86,CS_MODE_64
from inspect_emulator import PE,OUT
pe=PE(r'C:\Program Files\E-MU\Emulator X3\EmulatorX.exe')
md=Cs(CS_ARCH_X86,CS_MODE_64); md.skipdata=True
rva,size=pe.dirs[3]
unwind=[struct.unpack_from('<III',pe.data,pe.offset(rva)+i) for i in range(0,size,12)]
starts=[x[0]+pe.base for x in unwind]
def bounds(va):
    i=bisect.bisect_right(starts,va)-1
    if i >= 0:
        a,b,_=unwind[i]
        if pe.base+a <= va < pe.base+b:
            while i+1 < len(unwind) and unwind[i+1][0] == b:
                i+=1
                b=unwind[i][1]
            return pe.base+a,pe.base+b
    return va,va+200
def disasm(va):
    a,b=bounds(va)
    off=pe.offset(a-pe.base)
    return '\n'.join(f'{i.address:016x}: {i.mnemonic:8} {i.op_str}' for i in md.disasm(pe.data[off:off+b-a],a))
def all_matches(needle):
    off=0
    while True:
        off=pe.data.find(needle,off)
        if off < 0: break
        yield off
        off+=1

if __name__=='__main__':
    if len(sys.argv)>1:
        for va in sys.argv[1:]: print(disasm(int(va,16)))
        sys.exit()
    classes={}
    for cname in ['CPhantomFilterP2k','CPhantomMorphDesigner','CPhantomMorph2','CPhantomMorphLPX','CPhantomMorphLP','CPhantomMorph1','CPhantomMorph1Basic','CPhantomFilterPlugin','CPhantomFilterPluginList','CPhantomFilter','CPhantomE4Filter','CPhantomRTFilter','CPhantomRTSSEFilter','CPhantomLP2Pole','CPhantomLP4Pole','CPhantomLP6Pole','CPhantomHP2Pole','CPhantomHP4Pole','CPhantomBP2Pole','CPhantomBP4Pole','CPhantomSweptEq1','CPhantomSweptEq2','CPhantomSweptEq3','CPhantomContraryBandpass','CPhantomPhaser1','CPhantomPhaser2','CPhantomBatman','CPhantomFlanger1','CPhantomVocal1','CPhantomVocal2']:
        typeoff=pe.data.index(('.?AV'+cname+'@@').encode())-16
        typerva=pe.va(typeoff)-pe.base
        vtables=[]
        for ref in all_matches(struct.pack('<I',typerva)):
            col=ref-12
            if pe.u32(col) not in (0,1): continue
            colva=pe.va(col)
            if not colva or (pe.u32(col)==1 and pe.u32(col+20)!=colva-pe.base): continue
            for ptr in all_matches(struct.pack('<Q',colva)):
                funcs=[]
                for i in range(40):
                    v=pe.u64(ptr+8+i*8)
                    if not pe.base+0x1000 <= v < pe.base+0x609000: break
                    funcs.append(hex(v))
                if funcs: vtables.append({'va':hex(pe.va(ptr+8)),'col_va':hex(colva),'functions':funcs})
        classes[cname]=vtables
    (OUT/'filter-vtables.json').write_text(json.dumps(classes,indent=2),encoding='utf-8')
    print(json.dumps(classes,indent=2))
    text=[]
    for name,vt in classes.items():
        for v in vt:
            for i,va in enumerate(v['functions']):
                text.append(f'\n\n{name} slot {i} {va}\n'+disasm(int(va,16)))
    (pathlib.Path(__file__).parent/'filter-disassembly.txt').write_text(''.join(text),encoding='utf-8')

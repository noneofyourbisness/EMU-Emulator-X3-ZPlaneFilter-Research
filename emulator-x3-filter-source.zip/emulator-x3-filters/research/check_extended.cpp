#include "../emux_extended.hpp"
#include <iostream>
#include <cstring>
template<class T> T read(std::ifstream& f) { T v{};if(!f.read(reinterpret_cast<char*>(&v),sizeof v))throw std::runtime_error("Truncated vectors");return v; }
bool equal(float a,float b) { return std::memcmp(&a,&b,4)==0; }
int main() {
    auto bank=emux::ExtendedBank::from_table_files("standard-bank.bin","morph-support.bin");
    std::ifstream f("research/extended-vectors.bin",std::ios::binary);
    const auto total=read<unsigned>(f);
    const unsigned rates[]={44100,48000,96000,192000};
    for(unsigned test=0;test<total;++test) {
        const auto kind=read<unsigned>(f),index=read<unsigned>(f),rate=read<unsigned>(f),count=read<unsigned>(f);
        emux::MorphParameters p{};for(auto& v:p)v=read<unsigned>(f);
        std::array<emux::DesignerSection,6> sections{};
        for(auto& s:sections) {
            s.shape=static_cast<emux::Shape>(read<unsigned>(f));
            s.start_frequency=read<unsigned>(f);s.start_gain=read<unsigned>(f);
            s.end_frequency=read<unsigned>(f);s.end_gain=read<unsigned>(f);
        }
        const auto freq=read<float>(f),res=read<float>(f),gain=read<float>(f);
        emux::PackedConfiguration packed;
        if(kind==0)packed=bank.frames(index,rates[rate]);
        if(kind==1)packed=bank.morph_frames(static_cast<emux::MorphKind>(index),p,res,rates[rate]);
        if(kind==2)packed=bank.designer_frames(sections,res,rates[rate]);
        if(packed.sections!=count || !equal(packed.gain_factor,gain))throw std::runtime_error("Count or gain mismatch");
        for(const auto& frame:packed.frames)for(unsigned i=0;i<count;++i)for(auto word:frame[i])
            if(word!=read<std::uint16_t>(f))throw std::runtime_error("Frame mismatch at "+std::to_string(test));
        auto config=emux::coefficients_from_frames(packed,freq,res);
        for(unsigned i=0;i<count;++i)for(auto v:config.coefficients[i])
            if(!equal(v,read<float>(f)))throw std::runtime_error("Coefficient mismatch at "+std::to_string(test));
        std::array<float,64> input{},expected{},actual{};
        for(auto& v:input)v=read<float>(f);
        for(auto& v:expected)v=read<float>(f);
        emux::Filter filter(config.coefficients,config.sections);
        filter.process(input.data(),actual.data(),17);
        filter.process(input.data()+17,actual.data()+17,47);
        for(unsigned i=0;i<64;++i)if(!equal(actual[i],expected[i]))throw std::runtime_error("Audio mismatch at "+std::to_string(test));
        filter.reset();filter.process(input.data(),actual.data(),64);
        for(unsigned i=0;i<64;++i)if(!equal(actual[i],expected[i]))throw std::runtime_error("Reset mismatch");
    }
    if(f.get()!=std::char_traits<char>::eof())throw std::runtime_error("Extra vector bytes");
    std::cout<<"Passed "<<total<<" cases: original frames, coefficients, audio, split processing and reset.\n";
}

"""Recover other X3 filter tables through isolated original setup routines."""
from emulation import *

STATIC = [
 ('2 Pole Lowpass',0x1402e6200),('4 Pole Lowpass',0x1402e62c0),
 ('6 Pole Lowpass',0x1402e63a0),('2 Pole Highpass',0x1402e6480),
 ('4 Pole Highpass',0x1402e6540),('2 Pole Bandpass',0x1402e6860),
 ('4 Pole Bandpass',0x1402e6920),('Contrary Bandpass',0x1402e6a00),
 ('Swept EQ 1 Octave',0x1402e6620),('Swept EQ 2/1 Octave',0x1402e66e0),
 ('Swept EQ 3/1 Octave',0x1402e67a0),('Phaser 1',0x1402e6ac0),
 ('Phaser 2',0x1402e6bb0),('Bat Phaser',0x1402e6ca0),
 ('Flanger Lite',0x1402e6d90),('Vocal Ah-Ay-Ee',0x1402e6e70),
 ('Vocal Oo-Ah',0x1402e6f50)]
PARAM=MEM+0x7000

def setup(address,rate,params=None,res=.5):
    uc.mem_write(VOICE,b'\0'*0x1000)
    uc.mem_write(PARAM,b'\0'*0x100)
    if params is not None: uc.mem_write(PARAM,bytes(params))
    write(PLUGIN+0xc,'H',rate)
    write(VOICE+0x2a8,'f',4.0)
    write(VOICE+0x1e8,'f',res)
    call(address,PLUGIN,PARAM,VOICE)
    count=read(VOICE+0x420,'I')[0]
    frames=[[list(read(VOICE+0x2c0+f*60+s*10,'5H')) for s in range(count)] for f in range(4)]
    return frames,read(VOICE+0x2a8,'f')[0]

def support(rva,fmt):
    return list(struct.unpack_from('<'+fmt,pe.data,pe.offset(rva)))

if __name__=='__main__':
    filters=[]
    binary=bytearray()
    for name,address in STATIC:
        rates=[]
        for rate in range(4):
            frames,gain=setup(address,rate)
            rates.append(frames)
            assert (frames,gain)==setup(address,rate,[127]*0x100,.937)
            for f in frames:
                for row in f: binary+=struct.pack('<5H',*row)
        filters.append(dict(name=name,setup_va=hex(address),sections=len(rates[0][0]),
                            gain_factor=gain,frames=rates))
        print(name,len(rates[0][0]),gain)
    tables=dict(morph_base=support(0x6f5d80,'4I'),morph_slope=support(0x6f5d90,'4I'),
        lp_morph=support(0x6f5da0,'96H'),expression=support(0x6f5e60,'48H'),
        shelf_base=support(0x6f5ec0,'4I'),shelf_slope=support(0x6f5ed0,'4I'),
        neutral=support(0x6f5ee0,'5H'),designer_base=support(0x6f5ef0,'4I'),
        designer_slope=support(0x6f5f00,'4I'),
        resonance_scale=support(0x70faf8,'f')[0],index_scale=support(0x674e2c,'f')[0])
    data=dict(format='emux-extended-v1',source_sha256=SUPPORTED_SHA256 if 'SUPPORTED_SHA256' in globals() else hashlib.sha256(pe.data).hexdigest(),
              filters=filters,support=tables)
    (OUT/'extended-bank.json').write_text(json.dumps(data,indent=2),encoding='utf-8')
    (OUT/'standard-bank.bin').write_bytes(binary)
    support_binary=bytearray()
    for key,fmt in [('morph_base','4I'),('morph_slope','4I'),('lp_morph','96H'),
                    ('expression','48H'),('shelf_base','4I'),('shelf_slope','4I'),
                    ('neutral','5H'),('designer_base','4I'),('designer_slope','4I'),
                    ('resonance_scale','f'),('index_scale','f')]:
        values=tables[key] if isinstance(tables[key],list) else [tables[key]]
        support_binary+=struct.pack('<'+fmt,*values)
    (OUT/'morph-support.bin').write_bytes(support_binary)
    print('Support',tables)

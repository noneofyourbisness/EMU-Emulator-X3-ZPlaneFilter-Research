# X3 Q0 / Q100 batch comparison, 5 October 2026

Both supplied batches are complete: **56 recordings each**, comprising No Filter plus 55 filters using Steps. All 112 WAVs are audible, finite, full-length stereo float32 at 44.1 kHz, 1,058,400 frames each. Both channels duplicate mono bit-for-bit. All MIDI events match the harness schedule, with ASIO buffer and internal quantum logged as 256, note 60 / velocity 127. Archive members were read and their CRCs checked. No detailed traces are present; direct Q readback awaits the separate takes the user will send afterward.

## Loaded VST3 result

All **110 filtered recordings** were freshly compared against the released **0.5.0 VST3** in the JUCE host. Each uses its own No Filter bus recording, recorded CC1 timestamps, Standalone timing, 256-frame host blocks, user-reported Q0/Q100 and matching default programmable settings. Input/output gain is 0 dB, mix 100%, guard off and optional X3 reference output off. No gain or delay fitting, input inversion or EQ correction was used.

Held-note comparison window: **[55,313, 968,035)** frames, excluding startup and note-off. Those parts are measured separately in the JSON/CSV. Results are normalized RMS waveform error against X3:

| Batch | Median held-note error | Worst held-note error | Largest difference |
|---|---:|---:|---|
| Q0 | 0.000952% | 0.021961% | Zoom Peaks |
| Q100 | 0.001980% | 0.067164% | Meaty Gizmo |

Ooh to Eee has **0.000861% at Q0** and **0.002073% at Q100**. Empty/default Morph Designer matches No Filter and the VST3 exactly throughout the held window. The two complete No Filter recordings are **bit-identical**, so the batches use an unchanged reference saw output.

![Comparison](comparison.png)

These results extend measured coverage from Q50 to both extremes. They are waveform error percentages for the tested conditions, not a single overall accuracy score or complete sampler bit-exactness. They do not replace the earlier raw-internal-input proofs: ordinary effect mode processes X3's already-amplified No Filter bus, while X3 filters earlier in its voice chain. Different float rounding at those signal levels is a possible source of the small residuals, especially with feedback at high Q; the audio alone cannot establish their exact cause.

## Q consistency and remaining tracing

For both batches, the correctly labelled Q render beats the opposite-Q render on **54 of 55 filters**; empty Designer is equal because its sections are inactive. The opposite-Q median error is **122.784%** for Q0 recordings and **96.496%** for Q100. This supports the batch labels acoustically, but does not independently read X3's actual Q value. No claim of raw Q/coefficient/state validation is made until detailed traces arrive.

The largest Q100 residual is Meaty Gizmo (**0.067164%**), followed by Contrary Bandpass (**0.037195%**) and Peak/Shelf Morph (**0.032360%**). The largest Q0 residual is Zoom Peaks (**0.021961%**), followed closely by Peak/Shelf Morph (**0.021939%**). These are useful next targets for internal input/coefficient/state comparisons after the planned Ooh traces. No full-batch repeat is needed.

The captures contain raw float peaks up to 8.16665 (Q0) and 83.11053 (Q100); values above 1 are preserved by the float WAV format and numerical comparisons. Listening examples in this package use a shared attenuation for each X3/VST3 pair, explicitly recorded in `listening-examples.json`.

## Files and status

`measurements.json` and `per-filter-comparison.csv` contain every filter's held, moving, settled, startup, release and whole-file results, without hiding release differences. `summary.json` records the VST3 hash, archive hashes, limits and opposite-Q diagnostic. Inventories record all event/audio checks. `reproduce/` contains the identical dry input and host configurations; see `REPRODUCE.md`.

The library and JUCE research folders include these findings. The VST3 binary and DSP remain unchanged at 0.5.0: this batch provides validation, and does not yet identify a verified code correction. Full sampler/loop lifetime, active programmable frames and live true-stereo processing remain separate work. Direct Q verification and internal-state comparisons await the two detailed Ooh takes.

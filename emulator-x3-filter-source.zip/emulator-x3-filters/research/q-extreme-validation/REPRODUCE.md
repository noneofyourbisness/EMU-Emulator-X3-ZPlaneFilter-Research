# Repeat the loaded-VST3 comparisons

Build `XPlaneTests` from the supplied JUCE source. In each `reproduce/*-vst3-config.json`, replace the three placeholder paths: the 0.5.0 VST3 bundle, the included `dry.wav`, and a fresh output folder. Then run the host with `--batch` followed by that JSON path. The host uses recorded CC1 timestamps and matching parameter overrides. Original render hashes are supplied for bitwise reproduction checks.

The dry WAV is from Q0; its complete float audio is bit-identical to Q100's No Filter take. Outputs are mono float32 `.f32` files starting at note-on, absolute frame 44,288. Prefix 44,288 zeros to align with the original user WAVs. Compare [55,313,968,035) for held-note results; the JSON/CSV separately measure moving, settled, startup, release and full-file windows. NRMSE is 100*norm(render-X3)/norm(X3), calculated in float64, without fitted delay/gain. The rendered output remains float32.

Original X3 wet WAVs remain in the user ZIPs and are not duplicated in this result package. Their archive hashes and the decoded per-take audio hashes are in the inventories. No executable or licence/activation mechanism is included. Current original binary hash and comparison limits are in `summary.json`.

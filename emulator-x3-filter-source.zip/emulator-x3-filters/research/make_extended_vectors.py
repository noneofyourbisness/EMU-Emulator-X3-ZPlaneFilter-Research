from pathlib import Path
import json,struct,sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from emux_extended import STANDARD_NAMES,PROGRAMMABLE_NAMES

vectors=json.loads((ROOT/'research'/'extended-vectors.json').read_text())
with (ROOT/'research'/'extended-vectors.bin').open('wb') as f:
    f.write(struct.pack('<I',len(vectors)))
    for v in vectors:
        label=v['label']; name,rate=label[:2]
        if name in STANDARD_NAMES: kind,index=0,STANDARD_NAMES.index(name);params=[0]*6;designer=[(0,0,0,0,0)]*6
        elif name in PROGRAMMABLE_NAMES[:4]: kind,index=1,PROGRAMMABLE_NAMES.index(name);params=label[2];designer=[(0,0,0,0,0)]*6
        else: kind,index=2,0;params=[0]*6;designer=label[2]
        count=len(v['coefficients'])
        f.write(struct.pack('<4I',kind,index,rate,count))
        f.write(struct.pack('<6I',*params))
        f.write(struct.pack('<30I',*[x for row in designer for x in row]))
        f.write(struct.pack('<3f',v['frequency'],v['resonance'],v['gain']))
        f.write(struct.pack('<'+str(count*20)+'H',*[x for frame in v['frames'] for row in frame for x in row]))
        f.write(struct.pack('<'+str(count*5)+'f',*[x for row in v['coefficients'] for x in row]))
        f.write(struct.pack('<64f',*v['input']))
        f.write(struct.pack('<64f',*v['output']))
print('Wrote',len(vectors),'C++ vectors')

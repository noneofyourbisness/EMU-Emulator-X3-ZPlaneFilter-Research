import hashlib,json,math,pathlib,random,struct,sys,time
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'research'/'python-deps'))
sys.path.insert(0,str(ROOT))
from unicorn import Uc,UC_ARCH_X86,UC_MODE_64,UC_HOOK_CODE
from unicorn.x86_const import *
from inspect_emulator import PE,OUT
from emux_filters import FactoryBank,Filter,decode_word,f32

pe=PE(r'C:\Program Files\E-MU\Emulator X3\EmulatorX.exe')
bank=FactoryBank.from_executable(pe.path)
uc=Uc(UC_ARCH_X86,UC_MODE_64)
uc.mem_map(pe.base,0x2100000)
for s in pe.sections:
    uc.mem_write(pe.base+s['rva'],pe.data[s['raw_offset']:s['raw_offset']+s['raw_size']])
MEM=0x20000000; STACK=MEM+0x80000; STOP=MEM+0xf0000
uc.mem_map(MEM,0x100000)
def write(address,fmt,*values): uc.mem_write(address,struct.pack('<'+fmt,*values))
def read(address,fmt): return struct.unpack('<'+fmt,uc.mem_read(address,struct.calcsize('<'+fmt)))
def hook(uc,address,size,user):
    if address!=0x14052b650: return
    xmm=uc.reg_read(UC_X86_REG_XMM0)
    value=struct.unpack('<d',xmm.to_bytes(16,'little')[:8])[0]
    exp=uc.reg_read(UC_X86_REG_EDX)
    if exp >= 0x80000000: exp-=0x100000000
    result=math.ldexp(value,exp)
    uc.reg_write(UC_X86_REG_XMM0,int.from_bytes(struct.pack('<d',result)+b'\0'*8,'little'))
    rsp=uc.reg_read(UC_X86_REG_RSP)
    ret=read(rsp,'Q')[0]
    uc.reg_write(UC_X86_REG_RSP,rsp+8)
    uc.reg_write(UC_X86_REG_RIP,ret)
uc.hook_add(UC_HOOK_CODE,hook,begin=0x14052b650,end=0x14052b650)

def call(address,rcx=0,rdx=0,r8=0,r9=0):
    rsp=STACK-8
    write(rsp,'Q',STOP)
    uc.reg_write(UC_X86_REG_RSP,rsp)
    uc.reg_write(UC_X86_REG_RCX,rcx)
    uc.reg_write(UC_X86_REG_RDX,rdx)
    uc.reg_write(UC_X86_REG_R8,r8)
    uc.reg_write(UC_X86_REG_R9,r9)
    uc.emu_start(address,STOP,count=5000000)
    assert uc.reg_read(UC_X86_REG_RIP)==STOP,'Routine failed to return'

VOICE=MEM; PLUGIN=MEM+0x1000; INPUT_DESC=MEM+0x2000; OUTPUT_DESC=MEM+0x2100
COEFS=MEM+0x3000; DELTAS=MEM+0x4000; STATES_PTR=MEM+0x5000; STATES=MEM+0x6000
INPUT=MEM+0x10000; OUTPUT=MEM+0x20000


import json,pathlib,sys
sys.path.insert(0,str(pathlib.Path(__file__).parent/'python-deps'))
import pefile
p=pefile.PE(r'C:\Program Files\E-MU\Emulator X3\EmulatorX.exe')
e=next(a for a in p.DIRECTORY_ENTRY_RESOURCE.entries if a.id==6)
result={}
for b in e.directory.entries:
    for c in b.directory.entries:
        data=p.get_data(c.data.struct.OffsetToData,c.data.struct.Size); off=0
        for i in range(16):
            n=int.from_bytes(data[off:off+2],'little'); off+=2
            text=data[off:off+n*2].decode('utf-16le'); off+=n*2
            if text: result[(b.id-1)*16+i]=text
print('Version',p.VS_FIXEDFILEINFO[0].FileVersionMS,p.VS_FIXEDFILEINFO[0].FileVersionLS)
print({k:v for k,v in result.items() if any(n in v for n in ['Ace of','MegaSweep','Klang','Ooh-To','No Filter','Lowpass'])})
(pathlib.Path(__file__).parent/'resource-strings.json').write_text(json.dumps(result,indent=2),encoding='utf-8')

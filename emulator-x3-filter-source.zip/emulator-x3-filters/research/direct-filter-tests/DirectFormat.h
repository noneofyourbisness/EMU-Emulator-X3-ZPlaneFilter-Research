#pragma once
#define NOMINMAX
#include <windows.h>
#include <cstdint>
#include <cstdio>
namespace direct {
constexpr unsigned Magic=0x58334431,Version=2,MaxCases=8192,Stages=6,MaxTableBytes=65536;
enum Stage:unsigned { Frames,Gain,Coefficients,Increments,Audio,State };
struct Difference {unsigned stage=0,block=0,element=0,expected=0,actual=0;};
struct Result {
 unsigned id=0,filter=0,rate=0,channels=0,variant=0,mode=0,profile=0,blocks=0;
 unsigned sections=0,fault=0,firstSet=0,nonfiniteAudio=0;
 uint64_t values[Stages]{},differences[Stages]{};Difference first{};
};
struct Shared {
 unsigned magic=Magic,version=Version,tableBytes[3]{};
 volatile LONG status=0,completed=0,total=0,cancel=0;
 unsigned limit=0,reserved=0;unsigned char tables[3][MaxTableBytes]{};Result results[MaxCases]{};
};
inline void name(wchar_t* s,size_t n,DWORD pid){swprintf_s(s,n,L"Local\\X3DirectTests-v2-%lu",pid);}
}

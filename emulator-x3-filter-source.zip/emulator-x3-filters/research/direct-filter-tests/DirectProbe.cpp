#include "DirectFormat.h"
#include "Dsp/emux_extended.hpp"
#include "Dsp/emux_runtime.hpp"
#include <sstream>
#include <memory>
#include <cstring>
#include <xmmintrin.h>
namespace {
using Setup=void(*)(void*,void*,void*);using Unary=void(*)(void*);using Kernel=void(*)(void*,void*,void*);
direct::Shared* shared=nullptr;HANDLE mapping=nullptr;uintptr_t image=0;
const uintptr_t setups[17]={0x2e6200,0x2e62c0,0x2e63a0,0x2e6480,0x2e6540,0x2e6860,0x2e6920,0x2e6a00,0x2e6620,0x2e66e0,0x2e67a0,0x2e6ac0,0x2e6bb0,0x2e6ca0,0x2e6d90,0x2e6e70,0x2e6f50};
const uintptr_t morphSetups[5]={0x2e73e0,0x2e74c0,0x2e7590,0x2e76a0,0x2e7c10};
template<class T>void put(void* base,size_t offset,T v){std::memcpy(static_cast<char*>(base)+offset,&v,sizeof v);}
template<class T>T get(const void* base,size_t offset){T v;std::memcpy(&v,static_cast<const char*>(base)+offset,sizeof v);return v;}
unsigned bits(float x){unsigned v;std::memcpy(&v,&x,4);return v;}
struct Rng {unsigned v;unsigned next(){v=v*1664525u+1013904223u;return v;}float sample(){return (float(int(next()>>8)-8388608)/8388608.0f)*.001f;}};
void check(direct::Result& r,unsigned stage,unsigned block,unsigned element,unsigned expected,unsigned actual){++r.values[stage];if(expected==actual)return;++r.differences[stage];if(!r.firstSet){r.firstSet=1;r.first={stage,block,element,expected,actual};}}
struct alignas(16) Scratch {
 unsigned char voice[0x1000]{},plugin[0x100]{},param[0x100]{},inputDesc[0x80]{},outputDesc[0x80]{};
 alignas(16) float coefficients[6][8]{},delta[6][8]{};
 float states[2][6][2]{},input[1024]{},output[1024]{};
 float* statePointers[2][6]{};
};
struct PortBanks {
 emux::Table words{};emux::FactoryBank factory;emux::ExtendedBank extended;
 static emux::Table factoryWords(){emux::Table t{};if(shared->tableBytes[0]!=sizeof(t))throw std::runtime_error("Wrong factory table size");for(unsigned i=0;i<t.size();++i)t[i]=get<uint16_t>(shared->tables[0],i*2);return t;}
 static emux::ExtendedBank extra(){std::istringstream a(std::string(reinterpret_cast<char*>(shared->tables[1]),shared->tableBytes[1]),std::ios::binary),b(std::string(reinterpret_cast<char*>(shared->tables[2]),shared->tableBytes[2]),std::ios::binary);return emux::ExtendedBank::from_streams(a,b);}
 PortBanks():words(factoryWords()),factory(words),extended(extra()){}
};
struct Parameters {emux::MorphParameters morph{};std::array<emux::DesignerSection,6> designer{};};
Parameters parameters(unsigned profile,unsigned filter){Parameters p;Rng rng{65102026u+filter*307u+profile*7919u};for(unsigned i=0;i<6;++i)p.morph[i]=profile==0?0:profile==1?127:profile==2?(rng.next()>>24)&127:emux::MorphParameters{32,96,64,48,112,64}[i];
 for(unsigned i=0;i<6;++i){auto& s=p.designer[i];s.shape=static_cast<emux::Shape>(profile==0?0:profile==1?1:profile==2?(i<3?i+1:0):i%3+1);s.start_frequency=profile==1?32:(rng.next()>>24)&127;s.start_gain=profile==1?64:(rng.next()>>24)&127;s.end_frequency=profile==1?96:(rng.next()>>24)&127;s.end_gain=profile==1?64:(rng.next()>>24)&127;}return p;}
emux::PackedConfiguration portFrames(const PortBanks& banks,unsigned filter,unsigned rate,const Parameters& p,float q){
 if(filter<17)return banks.extended.frames(filter,rate);
 if(filter>=50)return filter==54?banks.extended.designer_frames(p.designer,q,rate):banks.extended.morph_frames(static_cast<emux::MorphKind>(filter-50),p.morph,q,rate);
 const unsigned rateIndex=rate==44100?0:rate==48000?1:rate==96000?2:3;
 emux::PackedConfiguration pack;pack.sections=6;for(unsigned f=0;f<4;++f)for(unsigned s=0;s<6;++s)for(unsigned k=0;k<5;++k)pack.frames[f][s][k]=banks.words[(filter-17)*480+rateIndex*120+s*20+f*5+k];return pack;
}
emux::Configuration portConfig(const PortBanks& banks,unsigned filter,unsigned rate,const emux::PackedConfiguration& frames,float morph,float q){
 if(filter>=17&&filter<50)return {banks.factory.coefficients(filter-17,morph,q,rate),6};return emux::coefficients_from_frames(frames,morph,q);
}
unsigned originalConfig(Scratch& s,unsigned filter,unsigned rate,const Parameters& p,float morph,float q){
 std::memset(s.voice,0,sizeof s.voice);std::memset(s.plugin,0,sizeof s.plugin);std::memset(s.param,0,sizeof s.param);
 put<uint16_t>(s.plugin,0xc,rate==44100?0:rate==48000?1:rate==96000?2:3);put<float>(s.voice,0x2a8,4.0f);put<float>(s.voice,0x1e8,q);
 for(unsigned i=0;i<6;++i){s.param[0x16+i]=static_cast<unsigned char>(p.morph[i]);const auto& d=p.designer[i];unsigned o=0x20+i*6;s.param[o]=static_cast<unsigned char>(d.shape);s.param[o+1]=static_cast<unsigned char>(d.start_frequency);s.param[o+2]=static_cast<unsigned char>(d.start_gain);s.param[o+3]=static_cast<unsigned char>(d.end_frequency);s.param[o+4]=static_cast<unsigned char>(d.end_gain);}
 if(filter<17)reinterpret_cast<Setup>(image+setups[filter])(s.plugin,s.param,s.voice);
 else if(filter<50){put<uint16_t>(s.plugin,0x18,static_cast<uint16_t>(filter-17));reinterpret_cast<Setup>(image+0x2ed880)(s.plugin,s.param,s.voice);}
 else reinterpret_cast<Setup>(image+morphSetups[filter-50])(s.plugin,s.param,s.voice);
 const unsigned sections=get<unsigned>(s.voice,0x420);if(sections>6)throw std::runtime_error("Invalid original section count");put<float>(s.voice,0x2b0,morph);
 if(sections){reinterpret_cast<Unary>(image+0x2cf470)(s.voice);reinterpret_cast<Kernel>(image+0x2ced30)(s.voice,s.voice+0x3b0,s.voice+0x530);}return sections;
}
void compareSetup(direct::Result& r,unsigned block,const Scratch& s,const emux::PackedConfiguration& pack,const emux::Configuration& config){
 check(r,direct::Frames,block,0,get<unsigned>(s.voice,0x420),static_cast<unsigned>(pack.sections));
 for(unsigned f=0;f<4;++f)for(unsigned stage=0;stage<pack.sections;++stage)for(unsigned k=0;k<5;++k)check(r,direct::Frames,block,1+(f*6+stage)*5+k,get<uint16_t>(s.voice,0x2c0+f*60+stage*10+k*2),pack.frames[f][stage][k]);
 check(r,direct::Gain,block,0,bits(get<float>(s.voice,0x2a8)),bits(pack.gain_factor));
 for(unsigned stage=0;stage<pack.sections;++stage)for(unsigned k=0;k<5;++k)check(r,direct::Coefficients,block,stage*5+k,bits(get<float>(s.voice,0x530+stage*20+k*4)),bits(config.coefficients[stage][k]));
}
void runCase(const PortBanks& banks,direct::Result& r){
 auto scratch=std::make_unique<Scratch>();auto& s=*scratch;const auto p=parameters(r.profile,r.filter);emux::RampedStereoFilter port;
 Rng rng{65102026u+r.id*65537u};emux::RampedStereoFilter::ChannelStates initial{};
 for(unsigned c=0;c<r.channels;++c)for(unsigned stage=0;stage<6;++stage)for(unsigned k=0;k<2;++k)initial[c][stage][k]=rng.sample()*.01f;
 std::memcpy(s.states,initial.data(),sizeof s.states);for(unsigned c=0;c<2;++c)for(unsigned i=0;i<6;++i)s.statePointers[c][i]=s.states[c][i];
 emux::Coefficients last{};unsigned previousSections=0;bool started=false;
 constexpr unsigned counts[]={1,17,64,256,128,31,88,257};
 for(unsigned block=0;block<17;++block){
  const float morph=r.profile==1?float(16-block)/16.0f:r.profile==2?float(rng.next()&127)/127.0f:float(block)/16.0f;
  const float q=r.profile<3?float(r.profile)*.5f:float((block*7)%17)/16.0f;
  const unsigned count=counts[block%8];const unsigned csr=0x1f80;
  _mm_setcsr(csr);const unsigned sections=originalConfig(s,r.filter,r.rate,p,morph,q);r.sections=sections;
  _mm_setcsr(csr);const auto packed=portFrames(banks,r.filter,r.rate,p,q);const auto config=portConfig(banks,r.filter,r.rate,packed,morph,q);compareSetup(r,block,s,packed,config);
  if(!started||previousSections!=sections){port.initialize(config.coefficients,sections);if(!started)port.restore_states(initial);else std::memset(s.states,0,sizeof s.states);for(unsigned stage=0;stage<sections;++stage)for(unsigned k=0;k<5;++k)last[stage][k]=get<float>(s.voice,0x530+stage*20+k*4);started=true;}
  if(r.mode==0)port.ramp_to(config.coefficients,sections,count);else port.initialize(config.coefficients,sections);
  put<unsigned>(s.voice,0x28,count);put<float>(s.voice,0x2c,1.0f/float(count));put<uintptr_t>(s.voice,0x620,reinterpret_cast<uintptr_t>(s.statePointers[0]));put<uintptr_t>(s.voice,0x628,reinterpret_cast<uintptr_t>(s.statePointers[1]));
  for(unsigned stage=0;stage<sections;++stage){put<uintptr_t>(s.voice,0x428+stage*8,reinterpret_cast<uintptr_t>(s.coefficients[stage]));put<uintptr_t>(s.voice,0x488+stage*8,reinterpret_cast<uintptr_t>(s.delta[stage]));
   for(unsigned k=0;k<5;++k)put<float>(s.voice,0x4b8+stage*20+k*4,last[stage][k]);}
  if(r.mode==0){_mm_setcsr(csr);reinterpret_cast<Unary>(image+0x2cf8d0)(s.voice);reinterpret_cast<Unary>(image+0x2cf750)(s.voice);}
  else{for(unsigned stage=0;stage<sections;++stage)for(unsigned k=0;k<5;++k){s.coefficients[stage][k]=get<float>(s.voice,0x530+stage*20+k*4);s.delta[stage][k]=0;}}
  for(unsigned stage=0;stage<sections;++stage)for(unsigned k=0;k<5;++k){check(r,direct::Increments,block,stage*5+k,bits(s.delta[stage][k]),bits(r.mode==0?port.increments()[stage][k]:0.0f));}
  for(unsigned i=0;i<count*r.channels;++i)s.input[i]=block%4==0?(i==0?.001f:0.0f):block%4==1?(i%2?.0003f:-.0002f):rng.sample();
  put<uintptr_t>(s.inputDesc,0x20,reinterpret_cast<uintptr_t>(s.input));put<uintptr_t>(s.outputDesc,0x28,reinterpret_cast<uintptr_t>(s.output));
  unsigned slot=(r.mode?16:8)+(sections==1?0:sections==2?2:sections==3?4:6)+(r.channels==2?1:0);
  const uintptr_t table=image+(r.variant?0x6fded8:0x6f4bb8);auto kernel=reinterpret_cast<Kernel>(get<uintptr_t>(reinterpret_cast<void*>(table),slot*8));
  _mm_setcsr(csr);if(sections)kernel(s.voice,s.inputDesc,s.outputDesc);else std::memcpy(s.output,s.input,count*r.channels*4);
  _mm_setcsr(csr);for(unsigned i=0;i<count;++i){float l=s.input[i*r.channels],right=r.channels==2?s.input[i*2+1]:0;port.process(l,right,r.channels==2);if(shared->reserved==1&&r.id==0&&block==2&&i==7){unsigned changed=bits(l)^1;std::memcpy(&l,&changed,4);}r.nonfiniteAudio+=!std::isfinite(s.output[i*r.channels]);check(r,direct::Audio,block,i*r.channels,bits(s.output[i*r.channels]),bits(l));if(r.channels==2){r.nonfiniteAudio+=!std::isfinite(s.output[i*2+1]);check(r,direct::Audio,block,i*2+1,bits(s.output[i*2+1]),bits(right));}}
  const auto states=port.states();for(unsigned c=0;c<r.channels;++c)for(unsigned stage=0;stage<sections;++stage)for(unsigned k=0;k<2;++k)check(r,direct::State,block,(c*6+stage)*2+k,bits(s.states[c][stage][k]),bits(states[c][stage][k]));
  // Carry ORIGINAL endpoints, never port targets, into the next original block.
  for(unsigned stage=0;stage<sections;++stage)for(unsigned k=0;k<5;++k)last[stage][k]=get<float>(s.voice,0x530+stage*20+k*4);
  previousSections=sections;r.blocks=block+1;
 }
}
DWORD runGuarded(const PortBanks* banks,direct::Result* r){__try{runCase(*banks,*r);return 0;}__except(EXCEPTION_EXECUTE_HANDLER){return GetExceptionCode();}}
DWORD WINAPI worker(void*){const unsigned oldCsr=_mm_getcsr();try{PortBanks banks;unsigned id=0;InterlockedExchange(&shared->total,shared->limit?static_cast<LONG>(shared->limit):7040);InterlockedExchange(&shared->status,1);
 for(unsigned rate:{44100u,48000u,96000u,192000u})for(unsigned filter=0;filter<55;++filter)for(unsigned channels=1;channels<=2;++channels)for(unsigned variant=0;variant<2;++variant)for(unsigned mode=0;mode<2;++mode)for(unsigned profile=0;profile<4;++profile){
  if(InterlockedCompareExchange(&shared->cancel,0,0)||(shared->limit&&id>=shared->limit)){InterlockedExchange(&shared->status,3);_mm_setcsr(oldCsr);return 0;}
  auto& r=shared->results[id];r.id=id;r.filter=filter;r.rate=rate;r.channels=channels;r.variant=variant;r.mode=mode;r.profile=profile;
  r.fault=runGuarded(&banks,&r);++id;InterlockedExchange(&shared->completed,static_cast<LONG>(id));if(r.fault){InterlockedExchange(&shared->status,4);_mm_setcsr(oldCsr);return r.fault;}
 }
 InterlockedExchange(&shared->status,2);
 }catch(...){InterlockedExchange(&shared->status,4);}_mm_setcsr(oldCsr);return 0;}
}
extern "C" __declspec(dllexport) DWORD WINAPI DirectStart(void*){
 if(shared&&InterlockedCompareExchange(&shared->status,0,0)==1)return 0;
 if(shared){UnmapViewOfFile(shared);shared=nullptr;}if(mapping){CloseHandle(mapping);mapping=nullptr;}
 image=reinterpret_cast<uintptr_t>(GetModuleHandleW(nullptr));wchar_t n[96];direct::name(n,96,GetCurrentProcessId());mapping=OpenFileMappingW(FILE_MAP_ALL_ACCESS,FALSE,n);if(!mapping)return 0;
 shared=static_cast<direct::Shared*>(MapViewOfFile(mapping,FILE_MAP_ALL_ACCESS,0,0,sizeof(direct::Shared)));if(!shared||shared->magic!=direct::Magic||shared->version!=direct::Version||shared->limit>7040)return 0;
 HANDLE thread=CreateThread(nullptr,0,worker,nullptr,0,nullptr);if(!thread)return 0;CloseHandle(thread);return 1;
}
BOOL WINAPI DllMain(HINSTANCE module,DWORD reason,LPVOID){if(reason==DLL_PROCESS_ATTACH)DisableThreadLibraryCalls(module);return TRUE;}

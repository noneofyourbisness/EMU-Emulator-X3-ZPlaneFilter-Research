#pragma once
#define NOMINMAX
#include <windows.h>
#include <cstdint>
#include <algorithm>
#include <cstdio>
#include "TraceFormat.h"

namespace x3 {
constexpr uint32_t Magic=0x58335348, Version=4;
constexpr uint32_t MaxFrames=192000*24, MaxEvents=2048, QueueSize=64;
enum Command : LONG { Audition=1, Stop, Morph, Steps, Slow, Fast, SelectFilter, SetProbe };
enum State : LONG { Waiting=0, Ready=1, Recording=2, Complete=3, Cancelled=4, Fault=5 };
struct Message { LONG command,value; };
struct Event { uint64_t requested,applied; uint8_t bytes[3],length; };
struct Shared {
 uint32_t magic,version;
 volatile LONG state,attached,error,rate,buffer,quantum;
 volatile LONG writeIndex,readIndex,heartbeat,ticks,frames,eventCount,generation,selectedFilter;
 Message queue[QueueSize];
 Event events[MaxEvents];
 float audio[MaxFrames*2];
 volatile LONG traceEnabled,traceCount,traceFaults,traceSkipped,traceOverflow;
 TraceBlock trace[MaxTraceBlocks];
 float traceInput[MaxFrames*2],traceOutput[MaxFrames*2];
};
inline LONG read(volatile LONG& v) { return InterlockedCompareExchange(&v,0,0); }
inline void write(volatile LONG& v,LONG n) { InterlockedExchange(&v,n); }
inline bool post(Shared& s,Command c,LONG value=0) {
 LONG w=read(s.writeIndex), next=(w+1)%QueueSize;
 if(next==read(s.readIndex))return false;
 s.queue[w]={c,value}; write(s.writeIndex,next);return true;
}
inline void name(wchar_t* out,size_t n,DWORD pid) { swprintf_s(out,n,L"Local\\X3SawHarness-v4-%lu",pid); }
struct Schedule {
 Event events[MaxEvents]{};
 uint32_t count=0,next=0,rate=0;
 uint64_t position=0,total=0;
 void add(double seconds,uint8_t a,uint8_t b,uint8_t c,uint8_t len=3) {
  if(count<MaxEvents) events[count++]={uint64_t(seconds*rate+0.5),0,{a,b,c},len};
 }
 void build(Command kind,uint32_t sampleRate,uint8_t program=0,uint8_t note=60,uint8_t velocity=127) {
  count=next=0;position=0;rate=sampleRate;total=uint64_t(rate)*24;
  add(0,0x80,note,64);add(0,0xb0,0,0);add(0,0xb0,32,0);add(0,0xc0,program,0,2);add(0,0xb0,1,0);add(1,0x90,note,velocity);
  if(kind==Steps) {
   const int times[]={4,7,10,12,14,16,18,20}, values[]={127,0,64,65,32,96,127,0};
   for(int i=0;i<8;++i)add(times[i],0xb0,1,uint8_t(values[i]));
  } else if(kind==Slow) {
   for(int i=0;i<=127;++i)add(4.+16.*i/127.,0xb0,1,uint8_t(i));
  } else {
   for(int cycle=0;cycle<8;++cycle)
    for(int i=0;i<128;++i)add(4.+cycle*2.+2.*i/128.,0xb0,1,uint8_t(cycle%2?127-i:i));
  }
  add(22,0x80,note,64);
 }
};
}

#pragma once
#include "Protocol.h"
#include "FilterCatalog.h"
#include <vector>
#include <stdexcept>
namespace x3 {
struct BatchJob { int program; Command command; };
inline const wchar_t* captureName(Command command) {
 return command==Steps?L"steps":command==Slow?L"slow":L"fast";
}
inline std::vector<BatchJob> batchPlan(int mode) {
 if(mode<0||mode>3)throw std::runtime_error("Choose a batch test first.");
 std::vector<BatchJob> jobs;
 for(int program=0;program<int(filters.size());++program) {
  if(mode<3)jobs.push_back({program,Command(Steps+mode)});
  else { jobs.push_back({program,Steps});if(program) { jobs.push_back({program,Slow});jobs.push_back({program,Fast}); } }
 }
 return jobs;
}
// Completion only advances after a take has been saved. A generation number
// distinguishes an old Complete status from the next queued capture.
struct BatchRun {
 std::vector<BatchJob> jobs;
 size_t completed=0;
 LONG previousGeneration=0;
 bool active=false;
 uint64_t started=0,queuedAt=0;
 void start(int mode,uint64_t now) { jobs=batchPlan(mode);completed=0;started=now;active=true; }
 const BatchJob& current() const { return jobs.at(completed); }
 void queued(LONG generation,uint64_t now) { previousGeneration=generation;queuedAt=now; }
 bool ready(LONG state,LONG generation) const { return active&&state==Complete&&generation!=previousGeneration; }
 void saved() { if(!active)throw std::runtime_error("Batch is stopped.");if(++completed==jobs.size())active=false; }
 void stop() { active=false; }
 double remaining(uint64_t now,uint32_t frames,uint32_t rate) const {
  if(!active)return 0;
  double currentSeconds=rate?std::min(24.,double(frames)/rate):0.;
  double overhead=completed?std::max(0.,double(queuedAt-started)/1000./completed-24.):0.;
  return (jobs.size()-completed)*24.-currentSeconds+(jobs.size()-completed-1)*overhead;
 }
};
}

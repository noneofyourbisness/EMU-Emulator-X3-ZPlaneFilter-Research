#pragma once
#include <cstdint>
namespace x3 {
constexpr uint32_t MaxTraceBlocks=32768;
struct TraceBlock {
 uint64_t frame,voice,filter;
 uint32_t frames,channels,sections,kernel,variant,mxcsr;
 float morphTarget,morphCurrent,baseQ,realtimeQ,gain;
 uint32_t reserved;
 double morphAccumulator;
 float coefficients[6][5],delta[6][5],previous[6][5],target[6][5];
 float before[2][6][2],after[2][6][2];
 // Slot indices are retained until the original source-to-slot mapping is verified.
 float channelControllers[23][2],voiceControllers[25][2];
};
struct TraceHeader {
 char magic[8]; // X3TRACE1
 uint32_t version,recordBytes,rate,frames,blocks,faults,skipped,overflow;
};
static_assert(sizeof(TraceHeader)==40,"Trace header changed");
}

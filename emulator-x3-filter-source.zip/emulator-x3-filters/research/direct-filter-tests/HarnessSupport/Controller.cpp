#define UNICODE
#define _UNICODE
#include "Protocol.h"
#include "FilterCatalog.h"
#include "BatchPlan.h"
#include <tlhelp32.h>
#include <bcrypt.h>
#include <sddl.h>
#include <commctrl.h>
#include <dwmapi.h>
#include <uxtheme.h>
#include <filesystem>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <vector>
#include <string>
#include <stdexcept>
#include <cmath>
namespace fs=std::filesystem;
namespace {
const wchar_t* Exe=L"C:\\Program Files\\E-MU\\Emulator X3\\EmulatorX.exe";
const std::string Expected="6f342c6057a8a0fb69f021a0da46adbab7f5a332139a2ee3a9506c9fa84e6914";
fs::path root;
HANDLE process=nullptr,mapping=nullptr,mutex=nullptr;
x3::Shared* shared=nullptr;
DWORD pid=0;
HWND window=nullptr,status=nullptr,label=nullptr,slider=nullptr;
const COLORREF Background=RGB(20,22,28),Surface=RGB(32,36,45),Text=RGB(232,236,244),Muted=RGB(163,173,190),Accent=RGB(135,157,255),Border=RGB(62,70,85);
HBRUSH backgroundBrush=CreateSolidBrush(Background),surfaceBrush=CreateSolidBrush(Surface);
HFONT uiFont=nullptr,titleFont=nullptr;
bool selectOnReady=false;
LONG savedGeneration=0;
int captureProgram=0;
double savedPeak=0;
std::wstring captureLabel=L"No Filter",captureKind=L"steps";
x3::BatchRun batch;
fs::path batchFolder;
std::vector<fs::path> batchFiles;
std::wstring batchOutcome;
bool capturePending=false;
uint64_t captureQueuedAt=0;
LONG capturePreviousGeneration=0;
uint64_t savedInvalid=0;
HWND batchMode=nullptr,batchStatus=nullptr,takeProgress=nullptr,overallProgress=nullptr;
bool detailedTrace=false;
int captureNote=60,captureVelocity=127;
std::wstring duration(double seconds) {
 auto s=uint64_t(std::ceil(std::max(0.,seconds)));
 return std::to_wstring(s/60)+L"m "+std::to_wstring(s%60)+L"s";
}
std::wstring timestamp() {
 SYSTEMTIME now{};GetLocalTime(&now);wchar_t stamp[64];
 swprintf_s(stamp,L"%04u%02u%02u-%02u%02u%02u-%03u",now.wYear,now.wMonth,now.wDay,now.wHour,now.wMinute,now.wSecond,now.wMilliseconds);
 return stamp;
}
void fail(const char* text) { throw std::runtime_error(std::string(text)+" (Windows "+std::to_string(GetLastError())+")"); }
std::string hash(const fs::path& path) {
 std::ifstream f(path,std::ios::binary);if(!f)throw std::runtime_error("Cannot read EmulatorX.exe.");
 BCRYPT_ALG_HANDLE alg=nullptr;BCRYPT_HASH_HANDLE h=nullptr;
 if(BCryptOpenAlgorithmProvider(&alg,BCRYPT_SHA256_ALGORITHM,nullptr,0)<0)fail("SHA-256 unavailable");
 DWORD objectSize=0,used=0;
 BCryptGetProperty(alg,BCRYPT_OBJECT_LENGTH,reinterpret_cast<PUCHAR>(&objectSize),sizeof(objectSize),&used,0);
 std::vector<unsigned char> object(objectSize);
 if(BCryptCreateHash(alg,&h,object.data(),objectSize,nullptr,0,0)<0)fail("Cannot create SHA-256");
 char b[16384];while(f.read(b,sizeof(b))||f.gcount())BCryptHashData(h,reinterpret_cast<PUCHAR>(b),ULONG(f.gcount()),0);
 unsigned char digest[32];BCryptFinishHash(h,digest,sizeof(digest),0);BCryptDestroyHash(h);BCryptCloseAlgorithmProvider(alg,0);
 std::ostringstream result;for(auto v:digest)result<<std::hex<<std::setw(2)<<std::setfill('0')<<unsigned(v);return result.str();
}
uintptr_t module(DWORD target,const wchar_t* name) {
 HANDLE snap=CreateToolhelp32Snapshot(TH32CS_SNAPMODULE,target);if(snap==INVALID_HANDLE_VALUE)return 0;
 MODULEENTRY32W entry{};entry.dwSize=sizeof(entry);uintptr_t result=0;
 if(Module32FirstW(snap,&entry))do {
  if(!_wcsicmp(entry.szModule,name)) { result=reinterpret_cast<uintptr_t>(entry.modBaseAddr);break; }
 }while(Module32NextW(snap,&entry));CloseHandle(snap);return result;
}
DWORD findProcess() {
 HANDLE snap=CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS,0);PROCESSENTRY32W entry{};entry.dwSize=sizeof(entry);DWORD result=0;
 if(Process32FirstW(snap,&entry))do { if(!_wcsicmp(entry.szExeFile,L"EmulatorX.exe")) {
  if(result) { CloseHandle(snap);throw std::runtime_error("More than one X3 instance is running. Close the extra instance first."); }
  result=entry.th32ProcessID;
 }}while(Process32NextW(snap,&entry));CloseHandle(snap);return result;
}
void remoteThread(uintptr_t address,void* arg) {
 HANDLE thread=CreateRemoteThread(process,nullptr,0,reinterpret_cast<LPTHREAD_START_ROUTINE>(address),arg,0,nullptr);
 if(!thread)fail("Cannot start X3 bridge");
 DWORD wait=WaitForSingleObject(thread,10000),code=0;GetExitCodeThread(thread,&code);CloseHandle(thread);
 if(wait!=WAIT_OBJECT_0)throw std::runtime_error("X3 bridge startup timed out; restart X3 before retrying.");
 if(!code)throw std::runtime_error("X3 bridge startup failed.");
}
void attach() {
 if(shared)return;
 pid=findProcess();
 if(!pid) {
  fs::path bank=root/L"FilterSawBank.exb"/L"FilterSawBank.exb";
  std::wstring cmd=L"\""+std::wstring(Exe)+L"\" \""+bank.wstring()+L"\"";
  STARTUPINFOW startup{};startup.cb=sizeof(startup);PROCESS_INFORMATION info{};
  if(!CreateProcessW(Exe,cmd.data(),nullptr,nullptr,FALSE,0,nullptr,root.c_str(),&startup,&info))fail("Cannot open X3");
  pid=info.dwProcessId;CloseHandle(info.hThread);CloseHandle(info.hProcess);
  Sleep(1500);
 }
 process=OpenProcess(PROCESS_CREATE_THREAD|PROCESS_QUERY_INFORMATION|PROCESS_VM_OPERATION|PROCESS_VM_WRITE|PROCESS_VM_READ|SYNCHRONIZE,FALSE,pid);
 if(!process)fail("Cannot connect to X3; run both apps at the same permission level");
 wchar_t path[32768];DWORD size=32768;
 if(!QueryFullProcessImageNameW(process,0,path,&size))fail("Cannot identify X3");
 if(hash(path)!=Expected)throw std::runtime_error("This X3 version does not match the traced build. Bridge disabled.");
 wchar_t name[96];x3::name(name,96,pid);
 std::wstring mutexName=std::wstring(name)+L"-controller";
 mutex=CreateMutexW(nullptr,TRUE,mutexName.c_str());
 if(!mutex||GetLastError()==ERROR_ALREADY_EXISTS)throw std::runtime_error("A harness is already connected. Close it before opening another.");
 // Local mapping, current user's default Windows DACL. No global/network endpoint.
 mapping=CreateFileMappingW(INVALID_HANDLE_VALUE,nullptr,PAGE_READWRITE,0,sizeof(x3::Shared),name);
 if(!mapping)fail("Cannot allocate capture memory");bool existing=GetLastError()==ERROR_ALREADY_EXISTS;
 shared=static_cast<x3::Shared*>(MapViewOfFile(mapping,FILE_MAP_ALL_ACCESS,0,0,sizeof(x3::Shared)));
 if(!shared)fail("Cannot access capture memory");
 if(!existing) { shared->magic=x3::Magic;shared->version=x3::Version; }
 if(shared->magic!=x3::Magic||shared->version!=x3::Version)throw std::runtime_error("Unexpected bridge protocol.");
 savedGeneration=x3::read(shared->generation);
 InterlockedIncrement(&shared->heartbeat);
 uintptr_t dll=module(pid,L"X3Bridge.dll");
 if(dll&&!existing)throw std::runtime_error("A previous bridge is already loaded. Close and restart standalone X3 once before using this update.");
 if(dll&&existing) { selectOnReady=true;return; }
 if(!dll) {
  auto dllPath=(root/L"X3Bridge.dll").wstring();size_t bytes=(dllPath.size()+1)*sizeof(wchar_t);
  void* remote=VirtualAllocEx(process,nullptr,bytes,MEM_COMMIT|MEM_RESERVE,PAGE_READWRITE);
  if(!remote)fail("Cannot allocate bridge startup path");
  if(!WriteProcessMemory(process,remote,dllPath.c_str(),bytes,nullptr))fail("Cannot write bridge startup path");
  auto loader=GetProcAddress(GetModuleHandleW(L"kernel32.dll"),"LoadLibraryW");
  HMODULE owner=nullptr;GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS|GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,reinterpret_cast<LPCWSTR>(loader),&owner);
  wchar_t ownerPath[MAX_PATH];GetModuleFileNameW(owner,ownerPath,MAX_PATH);auto* leaf=wcsrchr(ownerPath,L'\\');
  uintptr_t remoteOwner=module(pid,leaf?leaf+1:ownerPath);
  if(!remoteOwner)throw std::runtime_error("Cannot locate Windows loader in X3.");
  // LoadLibrary thread exit code is a truncated HMODULE; module enumeration supplies the full address.
  remoteThread(remoteOwner+(reinterpret_cast<uintptr_t>(loader)-reinterpret_cast<uintptr_t>(owner)),remote);
  VirtualFreeEx(process,remote,0,MEM_RELEASE);dll=module(pid,L"X3Bridge.dll");
  if(!dll)throw std::runtime_error("X3 did not load the bridge.");
 }
 HMODULE local=LoadLibraryExW((root/L"X3Bridge.dll").c_str(),nullptr,DONT_RESOLVE_DLL_REFERENCES);
 if(!local)fail("Cannot read bridge export");
 auto start=GetProcAddress(local,"BridgeStart");if(!start)fail("Bridge export missing");
 uintptr_t offset=reinterpret_cast<uintptr_t>(start)-reinterpret_cast<uintptr_t>(local);FreeLibrary(local);
 remoteThread(dll+offset,nullptr);
 selectOnReady=true;
}
void u32(std::ofstream& f,uint32_t n) { f.write(reinterpret_cast<const char*>(&n),4); }
void u16(std::ofstream& f,uint16_t n) { f.write(reinterpret_cast<const char*>(&n),2); }
std::string utf8(std::wstring s) {
 int n=WideCharToMultiByte(CP_UTF8,0,s.data(),int(s.size()),nullptr,0,nullptr,nullptr);std::string out(n,' ');
 WideCharToMultiByte(CP_UTF8,0,s.data(),int(s.size()),out.data(),n,nullptr,nullptr);return out;
}
std::string jsonString(std::wstring s) {
 std::string out="\"";for(unsigned char c:utf8(s)) {
  if(c=='"'||c=='\\') { out+='\\';out+=char(c); }else if(c<32)out+=' ';else out+=char(c);
 }return out+'"';
}
void saveWave(const fs::path& path,const float* data,uint32_t frames,uint32_t rate) {
 if(fs::exists(path))throw std::runtime_error("A recording already exists; it was not overwritten.");
 std::ofstream f(path,std::ios::binary);if(!f)throw std::runtime_error("Cannot save filter trace audio.");
 uint32_t size=frames*8;f.write("RIFF",4);u32(f,size+48);f.write("WAVEfmt ",8);u32(f,16);u16(f,3);u16(f,2);u32(f,rate);u32(f,rate*8);u16(f,8);u16(f,32);
 f.write("fact",4);u32(f,4);u32(f,frames);f.write("data",4);u32(f,size);f.write(reinterpret_cast<const char*>(data),size);
 if(!f)throw std::runtime_error("Filter trace audio write failed.");
}
void saveTrace(const fs::path& path,uint32_t frames,uint32_t rate) {
 if(!x3::read(shared->traceEnabled))return;
 auto stem=path;stem.replace_extension();
 x3::TraceHeader header{{'X','3','T','R','A','C','E','1'},1,sizeof(x3::TraceBlock),rate,frames,
  uint32_t(x3::read(shared->traceCount)),uint32_t(x3::read(shared->traceFaults)),uint32_t(x3::read(shared->traceSkipped)),uint32_t(x3::read(shared->traceOverflow))};
 if(header.blocks>x3::MaxTraceBlocks)throw std::runtime_error("Filter trace count is invalid.");
 std::ofstream f(stem.wstring()+L".trace.bin",std::ios::binary);f.write(reinterpret_cast<const char*>(&header),sizeof(header));
 f.write(reinterpret_cast<const char*>(shared->trace),size_t(header.blocks)*sizeof(x3::TraceBlock));
 f.write(reinterpret_cast<const char*>(shared->traceInput),size_t(frames)*8);f.write(reinterpret_cast<const char*>(shared->traceOutput),size_t(frames)*8);
 if(!f)throw std::runtime_error("Filter trace write failed.");
 f.close();
 if(header.blocks) {
  saveWave(stem.wstring()+L".filter-input.wav",shared->traceInput,frames,rate);
  saveWave(stem.wstring()+L".filter-output.wav",shared->traceOutput,frames,rate);
 }
 std::ofstream csv(stem.wstring()+L".controls.csv");
 csv<<"frame,frames,voice,filter,kernel,variant,channels,sections,mxcsr,morph_target,morph_current,morph_accumulator,base_q,realtime_q,gain_raw_0x40\n";
 csv<<std::setprecision(17);
 for(uint32_t i=0;i<header.blocks;++i) { const auto& b=shared->trace[i];csv<<b.frame<<','<<b.frames<<','<<b.voice<<','<<b.filter<<','<<b.kernel<<','<<b.variant<<','<<b.channels<<','<<b.sections<<','<<b.mxcsr<<','<<b.morphTarget<<','<<b.morphCurrent<<','<<b.morphAccumulator<<','<<b.baseQ<<','<<b.realtimeQ<<','<<b.gain<<'\n'; }
 if(!csv)throw std::runtime_error("Filter trace controls write failed.");
 csv.close();
 if(header.blocks&&fs::exists(root/L"X3TraceCompare.exe")) {
  auto exe=root/L"X3TraceCompare.exe";
  auto command=L"\""+exe.wstring()+L"\" \""+stem.wstring()+L".trace.bin\" \""+stem.wstring()+L".kernel-comparison.json\"";
  STARTUPINFOW startup{};startup.cb=sizeof(startup);startup.dwFlags=STARTF_USESHOWWINDOW;startup.wShowWindow=SW_HIDE;PROCESS_INFORMATION info{};
  if(CreateProcessW(exe.c_str(),command.data(),nullptr,nullptr,FALSE,CREATE_NO_WINDOW,nullptr,root.c_str(),&startup,&info)) {
   // This helper compares a saved file; it does not connect to or alter X3.
   if(WaitForSingleObject(info.hProcess,2000)==WAIT_TIMEOUT)TerminateProcess(info.hProcess,3);
   CloseHandle(info.hThread);CloseHandle(info.hProcess);
  }
 }
}
fs::path save() {
 if(!shared||x3::read(shared->state)!=x3::Complete)throw std::runtime_error("Capture is not complete.");
 uint32_t frames=x3::read(shared->frames),rate=x3::read(shared->rate);
 if(frames!=rate*24||frames>x3::MaxFrames)throw std::runtime_error("Capture length is invalid.");
 std::wstring safe=captureLabel;for(auto& c:safe)if(c<32||wcschr(L"<>:\"/\\|?*",c))c=L'_';
 if(safe.empty())safe=L"Unlabelled";
 fs::path dir=batch.active?batchFolder:root/L"captures";fs::create_directories(dir);
 wchar_t prefix[20];swprintf_s(prefix,L"%03u-",unsigned(batch.completed+1));
 auto path=dir/((batch.active?std::wstring(prefix):timestamp()+L"-")+safe+L"-"+captureKind+L".wav");
 if(fs::exists(path))throw std::runtime_error("A capture filename already exists; recording was not overwritten.");
 std::ofstream f(path,std::ios::binary);if(!f)throw std::runtime_error("Cannot save capture.");
 uint32_t dataSize=frames*8;
 f.write("RIFF",4);u32(f,dataSize+48);f.write("WAVEfmt ",8);u32(f,16);u16(f,3);u16(f,2);u32(f,rate);u32(f,rate*8);u16(f,8);u16(f,32);
 f.write("fact",4);u32(f,4);u32(f,frames);f.write("data",4);u32(f,dataSize);f.write(reinterpret_cast<const char*>(shared->audio),dataSize);
 if(!f)throw std::runtime_error("Capture write failed.");f.close();
 saveTrace(path,frames,rate);
 double peak=0;uint64_t invalid=0;for(uint64_t i=0;i<uint64_t(frames)*2;++i) {
  float v=shared->audio[i];if(!std::isfinite(v))++invalid;else peak=std::max(peak,std::abs(double(v)));
 }
 auto meta=path;meta.replace_extension(L".json");std::ofstream j(meta);
 j<<"{\n  \"format\": \"x3-standalone-saw-capture-v1\",\n  \"exe_sha256\": \""<<Expected<<"\",\n  \"filter_label_user_supplied\": "<<jsonString(captureLabel)
  <<",\n  \"selected_preset_program\": "<<captureProgram<<",\n  \"filter_selection_method\": \"Program Change into supplied FilterSawBank\",\n  \"test\": "<<jsonString(captureKind)<<",\n  \"sample_rate\": "<<rate<<",\n  \"asio_buffer\": "<<x3::read(shared->buffer)
  <<",\n  \"probe_note\": "<<captureNote<<",\n  \"probe_velocity\": "<<captureVelocity
  <<",\n  \"internal_quantum\": "<<x3::read(shared->quantum)<<",\n  \"frames\": "<<frames<<",\n  \"peak\": "<<std::setprecision(17)<<peak
  <<",\n  \"nonfinite_samples\": "<<invalid<<",\n  \"silent\": "<<(peak==0?"true":"false")
  <<",\n  \"detailed_trace_enabled\": "<<(x3::read(shared->traceEnabled)?"true":"false")<<",\n  \"trace_blocks\": "<<x3::read(shared->traceCount)<<",\n  \"trace_faults\": "<<x3::read(shared->traceFaults)<<",\n  \"trace_skipped\": "<<x3::read(shared->traceSkipped)<<",\n  \"trace_overflow\": "<<x3::read(shared->traceOverflow)
  <<",\n  \"tap\": \"synth bus 0, interleaved float, before ASIO sample conversion\",\n  \"bank_loaded_automatically_verified\": false,\n  \"events\": [\n";
 LONG count=x3::read(shared->eventCount);
 for(LONG i=0;i<count;++i) { auto e=shared->events[i];
  j<<"    {\"requested_frame\": "<<e.requested<<", \"applied_frame\": "<<e.applied<<", \"midi\": [";
  for(int n=0;n<e.length;++n) { if(n)j<<", ";j<<int(e.bytes[n]); }j<<"]}"<<(i+1<count?",":"")<<"\n";
 }j<<"  ]\n}\n";if(!j)throw std::runtime_error("Metadata write failed.");savedGeneration=x3::read(shared->generation);savedPeak=peak;savedInvalid=invalid;return path;
}
void writeBatchManifest(const wchar_t* outcome) {
 std::ofstream f(batchFolder/L"session.json");
 if(!f)throw std::runtime_error("Cannot save batch session metadata.");
 f<<"{\n  \"format\": \"x3-filter-batch-v1\",\n  \"status\": "<<jsonString(outcome)
  <<",\n  \"planned_takes\": "<<batch.jobs.size()<<",\n  \"completed_takes\": "<<batchFiles.size()
  <<",\n  \"seconds_per_take\": 24,\n  \"base_q_source\": \"Loaded X3 bank; use detailed trace to read actual voice controls\",\n  \"files\": [";
 for(size_t i=0;i<batchFiles.size();++i)f<<(i?", ":"")<<jsonString(batchFiles[i].filename().wstring());
 f<<"]\n}\n";if(!f)throw std::runtime_error("Batch session metadata write failed.");
}
std::wstring describe() {
 if(!shared)return L"Load FilterSawBank in X3, then connect here.";
 if(WaitForSingleObject(process,0)==WAIT_OBJECT_0)return L"X3 has closed. Close and reopen this harness to reconnect.";
 LONG state=x3::read(shared->state);
 if(state==x3::Fault)return L"Bridge stopped (code "+std::to_wstring(x3::read(shared->error))+L"). Restart X3 before retrying.";
 if(!x3::read(shared->attached))return L"Waiting for X3's ASIO audio engine. Check X3 audio settings.";
 if(state==x3::Recording)return L"Recording "+std::to_wstring(x3::read(shared->frames)/x3::read(shared->rate))+L" / 24 seconds...";
 return L"Connected · "+std::to_wstring(x3::read(shared->rate))+L" Hz · Buffer "+std::to_wstring(x3::read(shared->buffer));
}
int selected() { return int(SendMessageW(label,CB_GETCURSEL,0,0)); }
void setManualEnabled(bool enabled) {
 for(int id:{101,102,104,105,106,108,109,201,202,205,210,211})EnableWindow(GetDlgItem(window,id),enabled);
}
void chooseFilter() {
 int choice=selected();
 if(choice<0||choice>=int(x3::filters.size()))throw std::runtime_error("Choose a filter first.");
 if(!shared||!x3::read(shared->attached)) { selectOnReady=true;return; }
 if(x3::read(shared->state)==x3::Recording)return;
 if(!x3::post(*shared,x3::SelectFilter,choice))throw std::runtime_error("The controller queue is full; retry after a moment.");
 selectOnReady=false;
}
void begin(x3::Command command) {
 if(!shared||!x3::read(shared->attached)||x3::read(shared->state)==x3::Fault)throw std::runtime_error("Connect to X3 and wait for its audio engine first.");
 if(capturePending||x3::read(shared->state)==x3::Recording)throw std::runtime_error("Stop the current capture first.");
 InterlockedIncrement(&shared->heartbeat);
 const int notes[]={36,60,84},velocities[]={32,64,127};
 int n=int(SendMessageW(GetDlgItem(window,210),CB_GETCURSEL,0,0)),v=int(SendMessageW(GetDlgItem(window,211),CB_GETCURSEL,0,0));
 captureNote=notes[n<0?1:n];captureVelocity=velocities[v<0?2:v];
 if(!x3::post(*shared,x3::SetProbe,captureNote|(captureVelocity<<8)))throw std::runtime_error("The controller queue is full.");
 chooseFilter();
 if(command>=x3::Steps&&command<=x3::Fast) {
  captureProgram=selected();captureLabel=x3::filters[captureProgram].name;
  captureKind=command==x3::Steps?L"steps":command==x3::Slow?L"slow":L"fast";savedGeneration=x3::read(shared->generation);
  x3::write(shared->traceEnabled,detailedTrace?1:0);
  if(detailedTrace) {
   auto frames=size_t(x3::read(shared->rate))*24;if(frames>x3::MaxFrames)throw std::runtime_error("Trace capture rate is invalid.");
   std::memset(shared->traceInput,0,frames*8);std::memset(shared->traceOutput,0,frames*8);
  }
 }
 if(!x3::post(*shared,command))throw std::runtime_error("The controller queue is full; retry after a moment.");
 if(command>=x3::Steps&&command<=x3::Fast) {
  capturePending=true;captureQueuedAt=GetTickCount64();capturePreviousGeneration=savedGeneration;
  if(batch.active)batch.queued(savedGeneration,captureQueuedAt);
  setManualEnabled(false);
 }
}
void queueBatchTake() {
 const auto job=batch.current();SendMessageW(label,CB_SETCURSEL,job.program,0);begin(job.command);
}
void startBatch() {
 if(batch.active||capturePending|| (shared&&x3::read(shared->state)==x3::Recording))throw std::runtime_error("Stop the current recording first.");
 if(!shared||!x3::read(shared->attached)||x3::read(shared->state)==x3::Fault)throw std::runtime_error("Connect to X3 and wait for its audio engine first.");
 batchFolder=root/L"captures"/(L"Batch-"+timestamp());
 fs::create_directories(root/L"captures");if(!fs::create_directory(batchFolder))throw std::runtime_error("Cannot create a new batch folder.");
 batchFiles.clear();batchOutcome.clear();batch.start(int(SendMessageW(batchMode,CB_GETCURSEL,0,0)),GetTickCount64());
 writeBatchManifest(L"recording");queueBatchTake();
}
void stopBatch(const wchar_t* reason) {
 if(shared)x3::post(*shared,x3::Stop);
 capturePending=false;
 if(batch.active) { batch.stop();batchOutcome=reason;writeBatchManifest(reason); }
}
void updateBatchProgress() {
 if(!batchMode)return;
 int mode=int(SendMessageW(batchMode,CB_GETCURSEL,0,0));
 if(batch.active) {
  const auto job=batch.current();bool newTake=shared&&x3::read(shared->generation)!=batch.previousGeneration;
  uint32_t frames=newTake?x3::read(shared->frames):0,rate=shared?x3::read(shared->rate):0;
  double fraction=rate?std::clamp(double(frames)/(rate*24.),0.,1.):0.;
  auto text=std::to_wstring(batch.completed+1)+L" / "+std::to_wstring(batch.jobs.size())+L" · "+x3::filters[job.program].name
   +L"\r\n"+x3::captureName(job.command)+L" · Take: "+duration(24.*(1.-fraction))+L" · All: ~"+duration(batch.remaining(GetTickCount64(),frames,rate));
  SetWindowTextW(batchStatus,text.c_str());
  SendMessageW(takeProgress,PBM_SETPOS,WPARAM(fraction*1000),0);
  SendMessageW(overallProgress,PBM_SETPOS,WPARAM(1000.*(batch.completed+fraction)/batch.jobs.size()),0);
 } else if(!batchOutcome.empty()) {
  auto text=batchOutcome+L" · "+std::to_wstring(batchFiles.size())+L" / "+std::to_wstring(batch.jobs.size())+L" files saved\r\n"+batchFolder.filename().wstring();
  SetWindowTextW(batchStatus,text.c_str());SendMessageW(overallProgress,PBM_SETPOS,WPARAM(1000.*batchFiles.size()/batch.jobs.size()),0);
 } else {
  auto jobs=x3::batchPlan(mode);auto text=std::to_wstring(jobs.size())+L" separate WAVs · About "+duration(jobs.size()*24.)+L"\r\nFinished files are kept if you press Stop.";
  SetWindowTextW(batchStatus,text.c_str());
 }
}
void fill(HDC dc,RECT rect,COLORREF color) { HBRUSH brush=CreateSolidBrush(color);FillRect(dc,&rect,brush);DeleteObject(brush); }
void drawButton(const DRAWITEMSTRUCT& item) {
 bool disabled=item.itemState&ODS_DISABLED,pressed=item.itemState&ODS_SELECTED;
 fill(item.hDC,item.rcItem,Background);
 HBRUSH brush=CreateSolidBrush(pressed?RGB(53,63,85):Surface);HPEN pen=CreatePen(PS_SOLID,1,item.itemState&ODS_FOCUS?Accent:Border);
 auto oldBrush=SelectObject(item.hDC,brush),oldPen=SelectObject(item.hDC,pen);
 RoundRect(item.hDC,item.rcItem.left,item.rcItem.top,item.rcItem.right,item.rcItem.bottom,10,10);
 SelectObject(item.hDC,oldBrush);SelectObject(item.hDC,oldPen);DeleteObject(brush);DeleteObject(pen);
 wchar_t caption[100];GetWindowTextW(item.hwndItem,caption,100);SetBkMode(item.hDC,TRANSPARENT);SetTextColor(item.hDC,disabled?Muted:Text);
 RECT text=item.rcItem;DrawTextW(item.hDC,caption,-1,&text,DT_CENTER|DT_VCENTER|DT_SINGLELINE);
}
void drawFilter(const DRAWITEMSTRUCT& item) {
 fill(item.hDC,item.rcItem,item.itemState&ODS_SELECTED?RGB(49,62,92):Surface);
 if(item.itemID==UINT(-1))return;
 SetTextColor(item.hDC,item.itemState&ODS_DISABLED?Muted:Text);SetBkMode(item.hDC,TRANSPARENT);
 wchar_t caption[512]{};SendMessageW(item.hwndItem,CB_GETLBTEXT,item.itemID,reinterpret_cast<LPARAM>(caption));
 RECT text=item.rcItem;text.left+=12;text.right-=6;DrawTextW(item.hDC,caption,-1,&text,DT_SINGLELINE|DT_VCENTER|DT_END_ELLIPSIS);
}
LRESULT CALLBACK comboPaint(HWND h,UINT msg,WPARAM w,LPARAM l,UINT_PTR,DWORD_PTR) {
 LRESULT result=DefSubclassProc(h,msg,w,l);
 if(msg==WM_PAINT) {
  HDC dc=GetDC(h);RECT rect;GetClientRect(h,&rect);RECT arrow=rect;arrow.left=rect.right-30;
  fill(dc,arrow,Surface);SetDCBrushColor(dc,IsWindowEnabled(h)?Text:Muted);SetDCPenColor(dc,IsWindowEnabled(h)?Text:Muted);
  auto b=SelectObject(dc,GetStockObject(DC_BRUSH)),p=SelectObject(dc,GetStockObject(DC_PEN));
  int cx=(arrow.left+arrow.right)/2,cy=(arrow.top+arrow.bottom)/2;POINT triangle[]={{cx-4,cy-2},{cx+4,cy-2},{cx,cy+3}};Polygon(dc,triangle,3);
  SelectObject(dc,b);SelectObject(dc,p);HBRUSH edge=CreateSolidBrush(Border);FrameRect(dc,&rect,edge);DeleteObject(edge);ReleaseDC(h,dc);
 }
 if(msg==WM_NCDESTROY)RemoveWindowSubclass(h,comboPaint,1);
 return result;
}
LRESULT CALLBACK proc(HWND h,UINT msg,WPARAM w,LPARAM l) {
 try {
  if(msg==WM_COMMAND) {
   int id=LOWORD(w);
   if((batch.active||capturePending)&&id!=103&&id!=107)return 0;
   if(id==101)attach();else if(id==102)begin(x3::Audition);else if(id==103)stopBatch(L"Cancelled");
   else if(id>=104&&id<=106)begin(x3::Command(id-100));
   else if(id==107) { fs::create_directories(root/L"captures");ShellExecuteW(h,L"open",(root/L"captures").c_str(),nullptr,nullptr,SW_SHOWNORMAL); }
   else if(id==201&&HIWORD(w)==CBN_SELCHANGE)chooseFilter();
   else if(id==108)startBatch();
   else if(id==109) { detailedTrace=!detailedTrace;SetWindowTextW(GetDlgItem(h,109),detailedTrace?L"Detailed trace: ON":L"Detailed trace: OFF"); }
   else if(id==205&&HIWORD(w)==CBN_SELCHANGE) { batchOutcome.clear();updateBatchProgress(); }
   SetWindowTextW(status,describe().c_str());return 0;
  }
  if(msg==WM_CTLCOLORSTATIC||msg==WM_CTLCOLORLISTBOX||msg==WM_CTLCOLOREDIT) {
   HDC dc=reinterpret_cast<HDC>(w);bool list=msg!=WM_CTLCOLORSTATIC;
   SetTextColor(dc,Text);SetBkColor(dc,list?Surface:Background);return reinterpret_cast<LRESULT>(list?surfaceBrush:backgroundBrush);
  }
  if(msg==WM_MEASUREITEM) { reinterpret_cast<MEASUREITEMSTRUCT*>(l)->itemHeight=30;return TRUE; }
  if(msg==WM_DRAWITEM) {
   auto& item=*reinterpret_cast<DRAWITEMSTRUCT*>(l);
   if(item.CtlType==ODT_BUTTON)drawButton(item);else if(item.CtlType==ODT_COMBOBOX)drawFilter(item);return TRUE;
  }
  if(msg==WM_NOTIFY) {
   auto* draw=reinterpret_cast<NMCUSTOMDRAW*>(l);
   if(draw->hdr.hwndFrom==slider&&draw->hdr.code==NM_CUSTOMDRAW) {
    if(draw->dwDrawStage==CDDS_PREPAINT)return CDRF_NOTIFYITEMDRAW;
    if(draw->dwDrawStage==CDDS_ITEMPREPAINT) {
     if(draw->dwItemSpec==TBCD_CHANNEL)fill(draw->hdc,draw->rc,Border);
     else if(draw->dwItemSpec==TBCD_THUMB)fill(draw->hdc,draw->rc,Accent);
     return CDRF_SKIPDEFAULT;
    }
   }
  }
  if(msg==WM_HSCROLL&&shared) {
   x3::post(*shared,x3::Morph,LONG(SendMessageW(slider,TBM_GETPOS,0,0)));return 0;
  }
  if(msg==WM_TIMER) {
   if(shared) {
    InterlockedIncrement(&shared->heartbeat);
    LONG state=x3::read(shared->state),generation=x3::read(shared->generation);
    if(capturePending&&generation!=capturePreviousGeneration)capturePending=false;
    if(batch.active&&(state==x3::Fault||state==x3::Cancelled||WaitForSingleObject(process,0)==WAIT_OBJECT_0))stopBatch(L"Stopped: X3 capture interrupted");
    if(capturePending&&GetTickCount64()-captureQueuedAt>5000) { stopBatch(L"Stopped: audio engine did not start");throw std::runtime_error("Capture did not start. Check X3 audio settings."); }
    if(batch.active&&GetTickCount64()-batch.queuedAt>35000) { stopBatch(L"Stopped: capture timed out");throw std::runtime_error("Capture timed out. Check X3 audio settings."); }
    bool recording=state==x3::Recording||capturePending||batch.active;
    EnableWindow(label,!recording);EnableWindow(slider,!recording);EnableWindow(GetDlgItem(h,102),!recording);
    EnableWindow(GetDlgItem(h,101),!recording);EnableWindow(batchMode,!recording);EnableWindow(GetDlgItem(h,108),!recording);EnableWindow(GetDlgItem(h,109),!recording);
    EnableWindow(GetDlgItem(h,210),!recording);EnableWindow(GetDlgItem(h,211),!recording);
    for(int id=104;id<=106;++id)EnableWindow(GetDlgItem(h,id),!recording);
    if(selectOnReady&&x3::read(shared->attached)&&!recording)chooseFilter();
    if(state==x3::Complete&&savedGeneration!=generation&&(!batch.active||batch.ready(state,generation))) {
     bool wasBatch=batch.active;
     auto path=save();SetWindowTextW(status,(savedPeak==0?L"Saved silence. Check FilterSawBank on channel 1.":(L"Saved: "+path.filename().wstring())).c_str());
     if(wasBatch) {
      batchFiles.push_back(path);batch.saved();writeBatchManifest(batch.active?L"recording":L"Complete");
      if(savedPeak==0||savedInvalid) {
       if(batch.active)stopBatch(L"Stopped: silent or invalid audio");else { batchOutcome=L"Stopped: silent or invalid audio";writeBatchManifest(batchOutcome.c_str()); }
      } else if(batch.active)queueBatchTake();else batchOutcome=L"Complete";
     }
    }
   }
   updateBatchProgress();
   if(!shared||x3::read(shared->state)!=x3::Complete)SetWindowTextW(status,describe().c_str());return 0;
  }
  if(msg==WM_CLOSE) { stopBatch(L"Cancelled");DestroyWindow(h);return 0; }
  if(msg==WM_DESTROY) { if(shared)x3::post(*shared,x3::Stop);PostQuitMessage(0);return 0; }
 } catch(const std::exception& e) {
  if(batch.active) { batch.stop();capturePending=false;if(shared)x3::post(*shared,x3::Stop);batchOutcome=L"Stopped: save or controller error";try { writeBatchManifest(batchOutcome.c_str()); }catch(...){} }
  auto s=e.what();std::wstring ws(s,s+strlen(s));SetWindowTextW(status,ws.c_str());
  if(msg!=WM_TIMER)MessageBoxW(h,ws.c_str(),L"X3 Saw Harness",MB_OK|MB_ICONINFORMATION);
 }
 return DefWindowProcW(h,msg,w,l);
}
void child(const wchar_t* cls,const wchar_t* text,DWORD style,int x,int y,int width,int height,int id) {
 if(!_wcsicmp(cls,L"BUTTON"))style=(style&~BS_TYPEMASK)|BS_OWNERDRAW|WS_TABSTOP;
 HWND c=CreateWindowW(cls,text,WS_CHILD|WS_VISIBLE|style,x,y,width,height,window,reinterpret_cast<HMENU>(intptr_t(id)),GetModuleHandleW(nullptr),nullptr);
 SendMessageW(c,WM_SETFONT,reinterpret_cast<WPARAM>(id==204?titleFont:uiFont),TRUE);
 if(id==201)label=c;if(id==202)slider=c;if(id==203)status=c;
}
void createUi() {
  INITCOMMONCONTROLSEX common{sizeof(common),ICC_BAR_CLASSES};InitCommonControlsEx(&common);
  uiFont=CreateFontW(-16,0,0,0,FW_NORMAL,FALSE,FALSE,FALSE,DEFAULT_CHARSET,0,0,CLEARTYPE_QUALITY,0,L"Segoe UI");
  titleFont=CreateFontW(-26,0,0,0,FW_SEMIBOLD,FALSE,FALSE,FALSE,DEFAULT_CHARSET,0,0,CLEARTYPE_QUALITY,0,L"Segoe UI");
  WNDCLASSW wc{};wc.lpfnWndProc=proc;wc.hInstance=GetModuleHandleW(nullptr);wc.lpszClassName=L"X3SawHarness";wc.hCursor=LoadCursorW(nullptr,IDC_ARROW);wc.hbrBackground=backgroundBrush;RegisterClassW(&wc);
  window=CreateWindowW(wc.lpszClassName,L"X3 Saw Harness",WS_OVERLAPPED|WS_CAPTION|WS_SYSMENU|WS_MINIMIZEBOX,CW_USEDEFAULT,CW_USEDEFAULT,720,710,nullptr,nullptr,wc.hInstance,nullptr);
  BOOL dark=TRUE;DwmSetWindowAttribute(window,20,&dark,sizeof(dark));
  child(L"STATIC",L"X3 Saw Harness",0,24,18,500,36,204);
  child(L"STATIC",L"Load FilterSawBank in X3 · Channel 1 · Q from bank · Mod Wheel +100%",0,24,61,650,24,0);
  child(L"BUTTON",L"Open / connect to X3",BS_PUSHBUTTON,24,98,205,36,101);
  child(L"BUTTON",L"Audition saw",BS_PUSHBUTTON,245,98,175,36,102);
  child(L"BUTTON",L"Stop",BS_PUSHBUTTON,436,98,115,36,103);
  child(L"STATIC",L"Filter",0,24,161,110,24,0);
  child(L"COMBOBOX",L"",CBS_DROPDOWNLIST|CBS_OWNERDRAWFIXED|CBS_HASSTRINGS|WS_VSCROLL|WS_TABSTOP,147,153,525,350,201);
  SetWindowTheme(label,L"",L"");SetWindowSubclass(label,comboPaint,1,0);
  for(const auto& entry:x3::filters)SendMessageW(label,CB_ADDSTRING,0,reinterpret_cast<LPARAM>(entry.name));
  SendMessageW(label,CB_SETCURSEL,0,0);SendMessageW(label,CB_SETITEMHEIGHT,WPARAM(-1),30);SendMessageW(label,CB_SETMINVISIBLE,10,0);
  child(L"STATIC",L"Morph",0,24,211,110,23,0);
  child(TRACKBAR_CLASSW,L"",WS_TABSTOP,147,199,525,40,202);SetWindowTheme(slider,L"",L"");SendMessageW(slider,TBM_SETRANGE,TRUE,MAKELPARAM(0,127));
  child(L"BUTTON",L"Capture steps",BS_PUSHBUTTON,24,259,205,40,104);
  child(L"BUTTON",L"Capture slow sweep",BS_PUSHBUTTON,245,259,205,40,105);
  child(L"BUTTON",L"Capture fast sweeps",BS_PUSHBUTTON,466,259,205,40,106);
  child(L"STATIC",L"24-second captures · Float WAV + event timings · Saved automatically",0,24,314,650,23,0);
  child(L"STATIC",L"Capture every filter",0,24,354,170,24,0);
  child(L"COMBOBOX",L"",CBS_DROPDOWNLIST|CBS_OWNERDRAWFIXED|CBS_HASSTRINGS|WS_TABSTOP,206,347,465,220,205);
  batchMode=GetDlgItem(window,205);SetWindowTheme(batchMode,L"",L"");SetWindowSubclass(batchMode,comboPaint,1,0);
  for(auto text:{L"Steps — 56 files",L"Slow sweep — 56 files",L"Fast sweeps — 56 files",L"All three — 166 files"})SendMessageW(batchMode,CB_ADDSTRING,0,reinterpret_cast<LPARAM>(text));
  SendMessageW(batchMode,CB_SETCURSEL,0,0);SendMessageW(batchMode,CB_SETITEMHEIGHT,WPARAM(-1),30);
  child(L"BUTTON",L"Capture all filters",BS_PUSHBUTTON,24,399,205,40,108);
  child(L"STATIC",L"",0,245,396,426,48,206);batchStatus=GetDlgItem(window,206);
  child(L"STATIC",L"Current take",0,24,459,110,24,0);
  child(PROGRESS_CLASSW,L"",PBS_SMOOTH,147,458,524,15,207);takeProgress=GetDlgItem(window,207);
  child(L"STATIC",L"Overall batch",0,24,489,110,24,0);
  child(PROGRESS_CLASSW,L"",PBS_SMOOTH,147,488,524,15,208);overallProgress=GetDlgItem(window,208);
  for(auto bar:{takeProgress,overallProgress}) { SetWindowTheme(bar,L"",L"");SendMessageW(bar,PBM_SETRANGE32,0,1000);SendMessageW(bar,PBM_SETBKCOLOR,0,Surface);SendMessageW(bar,PBM_SETBARCOLOR,0,Accent); }
  child(L"BUTTON",L"Detailed trace: OFF",BS_PUSHBUTTON,24,514,205,30,109);
  child(L"STATIC",L"Optional filter input/output + exact-state research logs",0,245,519,426,24,0);
  child(L"STATIC",L"Test pitch",0,24,561,100,24,0);
  child(L"COMBOBOX",L"",CBS_DROPDOWNLIST|CBS_OWNERDRAWFIXED|CBS_HASSTRINGS|WS_TABSTOP,147,552,200,150,210);
  child(L"STATIC",L"Velocity",0,371,561,75,24,0);
  child(L"COMBOBOX",L"",CBS_DROPDOWNLIST|CBS_OWNERDRAWFIXED|CBS_HASSTRINGS|WS_TABSTOP,461,552,210,150,211);
  for(auto text:{L"Low — MIDI note 36",L"Reference — note 60",L"High — MIDI note 84"})SendMessageW(GetDlgItem(window,210),CB_ADDSTRING,0,reinterpret_cast<LPARAM>(text));
  for(auto text:{L"Quiet — velocity 32",L"Medium — velocity 64",L"Reference — 127"})SendMessageW(GetDlgItem(window,211),CB_ADDSTRING,0,reinterpret_cast<LPARAM>(text));
  SendMessageW(GetDlgItem(window,210),CB_SETCURSEL,1,0);SendMessageW(GetDlgItem(window,211),CB_SETCURSEL,2,0);
  for(int id:{210,211}) { auto combo=GetDlgItem(window,id);SetWindowTheme(combo,L"",L"");SetWindowSubclass(combo,comboPaint,1,0);SendMessageW(combo,CB_SETITEMHEIGHT,WPARAM(-1),30); }
  child(L"BUTTON",L"Open recordings",BS_PUSHBUTTON,24,610,175,34,107);
  child(L"STATIC",L"Load FilterSawBank, then connect to X3.",0,219,604,452,62,203);
  updateBatchProgress();
  SetTimer(window,1,200,nullptr);
}
}
int wmain(int argc,wchar_t** argv) {
 wchar_t own[32768];GetModuleFileNameW(nullptr,own,32768);root=fs::path(own).parent_path();
 try {
  if(argc>1) {
   attach();captureLabel=argc>3?argv[3]:L"No Filter";
   auto kind=argc>2?std::wstring(argv[2]):L"steps";captureKind=kind;
   DWORD start=GetTickCount();
   while(!x3::read(shared->attached)&&x3::read(shared->state)!=x3::Fault&&GetTickCount()-start<32000) { InterlockedIncrement(&shared->heartbeat);Sleep(100); }
   wprintf(L"%s\n",describe().c_str());
   if(std::wstring(argv[1])==L"--status")return x3::read(shared->attached)?0:1;
   if(std::wstring(argv[1])!=L"--capture")throw std::runtime_error("Use --status or --capture steps|slow|fast [filter label].");
   if(!x3::read(shared->attached)||x3::read(shared->state)==x3::Fault)throw std::runtime_error("Audio bridge not ready.");
   int program=-1;for(size_t i=0;i<x3::filters.size();++i)if(captureLabel==x3::filters[i].name)program=int(i);
   if(program<0)throw std::runtime_error("Unknown filter name; use its exact X3 name.");
   captureProgram=program;
   x3::post(*shared,x3::SelectFilter,program);
   auto command=kind==L"steps"?x3::Steps:kind==L"slow"?x3::Slow:kind==L"fast"?x3::Fast:x3::Command(0);
   if(!command)throw std::runtime_error("Unknown capture test.");
   if(x3::read(shared->state)==x3::Recording)throw std::runtime_error("A capture is already running.");
   x3::post(*shared,command);start=GetTickCount();bool begun=false;
   while(GetTickCount()-start<35000) {
    InterlockedIncrement(&shared->heartbeat);LONG s=x3::read(shared->state);
    if(s==x3::Recording)begun=true;
    if(begun&&s==x3::Complete) { wprintf(L"Saved: %s\n",save().c_str());if(savedPeak==0) { fprintf(stderr,"Capture is silent. Load FilterSawBank and assign MIDI channel 1.\n");return 2; }return 0; }
    if(s==x3::Fault||s==x3::Cancelled)throw std::runtime_error("Capture stopped before completion.");
    Sleep(100);
   }
   x3::post(*shared,x3::Stop);throw std::runtime_error("Capture timed out. Check X3's active ASIO device.");
  }
  createUi();ShowWindow(window,SW_SHOW);MSG msg{};
  while(GetMessageW(&msg,nullptr,0,0)>0) { if(!IsDialogMessageW(window,&msg)) { TranslateMessage(&msg);DispatchMessageW(&msg); } }
  return 0;
 }catch(const std::exception& e) {
  fprintf(stderr,"%s\n",e.what());
  if(argc==1) { auto s=e.what();std::wstring text(s,s+strlen(s));MessageBoxW(nullptr,text.c_str(),L"X3 Saw Harness",MB_OK|MB_ICONINFORMATION); }
  return 1;
 }
}

# Native filter test research

See REPORT.md and accuracy.json for the original native-X3 comparison and its limits.
The results folder includes the full passing case CSV and the deliberate one-bit negative control.
Source is copied here for review. To run or rebuild the self-contained tester, use the separate
X3-Direct-Filter-Tester.zip package, which includes Build.ps1, diagnostic binaries and Data/.
These research copies do not duplicate that package's runtime files.

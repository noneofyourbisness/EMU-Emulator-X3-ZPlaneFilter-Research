# Native X3 filter comparison — 5 October 2026

The automatic tester directly calls the installed, running X3's original machine-code routines and the port's reusable C++ DSP, on this computer. **All 55 filter types passed: 7,040 sequences, 119,680 blocks and 17,793,600 output float samples, with zero bit differences.** No WAV rendering or fitting is involved.

| Compared stage | Checked values | Bit differences |
|---|---:|---:|
| frames | 10,771,200 | 0 |
| gain | 119,680 | 0 |
| coefficients | 2,662,880 | 0 |
| increments | 2,662,880 | 0 |
| audio | 17,793,600 | 0 |
| state | 1,597,728 | 0 |

Total: **35,607,968 checked values**. There were zero original-code faults and zero nonfinite output samples. The checker also ran a negative control: toggling one bit of its own comparison copy produced exactly one reported audio difference, at block 2/sample 7. This deliberately failing self-test leaves the original DSP and both carried states unchanged.

## Independence and coverage

X3 generates its own packed frames and gain, interpolates/decodes its own target coefficients, computes its own ramps, and processes its own scratch state. The port independently obtains its frames from the previously extracted table files and computes its coefficients with the same headers used in the JUCE project. Neither implementation is fed the other's coefficients, output samples or final state. Nonzero initial states are seeded identically once per sequence, then carried independently. Original coefficient endpoints are read from original outputs for the following original block.

The suite covers the cross product of 55 filters, four stored sample-rate table selections (44.1/48/96/192 kHz), mono and distinct stereo inputs, two original class kernel variants, static and ramped coefficient kernels, and four parameter profiles. Each sequence has 17 blocks, cycling lengths 1, 17, 64, 256, 128, 31, 88 and 257. Profiles cover Q0/Q50/Q100, a mixed-Q grid, endpoint/intermediate Morph positions, default and active programmable frames, and Designer EQ/lowpass/highpass shapes. Inputs include impulses, alternating/DC values and deterministic distinct-channel noise at low finite levels. Inactive Designer sections cover the zero-section bypass case. This is finite test coverage, not exhaustive coverage of all parameter bit patterns or signal levels.

Original setup routines are called with independent scratch plugin/parameter/voice structures. The worker selects sample-rate tables in those structures: X3's live ASIO configuration is not changed. Both branches use the same CPU with MXCSR 0x1f80 and strict floating-point compilation. The worker restores its previous floating-point mode. Original SIMD scratch rows are 16-byte aligned, with 32-byte row strides. The DLL has no audio-voice hooks or instruction patches; it starts a dedicated diagnostic worker, and remains loaded but idle afterwards.

## What this establishes

The covered **filter-core paths are bit-exact under these tests**, including distinct stereo and active programmable frames. Small errors in earlier bus-input WAV comparisons cannot be expressed as a universal accuracy percentage, and this test alone does not identify their cause. Those comparisons include different signal-chain gain placement and live scheduling, which remain separate questions.

This suite does not run MIDI/mod-wheel routing, MorphLag, sampler resampling/loops, envelope/release, post-filter adaptive gain, pan, master mixing, or the complete VST3 host path. The original held-note VST3 proofs and live release/control studies remain separate evidence. Full sampler equivalence is not claimed. Further full-filter WAV batches are unnecessary for the tested arithmetic; live internal traces can still verify integration and scheduling.

## Deliverables and reproduction

Extract `X3-Direct-Filter-Tester.zip` into a writable folder. Open the fingerprinted X3 standalone, double-click `X3DirectTest.exe`, and choose **Check all filters**. No bank loading, MIDI driver or recording is required. The dark window reports completion and opens the latest JSON report. The adjacent `results` folder contains per-case CSV, aggregate JSON and a raw protocol snapshot. A fresh full run must contain exactly 7,040 completed cases and zero differences/faults/nonfinite values. `--self-test` intentionally returns failure with exactly one difference; it is a checker test, not a filter regression.

This attached tester requires this exact original EXE SHA-256: `6f342c6057a8a0fb69f021a0da46adbab7f5a332139a2ee3a9506c9fa84e6914`. It does not include the original executable. Extracted table payloads are supplied separately from newly written code; their original provenance and rights are unchanged. No modern Rossum Morpheus documentation or data was used. The installed EXE and original SawBank hashes still match their recorded values.

The published VST3 remains **0.5.0**, SHA-256 `0d9c8b36825b499144b0acbbdd558b2b4a752a613645e357fc82c65b60d25a97`. Its DSP processing has not been changed by this validation. The library and JUCE source add read-only coefficient/ramp/state inspection and a diagnostic state restore helper, used by the tester. Existing processor and voice-control checks passed (2/2). These additions do not change normal processing.

Authoritative full run: `20261005-192417-619-all.json`. Negative control: `20261005-192116-625-smoke.json`. Both runs and the deterministic source are included. CSV filter IDs use 0–16 standard, 17–49 factory, and 50–54 programmable; they are not the UI list ordinals. The raw binary is a v2 `direct::Shared` snapshot defined in `DirectFormat.h`; it stores tables, case counters and first differences, not every sample. Full test inputs are recreated deterministically by `DirectProbe.cpp`.

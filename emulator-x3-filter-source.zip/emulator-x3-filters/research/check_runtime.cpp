#include <iostream>
#include <vector>
#include <stdexcept>
void require(bool ok,const std::string& message){if(!ok)throw std::runtime_error(message);}

#include "../emux_runtime.hpp"
#include <fstream>

inline void checkRuntimeVectors(const char* path) {
    std::ifstream file(path,std::ios::binary);
    require(static_cast<bool>(file),"Runtime reference vectors missing");
    const auto read=[&](auto& v){require(static_cast<bool>(file.read(reinterpret_cast<char*>(&v),sizeof(v))),"Truncated runtime vectors");};
    const auto same=[](auto a,auto b){return std::memcmp(&a,&b,sizeof(a))==0;};
    unsigned cases=0,ticks=0,ramps=0,pairs=0;
    read(cases);
    for(unsigned i=0;i<cases;++i) {
        unsigned rate,quantum,count;float initial,divisor;
        read(rate);read(quantum);read(initial);read(divisor);read(count);
        emux::MorphLag lag;lag.prepare(rate,quantum,initial);
        require(same(lag.divisor(),divisor),"Lag table selection differs from X3");
        for(unsigned n=0;n<count;++n) {
            float target,expected;double accumulator;read(target);read(expected);read(accumulator);
            require(same(lag.tick(target),expected)&&same(lag.accumulator(),accumulator),"Lag differs from X3");++ticks;
        }
    }
    read(cases);
    for(unsigned i=0;i<cases;++i) {
        unsigned sections,stereo,count;read(sections);read(stereo);read(count);
        emux::Coefficients a{},b{};
        for(auto* c:{&a,&b})for(unsigned s=0;s<sections;++s)for(auto& v:(*c)[s])read(v);
        std::vector<float> input(count*(stereo?2:1)),expected(input.size());
        for(auto& v:input)read(v);for(auto& v:expected)read(v);
        emux::RampedStereoFilter f;f.initialize(a,sections);f.ramp_to(b,sections,count);
        for(unsigned n=0;n<count;++n) {
            float l=input[n*(stereo?2:1)],r=stereo?input[n*2+1]:0;
            f.process(l,r,stereo!=0);
            require(same(l,expected[n*(stereo?2:1)])&&(!stereo||same(r,expected[n*2+1])),"Coefficient ramp differs from X3");
        }
        ++ramps;
    }
    read(cases);
    for(unsigned i=0;i<cases;++i) {
        unsigned rate,stereo,count;read(rate);read(stereo);read(count);
        std::array<float,16> multipliers;for(auto& v:multipliers)read(v);
        emux::AdaptiveGain gain;gain.prepare(rate);
        for(unsigned n=0;n<count;++n) {
            float l,r,el,er,eg;read(l);read(r);read(el);read(er);read(eg);
            gain.process(l,r,stereo!=0);
            require(same(l,el)&&same(r,er)&&same(gain.gain(),eg),"Adaptive gain differs from X3");++pairs;
        }
    }
    require(file.peek()==std::char_traits<char>::eof(),"Extra runtime vector bytes");
    std::cout<<"PASS: original X3 instruction references: "<<ticks<<" lag ticks, "<<ramps<<" mono/stereo coefficient ramps, "<<pairs<<" adaptive gain sample pairs.\n";
}

int main(int argc,char** argv){try{checkRuntimeVectors(argc>1?argv[1]:"research/runtime-vectors.bin");return 0;}catch(const std::exception& e){std::cerr<<e.what()<<"\n";return 1;}}

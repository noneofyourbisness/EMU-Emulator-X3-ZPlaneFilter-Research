from emulation import *
from trace_filters import md

dest=ROOT/'research'
dest.mkdir(exist_ok=True)
rng=random.Random(20261005)
lag=[]; ramps=[]; gains=[]
for rate in (44100,48000,96000,192000):
    for quantum in (16,64,128,256):
        scale=f32(.01/(quantum/rate))
        entry=f32(f32(math.pow(2,.05*10))*scale)
        divisor=f32(f32(f32(entry-1)*f32(20*f32(.01)))+1)
        reciprocal=float(f32(1/divisor))
        write(0x1408b2db0,'d',reciprocal)
        value=f32(rng.random()); acc=float(f32(divisor*value))
        write(VOICE+0x2b8,'d',acc);write(VOICE+0x9c,'B',0)
        values=[]
        for i in range(128):
            target=f32(0 if i<32 else 1 if i<64 else rng.random())
            write(VOICE+0x98,'f',target)
            call(0x1402cbb60,VOICE)
            values.append((target,read(VOICE+0x2b0,'f')[0],read(VOICE+0x2b8,'d')[0]))
        lag.append((rate,quantum,value,divisor,values))
    call(0x1402cb140,VOICE+0x40,rate)
    multipliers=read(VOICE+0x44,'16f')
    for stereo in (False,True):
        values=[];write(VOICE+0x40,'f',1)
        for i in range(1024):
            amplitude=8 if i<256 else .25 if i<768 else 64
            left=f32(rng.uniform(-amplitude,amplitude));right=f32(rng.uniform(-amplitude,amplitude))
            write(OUTPUT,'2f',left,right)
            uc.reg_write(UC_X86_REG_RBX,VOICE);uc.reg_write(UC_X86_REG_RCX,OUTPUT);uc.reg_write(UC_X86_REG_EDX,1)
            uc.emu_start(0x1402cbdd8 if stereo else 0x1402cbe5f,0x1402cbeb3,count=1000)
            assert uc.reg_read(UC_X86_REG_RIP)==0x1402cbeb3
            result=read(OUTPUT,'2f')
            values.append((left,right,*result,read(VOICE+0x40,'f')[0]))
        gains.append((rate,int(stereo),multipliers,values))
    for sections,mono,stereo_kernel in [(1,0x1402cbed0,0x1402cc020),(2,0x1402cc200,0x1402cc3d0),(3,0x1402cc690,0x1402cc8d0),(6,0x1402ccc80,0x1402cd010)]:
        for stereo in (False,True):
            for count in (1,17,64,128):
                ca=bank.coefficients(10,f32(.15),f32(.5),rate)[:sections]
                cb=bank.coefficients(10,f32(.2),f32(.55),rate)[:sections]
                for i,(a,b) in enumerate(zip(ca,cb)):
                    write(VOICE+0x4b8+i*20,'5f',*a);write(VOICE+0x530+i*20,'5f',*b)
                    write(VOICE+0x428+i*8,'Q',COEFS+i*20);write(VOICE+0x488+i*8,'Q',DELTAS+i*20)
                    write(STATES_PTR+i*8,'Q',STATES+i*8)
                    write(STATES_PTR+0x80+i*8,'Q',STATES+0x80+i*8)
                write(VOICE+0x420,'I',sections);write(VOICE+0x28,'I',count)
                write(VOICE+0x2c,'f',f32(1/count))
                write(VOICE+0x620,'Q',STATES_PTR);write(VOICE+0x628,'Q',STATES_PTR+0x80)
                uc.mem_write(STATES,b'\0'*0x100)
                call(0x1402cf8d0,VOICE);call(0x1402cf750,VOICE)
                inputs=[f32(rng.uniform(-.01,.01)) for _ in range(count*(2 if stereo else 1))]
                write(INPUT,str(len(inputs))+'f',*inputs)
                write(INPUT_DESC+0x20,'Q',INPUT);write(OUTPUT_DESC+0x28,'Q',OUTPUT)
                call(stereo_kernel if stereo else mono,VOICE,INPUT_DESC,OUTPUT_DESC)
                result=list(read(OUTPUT,str(len(inputs))+'f'))
                ramps.append((sections,int(stereo),count,ca,cb,inputs,result))

with open(dest/'runtime-vectors.bin','wb') as f:
    def emit(fmt,*v):f.write(struct.pack('<'+fmt,*v))
    emit('I',len(lag))
    for rate,quantum,value,divisor,values in lag:
        emit('IIffI',rate,quantum,value,divisor,len(values))
        for v in values:emit('ffd',*v)
    emit('I',len(ramps))
    for sections,stereo,count,ca,cb,inputs,result in ramps:
        emit('III',sections,stereo,count)
        for c in (ca,cb):
            for s in c:emit('5f',*s)
        emit(str(len(inputs))+'f',*inputs);emit(str(len(result))+'f',*result)
    emit('I',len(gains))
    for rate,stereo,multipliers,values in gains:
        emit('III',rate,stereo,len(values));emit('16f',*multipliers)
        for v in values:emit('5f',*v)
report=dict(source_sha256=hashlib.sha256(pe.data).hexdigest(),
    lag_ticks=sum(len(x[-1]) for x in lag),ramp_cases=len(ramps),
    ramp_audio_values=sum(len(x[-1]) for x in ramps),gain_sample_pairs=sum(len(x[-1]) for x in gains),
    reference='Original x64 instructions emulated with Unicorn; C++ comparisons must pass separately',
    boundaries='Cadence uses a selected quantum; exact user MIDI arrival times and X3 voice scheduler are not recovered')
(ROOT/'research'/'runtime-validation-pending.json').write_text(json.dumps(report,indent=2))
print(report)

# Reproduce the live Ooh to Eee comparison

This is a verifier for the specific `20261005-150344-678-Ooh to Eee-steps` trace, not a general trace renderer. It checks the fixture layout and original event schedule before comparing.

In an x64 Visual Studio developer command prompt, from this directory:

```bat
cl /nologo /std:c++17 /EHsc /MT /O2 /fp:strict /utf-8 CompareOohTrace.cpp /Fe:CompareOohTrace.exe
CompareOohTrace.exe "C:\path\to\20261005-150344-678-Ooh to Eee-steps.trace.bin" events.txt factory-bank.bin comparison.csv comparison.json
```

Supply the original trace file extracted from your ZIP. All five arguments should be supplied; the source's fallback paths refer to the development workspace. Exit 0 means every comparison passed, exit 2 means a bit mismatch, exit 1 means invalid input or another error.

The checker processes the generated control/coefficients for the uncaptured first quantum, then seeds only the filter state from the first covered block. It replays captured mono input continuously, carrying state without block resets. Each subsequent output and final state is compared as IEEE bit patterns. Every current/target/previous/increment coefficient and controller/Morph/accumulator value is compared independently.

This validates the filter stages conditional on the captured internal input and first covered filter state. It does not reproduce the sampler, first note quantum, voice amplifier, or bus output. No fitted gain is applied.

#include "TraceFormat.h"
#include "emux_sweep_timing.hpp"
#include <fstream>
#include <vector>
#include <iostream>
#include <cstring>
#include <limits>
#include <stdexcept>
#include <xmmintrin.h>
bool same(float a,float b) { return std::memcmp(&a,&b,4)==0; }
bool same(double a,double b) { return std::memcmp(&a,&b,8)==0; }
int main(int argc,char** argv) { try {
 std::ifstream f(argc>1?argv[1]:"work/ooh-live-trace/20261005-150344-678-Ooh to Eee-steps.trace.bin",std::ios::binary);x3::TraceHeader h{};f.read(reinterpret_cast<char*>(&h),sizeof(h));
 if(!f||std::memcmp(h.magic,"X3TRACE1",8)||h.version!=1||h.recordBytes!=sizeof(x3::TraceBlock)||h.blocks!=3617||h.rate!=44100||h.frames!=1058400||h.faults||h.skipped||h.overflow)throw std::runtime_error("This verifier requires the complete, clean 20261005-150344-678 Ooh to Eee fixture");
 std::vector<x3::TraceBlock> blocks(h.blocks);f.read(reinterpret_cast<char*>(blocks.data()),blocks.size()*sizeof(x3::TraceBlock));
 if(!f)throw std::runtime_error("Truncated trace blocks");
 for(size_t i=0;i<blocks.size();++i) {
  const auto& b=blocks[i];
  if(b.frame!=44544+i*256||b.frames!=256||b.channels!=1||b.sections!=6||b.kernel!=14||b.variant!=1||b.mxcsr!=8096||!same(b.baseQ,.5f)||!same(b.realtimeQ,0.f)||b.voice!=blocks[0].voice||b.filter!=blocks[0].filter)throw std::runtime_error("Unexpected fixture layout or settings");
 }
 std::vector<float> rawInput(size_t(h.frames)*2),rawOutput(rawInput.size());f.read(reinterpret_cast<char*>(rawInput.data()),rawInput.size()*4);f.read(reinterpret_cast<char*>(rawOutput.data()),rawOutput.size()*4);
 if(!f)throw std::runtime_error("Truncated trace audio");
 std::ifstream events(argc>2?argv[2]:"work/ooh-live-trace/events.txt");std::vector<std::pair<unsigned,unsigned>> changes;unsigned frame,value;while(events>>frame>>value)changes.emplace_back(frame,value);
 const std::vector<std::pair<unsigned,unsigned>> expected={{0,0},{176640,127},{308736,0},{441088,64},{529408,65},{617472,32},{705792,96},{793856,127},{882176,0}};
 if(changes!=expected)throw std::runtime_error("Reference needs the original nine recorded CC events");
 auto bank=emux::FactoryBank::from_table_file(argc>3?argv[3]:"outputs/emulator-x3-investigation/factory-bank.bin");
 emux::SweepTiming sweep;sweep.prepare(44100,256,0);auto last=bank.coefficients(10,0,.5f,44100);size_t e=0,bi=0;
 emux::Coefficients initial{};std::memcpy(initial.data(),blocks[0].coefficients,sizeof(blocks[0].coefficients));emux::Filter continuous(initial,6);emux::Filter::State initialState{};std::memcpy(initialState.data(),blocks[0].before[0],sizeof(blocks[0].before[0]));continuous.restore_state(initialState);
 uint64_t continuousSamples=0,continuousDifferences=0,continuousStateDifferences=0;
 uint64_t morphTargetDiff=0,morphValueDiff=0,accumDiff=0,coeffDiff=0,targetDiff=0,previousDiff=0,deltaDiff=0;unsigned first=UINT_MAX;
 std::ofstream csv(argc>4?argv[4]:"outputs/zplane-ooh-live-trace/coefficient-stage-comparison.csv");if(!csv)throw std::runtime_error("Cannot write coefficient report");csv<<"frame,morph_driver_differences,morph_value_differences,accumulator_differences,current_coefficient_differences,target_differences,previous_differences,delta_differences\n";
 for(unsigned at=44288;bi<blocks.size();at+=256) {
  while(e<changes.size()&&changes[e].first<=at){sweep.set_midi_cc7(changes[e].second);++e;}
  _mm_setcsr(blocks[0].mxcsr);float position=sweep.tick();auto next=bank.coefficients(10,position,.5f,44100);
  if(at==blocks[bi].frame) {
   const auto& b=blocks[bi++];unsigned mt=!same(sweep.controller_value(),b.morphTarget),mv=!same(position,b.morphCurrent),ac=!same(sweep.accumulator(),b.morphAccumulator),co=0,ta=0,pr=0,de=0;
   for(unsigned s=0;s<6;++s)for(unsigned k=0;k<5;++k) {
    co+=!same(last[s][k],b.coefficients[s][k]);ta+=!same(next[s][k],b.target[s][k]);pr+=!same(last[s][k],b.previous[s][k]);
    float delta=(next[s][k]-last[s][k])*(1.f/256.f);de+=!same(delta,b.delta[s][k]);
   }
   morphTargetDiff+=mt;morphValueDiff+=mv;accumDiff+=ac;coeffDiff+=co;targetDiff+=ta;previousDiff+=pr;deltaDiff+=de;
   auto current=last;emux::Coefficients increments{};for(unsigned s=0;s<6;++s)for(unsigned k=0;k<5;++k)increments[s][k]=(next[s][k]-last[s][k])*(1.f/256.f);
   for(unsigned n=0;n<b.frames;++n) {
    continuous.set_coefficients(current);float y=continuous.process_sample(rawInput[(b.frame+n)*2]);++continuousSamples;continuousDifferences+=!same(y,rawOutput[(b.frame+n)*2]);
    for(unsigned s=0;s<6;++s)for(unsigned k=0;k<5;++k)current[s][k]+=increments[s][k];
   }
   auto finalState=continuous.state();for(unsigned s=0;s<6;++s)for(unsigned k=0;k<2;++k)continuousStateDifferences+=!same(finalState[s][k],b.after[0][s][k]);
   if(first==UINT_MAX&&(mt||mv||ac||co||ta||pr||de))first=at;
   csv<<at<<','<<mt<<','<<mv<<','<<ac<<','<<co<<','<<ta<<','<<pr<<','<<de<<'\n';
  }
  last=next;
 }
 std::ofstream report(argc>5?argv[5]:"outputs/zplane-ooh-live-trace/stage-comparison.json");if(!report)throw std::runtime_error("Cannot write stage report");report<<"{\n  \"blocks\": "<<h.blocks<<",\n  \"morph_target_differences\": "<<morphTargetDiff<<",\n  \"morph_current_differences\": "<<morphValueDiff<<",\n  \"morph_accumulator_differences\": "<<accumDiff<<",\n  \"current_coefficient_differences\": "<<coeffDiff<<",\n  \"target_coefficient_differences\": "<<targetDiff<<",\n  \"previous_target_differences\": "<<previousDiff<<",\n  \"delta_differences\": "<<deltaDiff<<",\n  \"first_differing_frame\": ";
 if(first==UINT_MAX)report<<"null";else report<<first;
 report<<",\n  \"continuous_replay_samples\": "<<continuousSamples<<",\n  \"continuous_replay_sample_differences\": "<<continuousDifferences<<",\n  \"continuous_replay_final_state_differences\": "<<continuousStateDifferences
 <<",\n  \"continuous_replay_scope\": \"Uses captured internal input and first covered initial state only; original MIDI schedule drives port-generated controls, coefficients and increments; no per-block state resets\"\n}\n";
 std::cout<<"Morph target/current/accumulator differences: "<<morphTargetDiff<<'/'<<morphValueDiff<<'/'<<accumDiff<<"; coefficients/targets/previous/delta: "<<coeffDiff<<'/'<<targetDiff<<'/'<<previousDiff<<'/'<<deltaDiff<<"\n";
 std::cout<<"Continuous replay samples/state differences: "<<continuousSamples<<'/'<<continuousDifferences<<'/'<<continuousStateDifferences<<"\n";
 return morphTargetDiff||morphValueDiff||accumDiff||coeffDiff||targetDiff||previousDiff||deltaDiff||continuousDifferences||continuousStateDifferences?2:0;
 }catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;} }

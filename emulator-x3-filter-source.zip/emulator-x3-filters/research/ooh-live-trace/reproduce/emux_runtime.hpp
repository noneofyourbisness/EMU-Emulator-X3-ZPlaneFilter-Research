#pragma once
#include "emux_filters.hpp"
#include <algorithm>

namespace emux {
// X3's frequency accumulator (0x1402cbb60). Tick once per control quantum.
// The constructor selects position 0.2 in the 21-entry lag table. Its entries
// are float(0.01 / controlSeconds) * float(2^(i * .05 * 10)).
class MorphLag {
public:
    void prepare(double sampleRate, unsigned quantum, float value) noexcept {
        const float scale = static_cast<float>(0.01 / (quantum / sampleRate));
        const float entry = static_cast<float>(std::pow(2.0, .05 * 10.0)) * scale;
        const float position = 20.0f * .01f;
        divisor_ = (entry - 1.0f) * position + 1.0f;
        reciprocal_ = static_cast<double>(1.0f / divisor_);
        reset(value);
    }
    void reset(float value) noexcept { accumulator_ = static_cast<double>(divisor_ * value); }
    float tick(float target) noexcept {
        const double removed = accumulator_ * reciprocal_;
        accumulator_ = accumulator_ - removed;
        accumulator_ = static_cast<double>(target) + accumulator_;
        if (accumulator_ < .0001 && accumulator_ > -.0001) accumulator_ = 0;
        return static_cast<float>(reciprocal_ * accumulator_);
    }
    float divisor() const noexcept { return divisor_; }
    double accumulator() const noexcept { return accumulator_; }
private:
    float divisor_ = 1;
    double reciprocal_ = 1, accumulator_ = 0;
};

// One coefficient ramp shared by two independent channel states. X3 computes
// (next - previous) * float(1 / quantum), processes with the previous value,
// then adds the delta after each mono sample or stereo pair. At the next
// quantum it loads the exact previous target, avoiding accumulated drift.
class RampedStereoFilter {
public:
    RampedStereoFilter() : left_(Coefficients{}, 0), right_(Coefficients{}, 0) {}
    void reset() noexcept { left_.reset(); right_.reset(); }
    void initialize(const Coefficients& c, std::size_t sections) {
        target_ = current_ = c; sections_ = sections; remaining_ = 0;
        left_.set_coefficients(c, sections); right_.set_coefficients(c, sections);
    }
    void ramp_to(const Coefficients& c, std::size_t sections, unsigned count) {
        if (!count || sections != sections_) { initialize(c, sections); return; }
        current_ = target_; target_ = c;
        const float inverse = 1.0f / static_cast<float>(count);
        for (std::size_t s=0; s<sections_; ++s)
            for (std::size_t j=0; j<5; ++j) delta_[s][j] = (target_[s][j]-current_[s][j])*inverse;
        remaining_ = count;
    }
    void process(float& left, float& right, bool stereo) noexcept {
        left_.set_coefficients(current_); right_.set_coefficients(current_);
        left = left_.process_sample(left);
        if (stereo) right = right_.process_sample(right);
        if (remaining_) {
            for (std::size_t s=0; s<sections_; ++s)
                for (std::size_t j=0; j<5; ++j) current_[s][j] += delta_[s][j];
            if (--remaining_ == 0) current_ = target_;
        }
    }
private:
    Filter left_, right_;
    Coefficients current_{}, target_{}, delta_{};
    std::size_t sections_=0;
    unsigned remaining_=0;
};

// Original optional Morph Designer output gain, 0x1402cb140 / 0x1402cbc10.
// These are X3's floating-point signal units; no PCM scale factor is applied.
class AdaptiveGain {
public:
    void prepare(unsigned rate) noexcept {
        multipliers_ = {1.0001f,1.0001f,.996f,.99f,.92f,.5f,.2f,.16f,
                       .12f,.12f,.12f,.12f,.12f,.12f,.12f,.12f};
        for (auto& m : multipliers_) {
            if (rate > 65000) m = std::sqrt(m);
            if (rate > 130000) m = std::sqrt(m);
        }
        reset();
    }
    void reset() noexcept { gain_ = 1; }
    void process(float& left, float& right, bool stereo) noexcept {
        const float peak = stereo ? std::max(std::abs(left),std::abs(right)) : std::abs(left);
        const float value = peak * gain_;
        // CVTTSS2SI's indefinite result has low four bits zero.
        const unsigned index = std::isfinite(value) && value < 2147483648.0f
            ? (static_cast<unsigned>(value) & 15u) : 0u;
        gain_ *= multipliers_[index];
        if (gain_ >= 1.0f) gain_ = 1.0f;
        else { left *= gain_; if (stereo) right *= gain_; }
    }
    float gain() const noexcept { return gain_; }
private:
    std::array<float,16> multipliers_{};
    float gain_=1;
};
} // namespace emux

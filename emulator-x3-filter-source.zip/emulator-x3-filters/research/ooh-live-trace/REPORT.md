# Live Ooh to Eee trace: filter stages are bit-exact

The recovered C++ filter matches **all 925,952 covered X3 filter samples bit-for-bit** in this take. The recovered MIDI/Morph timing, generated coefficients, ramps, and carried filter state also match exactly. This establishes the filter calculation for this recorded configuration; it does not establish bit-exact complete VST3-versus-X3 WAV output.

## What was compared

The supplied `ooh to eee.zip` contains a 24-second raw bus WAV, pre/post-filter WAVs, block snapshots, controller logs, metadata, and the harness's own kernel comparison. Its SHA-256 is `3c5bd928c6db44d6c3a89d083ec7b0cf71675b391655df544e156af06f833bc8`.

Ooh to Eee used base Q50%, realtime Q0%, MIDI note 60 / velocity 127, 44,100 Hz, ASIO256, and the 256-sample standalone control interval. The trace read back the Q values directly. It covers one voice and one filter, using the mono six-section moving SSE kernel (kernel14, variant1). MXCSR was 0x1fa0 throughout: nearest rounding, masked exceptions, FTZ/DAZ disabled.

| Comparison | Values checked | Bit differences |
|---|---:|---:|
| Controller value, Morph position, double accumulator | 10,851 | 0 |
| Current, previous, target, and increment coefficients | 434,040 | 0 |
| Continuous filter output | 925,952 | 0 |
| Continuous final section state | 43,404 | 0 |

There are 3,617 contiguous 256-sample blocks. No observer faults, skipped observations, or trace overflow were recorded. Every captured block's initial state matches the preceding block's final state. Auxiliary pre/post WAV values agree with their trace payloads; the two WAV channels duplicate the mono filter signal.

The covered frame interval is **[44,544, 970,496)**, about **20.997 seconds**. Note-on was at 44,288. The first 256 samples (5.805 ms) precede filter discovery and are not covered. Note-off was at 970,240; the traced interval includes that final block but does not prove the complete release tail.

## Two independent checks

The shipped `X3TraceCompare.exe` was rerun independently. It reproduces the archive's zero sample and final-state differences using captured input, coefficients, and each block's initial state. See [independent-kernel-comparison.json](independent-kernel-comparison.json).

The stronger check uses the reusable source headers to generate controls and coefficients from the original nine CC events, factory table 10, and Q 0.5. It seeds the filter state **once**, at the first covered block, then carries it continuously across the take. It uses X3's captured internal filter input; it never reseeds state between blocks. All generated control values, coefficients, coefficient increments, output samples, and final states agree at the bit level. See [stage-comparison.json](stage-comparison.json) and the [per-block comparison](coefficient-stage-comparison.csv).

The controller snapshots also show indexed slot 17 matching the recovered Mod Wheel driver at every block. This agrees with the saved Mod Wheel routing. Other indexed slots retain their numeric identities rather than speculative names.

## Where the remaining output difference sits

The raw bus WAV is bit-identical to the preceding automatic-batch Ooh to Eee Steps take over the covered interval. The detailed tap therefore left the observed bus signal unchanged in this comparison.

The internal filter input is at a different level from the NoFilter bus WAV previously fed to the effect plugin. Likewise, the internal filter output is at a different level from X3's bus output. The unscaled 68.413% tap-versus-bus error measures that level difference, **not filter error**.

A diagnostic fit in the held-note window estimates an output-to-bus gain near 0.31586923. One binary32 multiply with the best nearby factor leaves about 0.00000630% normalized RMS error and only 47.61% of samples bit-identical. It therefore cannot stand in for X3's exact output chain. The fitted gain has not been added to the library or VST3.

Read-only inspection of the original voice caller shows the filter call at 0x1402e45fa followed by the voice gain/pan/mix call at 0x1402e4615 to 0x1402e8860. That function computes per-block left/right weights and per-sample weight increments, multiplies filter output, and dispatches it to the bus. This directly establishes a post-filter stage. Its actual live weights and downstream arithmetic have not yet been captured.

The validated filter stages do not account for the remaining complete-output difference in this take. Gain and mix operation order is the next likely source to investigate: feeding an already amplified dry bus into a filter effect changes floating-point rounding compared with X3 filtering the internal voice signal before amplification. This is an inference from the tap levels and original call order, not proof of the complete gain chain.

## Scope and next work

This result covers Ooh to Eee at Q50 and the recorded Steps pattern at 44.1kHz/256. It does not prove every other filter, Q setting, sample rate, stereo kernel, active programmable frame, or arbitrary modulation path. Previous multi-filter audio comparisons remain useful but are a different kind of evidence.

The next trace should record the voice amplifier's actual current/next left and right weights, increments, post-amplifier samples, and bus accumulation/output values. Capturing the first voice quantum will also be needed for a full startup comparison. One additional detailed **Peak/Shelf Morph Steps** take at Q50 would extend live coverage to a programmable filter; another full batch is not required for this step.

The existing VST3/filter DSP binaries are unchanged: this evidence validates their recovered filter stages and does not justify a corrective EQ, gain fit, or timing adjustment. Source and package documentation now include this result.

## Reproduction

[The fixture-specific verifier](reproduce/README.md) includes C++ source, the exact current DSP headers, the factory table, and the captured CC event list. It requires the original `20261005-150344-678-Ooh to Eee-steps.trace.bin` from your ZIP. Compile with strict floating-point behavior; run the documented command. The full user recording is not duplicated in this evidence package.

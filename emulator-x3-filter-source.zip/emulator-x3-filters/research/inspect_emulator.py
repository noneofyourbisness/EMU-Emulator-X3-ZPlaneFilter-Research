import collections, hashlib, json, math, pathlib, re, struct

ROOT = pathlib.Path(__file__).resolve().parents[1]
OUT = ROOT
OUT.mkdir(parents=True, exist_ok=True)

class PE:
    def __init__(self, path):
        self.path = pathlib.Path(path)
        self.data = self.path.read_bytes()
        self.pe = struct.unpack_from('<I', self.data, 0x3c)[0]
        assert self.data[self.pe:self.pe+4] == b'PE\0\0'
        self.machine, n, self.timestamp, _, _, optsize, self.flags = struct.unpack_from('<HHIIIHH', self.data, self.pe+4)
        opt = self.pe+24
        self.bits = 64 if self.u16(opt) == 0x20b else 32
        self.base = self.u64(opt+24) if self.bits == 64 else self.u32(opt+28)
        self.entry = self.u32(opt+16)
        dd = opt + (112 if self.bits == 64 else 96)
        self.dirs = [struct.unpack_from('<II', self.data, dd+i*8) for i in range(16)]
        self.sections = []
        for i in range(n):
            off = opt+optsize+i*40
            name, vs, va, size, raw = struct.unpack_from('<8sIIII', self.data, off)
            blob = self.data[raw:raw+size]
            counts = collections.Counter(blob)
            ent = -sum((c/len(blob))*math.log2(c/len(blob)) for c in counts.values()) if blob else 0
            self.sections.append(dict(name=name.rstrip(b'\0').decode(errors='replace'), rva=va, virtual_size=vs, raw_offset=raw, raw_size=size, entropy=round(ent,3)))
    def u16(self,o): return struct.unpack_from('<H',self.data,o)[0]
    def u32(self,o): return struct.unpack_from('<I',self.data,o)[0]
    def u64(self,o): return struct.unpack_from('<Q',self.data,o)[0]
    def offset(self,rva):
        for s in self.sections:
            if s['rva'] <= rva < s['rva']+max(s['raw_size'],s['virtual_size']):
                return s['raw_offset'] + rva-s['rva']
        if rva < self.sections[0]['raw_offset']: return rva
        raise ValueError(hex(rva))
    def va(self,off):
        for s in self.sections:
            if s['raw_offset'] <= off < s['raw_offset']+s['raw_size']:
                return self.base+s['rva']+off-s['raw_offset']
        return None
    def cstr(self,off): return self.data[off:self.data.index(b'\0',off)].decode('ascii',errors='replace')
    def imports(self):
        rva,size=self.dirs[1]
        if not rva: return []
        off=self.offset(rva); result=[]
        while any(self.data[off:off+20]):
            orig,_,_,name,first=struct.unpack_from('<IIIII',self.data,off)
            to=self.offset(orig or first); names=[]; j=0; width=self.bits//8
            while True:
                v=self.u64(to+j*width) if self.bits == 64 else self.u32(to+j*width)
                if not v: break
                ordinal=1 << (self.bits-1)
                names.append({'name': '#'+str(v&65535) if v&ordinal else self.cstr(self.offset(v)+2), 'iat_va':hex(self.base+first+j*width)})
                j+=1
            result.append({'dll':self.cstr(self.offset(name)),'functions':names})
            off+=20
        return result
    def exports(self):
        rva,size=self.dirs[0]
        if not rva: return []
        off=self.offset(rva)
        _,_,_,_,_,base,nfunc,nnames,funcs,names,ordinals=struct.unpack_from('<IIHHIIIIIII',self.data,off)
        result=[]
        for i in range(nnames):
            name=self.cstr(self.offset(self.u32(self.offset(names)+i*4)))
            ordinal=self.u16(self.offset(ordinals)+i*2)
            result.append({'name':name,'ordinal':base+ordinal,'va':hex(self.base+self.u32(self.offset(funcs)+ordinal*4))})
        return result
    def summary(self):
        return {'path':str(self.path),'sha256':hashlib.sha256(self.data).hexdigest(),'size':len(self.data),'machine':hex(self.machine),'bits':self.bits,'base':hex(self.base),'entry':hex(self.base+self.entry),'sections':self.sections,'exports':self.exports(),'imports':self.imports()}

if __name__ == '__main__':
    install=pathlib.Path(r'C:\Program Files\E-MU\Emulator X3')
    pe=PE(install/'EmulatorX.exe')
    report=pe.summary()
    (OUT/'binary-inventory.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    strings=[]
    for encoding,regex in [('ascii',rb'[\x20-\x7e]{5,}'),('utf-16le',rb'(?:[\x20-\x7e]\x00){5,}')]:
        for m in re.finditer(regex,pe.data):
            value=m[0].decode(encoding)
            if re.search(r'filter|plane|morph|biquad|\.pdb|\.cpp|\.c\b|resonan|vowel|parametric',value,re.I):
                strings.append({'offset':hex(m.start()),'va':hex(pe.va(m.start())) if pe.va(m.start()) else None,'encoding':encoding,'text':value})
    (OUT/'filter-strings.json').write_text(json.dumps(strings,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in report.items() if k not in ('imports','exports')},indent=2))
    print('Exports:',len(report['exports']))
    print('Filter-related exports:',[x for x in report['exports'] if re.search(r'filter|biquad|morph|plane|resonan',x['name'],re.I)])
    print('Imports:',[(x['dll'],len(x['functions'])) for x in report['imports']])
    print('Relevant strings:',len(strings))
    print(json.dumps([x for x in strings if not re.search(r'Revis|XML|Xerces|Parser|Exception|Source|DOM|Namespace|xmlns',x['text'])][:100],indent=2))

#include "../emux_filters.hpp"
#include <cstring>
#include <iostream>
template<class T> T read(std::ifstream& file) {
    T value{};
    if (!file.read(reinterpret_cast<char*>(&value), sizeof(value)))
        throw std::runtime_error("Missing test vector");
    return value;
}
bool same(float a, float b) { return std::memcmp(&a, &b, 4) == 0; }
int main() {
    auto bank = emux::FactoryBank::from_table_file("factory-bank.bin");
    std::ifstream file("research/cpp-vectors.bin", std::ios::binary);
    const auto count = read<unsigned>(file);
    for (unsigned test = 0; test < count; ++test) {
        const auto index = read<unsigned>(file), rate = read<unsigned>(file);
        const auto freq = read<float>(file), res = read<float>(file);
        const auto coefficients = bank.coefficients(index, freq, res, rate);
        for (const auto& stage : coefficients)
            for (const auto value : stage)
                if (!same(value, read<float>(file))) {
                    std::cerr << "Coefficient mismatch at case " << test << '\n'; return 1;
                }
        std::array<float, 64> input{}, expected{}, output{};
        for (auto& value : input) value = read<float>(file);
        for (auto& value : expected) value = read<float>(file);
        emux::Filter filter(coefficients);
        filter.process(input.data(), output.data(), 17);
        filter.process(input.data() + 17, output.data() + 17, 47);
        for (unsigned i = 0; i < 64; ++i)
            if (!same(output[i], expected[i])) {
                std::cerr << "Audio mismatch at case " << test << " sample " << i << '\n'; return 1;
            }
    }
    for (unsigned word = 0; word < 65536; ++word)
        if (!same(emux::decode_word(static_cast<std::uint16_t>(word)), read<float>(file))) {
            std::cerr << "Decode mismatch at word " << word << '\n'; return 1;
        }
    std::cout << "C++: 924 cases, 59,136 samples and all 65,536 words match bit-for-bit.\n";
}

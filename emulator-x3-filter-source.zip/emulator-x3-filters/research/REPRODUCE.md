# Reproduce the comparisons

Run these from the root of the unzipped source package. The default original
executable path is `C:\Program Files\E-MU\Emulator X3\EmulatorX.exe`.
The library refuses any other SHA-256 fingerprint. All analysis is read-only
with respect to the sampler installation.

Use Python 3.11 or newer and install analysis tools locally:

```text
python -m pip install --target research/python-deps capstone==5.0.9 pefile==2024.8.26 unicorn==2.1.4
python research/inspect_emulator.py
python research/trace_filters.py
python research/index_code.py
python research/validate_port.py
python research/make_cpp_vectors.py
python research/recover_extended.py
python research/validate_extended.py
python research/make_extended_vectors.py
```

The validation emulates original routines from your executable in local CPU
emulator memory. It does not load the file as a Windows executable or connect
to an activation service. Calls to the standard C `ldexp` function are supplied
by Python's `math.ldexp`.

For compiled C++ validation, use a C++17 compiler, disable fast-math and floating
point contraction, then run the test executable from the package root:

```text
g++ -std=c++17 -O2 -ffp-contract=off -fno-fast-math research/check_cpp.cpp -o research/check_cpp.exe
research/check_cpp.exe
g++ -std=c++17 -O2 -ffp-contract=off -fno-fast-math research/check_extended.cpp -o research/check_extended.exe
research/check_extended.exe
```

The test compares the C++ implementation with the Python reference vectors that
were validated against the original scalar instructions. It checks 924
coefficient/audio cases, all packed words and split-block state continuity.
The additional test checks 3,156 cases covering all 22 other filter types,
original setup frames, coefficients/audio, split processing and reset.
Scripts generate vectors under `research/`, and the extended bank JSON and two
binary banks at the package root. Generated data is not in the source archive.

`trace_filters.py` uses x64 RTTI and the PE exception directory to locate filter
classes. Function disassembly is evidence for further work, not recovered
source. The scripts are specific to the supplied build and are not a generic
extractor for all Emulator X / Proteus binaries.

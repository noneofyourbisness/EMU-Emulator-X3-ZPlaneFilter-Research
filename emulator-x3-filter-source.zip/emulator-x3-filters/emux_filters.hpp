#pragma once
// Recovered X3 twelve-pole factory-filter core. See README.md for scope.
// Compile without fast-math or FP contraction for scalar X3 rounding behavior.
#include <array>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <fstream>
#include <stdexcept>
#include <string>

namespace emux {
using Section = std::array<float, 5>;
using Coefficients = std::array<Section, 6>;
constexpr std::size_t bank_words = 33 * 4 * 120;
using Table = std::array<std::uint16_t, bank_words>;

inline float decode_word(std::uint16_t word) noexcept {
    const unsigned n = static_cast<unsigned>(word) + 1;
    if (n == 65536) return 1.0f;
    if (n == 1) return 0.0f;
    const int exponent = static_cast<int>((n >> 12) & 15) - 15;
    const unsigned mantissa = (n & 4095) | (exponent > -15 ? 4096 : 0);
    const float value = static_cast<float>(mantissa) *
        (exponent > -15 ? 1.0f / 8192.0f : 1.0f / 4096.0f);
    return static_cast<float>(std::ldexp(static_cast<double>(value), exponent));
}

inline float normalized(float value) {
    if (!std::isfinite(value)) throw std::invalid_argument("Non-finite control");
    return value < 0.0f ? 0.0f : value > 1.0f ? 1.0f : value;
}

inline std::uint16_t interpolate(std::uint16_t a, std::uint16_t b, float t) noexcept {
    const float delta = static_cast<float>(static_cast<int>(b) - static_cast<int>(a)) * t;
    return static_cast<std::uint16_t>(static_cast<int>(a) + static_cast<int>(delta));
}

class FactoryBank {
public:
    explicit FactoryBank(Table table) : table_(table) {}

    // Use Python FactoryBank.save_binary() to export the fingerprinted local data.
    static FactoryBank from_table_file(const std::string& path) {
        std::ifstream file(path, std::ios::binary);
        if (!file) throw std::runtime_error("Cannot open extracted factory bank");
        Table table{};
        for (auto& word : table) {
            unsigned char bytes[2];
            if (!file.read(reinterpret_cast<char*>(bytes), 2))
                throw std::runtime_error("Truncated factory bank");
            word = static_cast<std::uint16_t>(bytes[0] | (bytes[1] << 8));
        }
        if (file.get() != std::char_traits<char>::eof())
            throw std::runtime_error("Incorrect factory bank length");
        return FactoryBank(table);
    }

    Coefficients coefficients(unsigned filter, float frequency, float resonance,
                              unsigned sample_rate = 48000) const {
        if (filter >= 33) throw std::invalid_argument("Filter must be 0..32");
        unsigned rate = 0;
        switch (sample_rate) {
            case 44100: rate = 0; break;
            case 48000: rate = 1; break;
            case 96000: rate = 2; break;
            case 192000: rate = 3; break;
            default: throw std::invalid_argument("Unsupported sample rate");
        }
        frequency = normalized(frequency);
        resonance = normalized(resonance);
        Coefficients result{};
        for (std::size_t stage = 0; stage < 6; ++stage) {
            Section decoded{};
            const auto base = (filter * 4 + rate) * 120 + stage * 20;
            for (std::size_t j = 0; j < 5; ++j) {
                const auto lo = interpolate(table_[base+j], table_[base+5+j], frequency);
                const auto hi = interpolate(table_[base+10+j], table_[base+15+j], frequency);
                decoded[j] = decode_word(interpolate(lo, hi, resonance));
            }
            result[stage] = {4.0f * decoded[0] + decoded[1], decoded[1],
                             4.0f * decoded[2] + decoded[3], decoded[3], 4.0f * decoded[4]};
        }
        return result;
    }
private:
    Table table_;
};

class Filter {
public:
    using State = std::array<std::array<float, 2>, 6>;
    State state() const noexcept { return state_; }
    void restore_state(const State& state) noexcept { state_ = state; }
    explicit Filter(const Coefficients& coefficients, std::size_t sections = 6)
        : coefficients_(coefficients), sections_(sections) {
        if (sections > 6) throw std::invalid_argument("Section count must be 0..6");
    }
    void reset() noexcept { state_ = {}; }
    void set_coefficients(const Coefficients& coefficients) noexcept {
        coefficients_ = coefficients;
    }
    void set_coefficients(const Coefficients& coefficients, std::size_t sections) {
        if (sections > 6) throw std::invalid_argument("Section count must be 0..6");
        if (sections != sections_) reset();
        sections_ = sections;
        coefficients_ = coefficients;
    }
    float process_sample(float x) noexcept {
        for (std::size_t i = 0; i < sections_; ++i) {
            const auto& c = coefficients_[i];
            const float s1 = state_[i][0], s2 = state_[i][1];
            const float t = (s2 * c[3] - s1 * c[2]) + x;
            x = ((s1 * c[0] + t) - s2 * c[1]) * c[4];
            state_[i] = {(2.0f * s1 + t) - s2, s1};
        }
        return x;
    }
    // In-place processing is supported. No allocation or system calls here.
    void process(const float* input, float* output, std::size_t count) noexcept {
        for (std::size_t i = 0; i < count; ++i) output[i] = process_sample(input[i]);
    }
private:
    Coefficients coefficients_;
    std::size_t sections_ = 6;
    std::array<std::array<float, 2>, 6> state_{};
};
} // namespace emux
